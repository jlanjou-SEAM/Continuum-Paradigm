# The Framework

> Read `00_EXECUTION_CONTRACT.md` first. This document states what the framework is and how
> it derives its results. It does not establish standing — that is `02_RECORD.md`.

---

## 1. What this is

**Continuum Paradigm** is the project name. It is presented as a **proposed scientific
paradigm and causal framework** — not a theory of everything, and not a claim of community
adoption.

The claim is narrow and specific: existing science provides a precise description of the
observable surface of reality; this framework supplies a structural causal layer beneath
those descriptions. The established laws and equations of science remain the language in
which resolved outcomes are measured. The framework describes the structure that produces
them.

```
SEAM causal structure -> physical state and evolution -> observable -> scientific description
```

The framework is deliberately falsifiable. A valid counterexample to a universal canonical
first principle or universal consequence, established under its declared contract,
falsifies that standing and therefore the foundational framework as currently stated.

### Layer identity

| Layer | Responsibility |
|---|---|
| **ESIH** | Definition of permissible structure and possible existence |
| **AEPS** | Definition of how energy interacts with and distributes across structure |
| **ESAM** | Mathematical formalization lineage expressing ESIH principles in SEAM mathematics |
| **SEAM** | Mathematical representation and execution of structure, relation, interaction, state change |

The canonical mathematics defines the system. The engine is a conforming implementation
and has no authority to redefine it.

### Existence standard

```
C_possible = A_SEAM                  (admissible structure)
C_realized ⊆ A_SEAM                  (structure actually realized)
M_t = RetainNormalize(ObservedResolved(C_realized))
```

The Continuum is the physical domain. The Manifold is the retained, normalized record of
observed or resolved portions of that domain.

---

## 2. First principles

These ten are the foundational layer. Everything downstream must derive from them, and
nothing may be introduced that is not declared here or admitted by an active run contract.

**FP-01 — Layer identity.** `ESIH -> ESAM -> SEAM`. Principles, formulation, execution.

**FP-02 — Continuity first.** Reality is represented through persistent or traceably
transformed structure. Conventional named laws are not native starting assumptions.
`continuity/traceability -> represented structure -> admissible state`

**FP-03 — Atomic starting law.** The canonical atomic starting statement is `Z(n)`, the
baseline number of electrons to distribute. Charge state, neutron closure, isotope state,
and shell arrangement are downstream derivations.
`Z(n) -> {N_i,n} -> {ρ_i,n} -> S_i`

**FP-04 — Single interaction law across construction scale.** Atomic, molecular, and
amalgamum binding are manifestations of one entropy-governed interaction law. A separate
force law is not introduced because the scale changed. Same governing law, not equal
magnitude.

**FP-05 — Entropy selection law.** Entropy is the native selector among admissible
configurations. No external objective replaces it.
`C* = arg max_{C ∈ A} S[C]`

**FP-06 — Closure law.** Full entropy closure corresponds to a highly stable admissible
configuration. Partial closure retains structural differential available for bonding,
reconfiguration, reactivity, or volatility.
`S_rule^atomic = S_rule^molecular = S_rule^amalgamum`

**FP-07 — Projection law.** The framework executes one representational layer upstream of
conventional physics. Native structure is constructed and sealed first; conventional
equations and units are downstream projection, never native generators.

**FP-08 — Metrology law.** Time is count-resolved from the Cs-133 hyperfine transition.
Native distance is a count of native spatial separation projected through a canonical
baseline length.
`T(X) = n_Cs(X) / 9,192,631,770;  f = 1/T;  L = N_L · L_A`

**FP-09 — Truth and falsification law.** A first-principle claim must derive from declared
primitives without unsupported external assumptions. An empirical claim must be
demonstrated against observation. Formal consistency alone does not promote a claim to
empirical truth.

**FP-10 — No implicit law.** Silence is prohibition, not permission. The executor consumes
only mathematics, branches, constants, domains, and inputs explicitly stated or admitted by
the active run contract. An undeclared required object yields a declared terminal state —
never an invented substitute.

---

## 3. Structural representation

### 3.1 Atomic baseline

An atom enters as an electron count `Z`. Electrons distribute across seven shells with
capacity vector:

```
[2, 8, 18, 32, 18, 32, 18]        ceiling = 128
```

This vector is **stated, not derived**, and carries a direct falsifiable consequence:
`Z ≥ 129` yields `∅`. No element beyond the ceiling is admissible. The domain for the sign
law is `Z = 3..128`, 126 evaluable states.

### 3.2 Complete configuration

```
C = ({Σ}, R)
```

A configuration is the set of structural entities together with their retained relational
coordinate. Equal entropy values do **not** imply identical configurations — the relational
coordinate `R` is retained independently. Structure is never collapsed to a scalar; a
faceted description is complete, not deferred.

### 3.3 Native shell support

```
Ω_{i,n} = { ξ : n−1 ≤ ‖ξ − X_i‖ < n }
```

Uniform unit-width radial shells around each center.

---

## 4. Entropy-directed resolution

### 4.1 The canonical decomposition

```
S = S_config + λ_field · S_field + λ_coupling · S_coupling

λ_field    = 1.0
λ_coupling = 0.1
```

Configuration entropy, structural field entropy, and coupling entropy are distinguishable
facets of one quantity. Field, energy, and material exchange are constituents of the
configuration state `C` — not separate causal agents.

### 4.2 Selection

```
C* = arg max_{C ∈ A} S[C]
```

Entropy is the single organizing principle. When asking why a configuration emerges, why
an entity persists, or why a succession occurs, the answer is entropy maximization. It is
not one cause among several.

### 4.3 The interior-maximum requirement

A finite molecular separation requires a genuine **interior maximum** of `S` with respect
to separation. A monotonically varying coupling term alone is insufficient — it produces a
boundary extremum, not a bond.

This requirement is what makes the molecular layer falsifiable, and it is where the
framework currently carries an open defect. See §6.

### 4.4 Variational contract v18.6

The current canonical evaluator is `VF-REGION-LBFGSB-R4`. The admissible field state is
resolved variationally over a profile family rather than assumed at fixed support.

**Critical distinction:** `u^(0) ∈ U` does not imply `u^(0) = u*`. A fixed-support
evaluation is a member of the admissible set, not the variational result. Conflating them
is misreading #6.

---

## 5. Nuclear formation

### 5.1 The chain

```
(Z, N) -> Γ_{Z,N} -> mean(Γ) -> A_Γ -> E_Γ(Z) -> (N_low, N_high)
```

The frozen `Γ_{Z,N}` relation matrix is the current nuclear authority. The historical
PNE/EPN `S(X)` spectral operator is **superseded** and is not a current source requirement.
A historical certificate may cite it only when describing a sealed execution that actually
used it.

### 5.2 What the envelope delivers

`N_low` and `N_high` are produced natively, before any comparator is opened. On comparator
access:

| Measure | Result |
|---|---|
| Evaluated-experimental states contained | 2549 / 2549 |
| Natural states contained | 288 / 288 |
| Mean band-to-observed width ratio | 3.766 |
| Retained outside-band failures | Li-3, Be-5, B-6 |

**Containment is scope, not precision.** The ratio is reported precisely so that 2549/2549
is not read as sharpness. The envelope is a statement about what can form, tested against
what has been observed to form.

The band tightens substantially at the light end, where the observed spans are
well-characterized:

| Element | Band width | Observed span | Ratio |
|---|---|---|---|
| B | 16 | 14 | 1.14 |
| C | 17 | 14 | 1.21 |
| O | 20 | 15 | 1.33 |
| N | 18 | 13 | 1.38 |
| Mg | 25 | 18 | 1.39 |

At the superheavy end the ratio degrades sharply, but observed spans there are 1–2 nuclides
because little has been synthesized. Those ratios measure experimental coverage, not model
width.

### 5.3 The four coordinates and their status

| Coordinate | Status |
|---|---|
| `N_low` | **Locked.** Frozen `Γ` formation-envelope lower coordinate. |
| `N_most-stable^SEAM` | **Requires separately locked native derivation.** |
| `N_longest-lived^SEAM` | **Requires separately locked native derivation.** |
| `N_high` | **Locked.** Frozen `Γ` formation-envelope upper coordinate. |

R229 is a falsification of one candidate interior entropy binding and cannot be cited as a
successful selector. R227 establishes that `Γ`, `W`, `W/Z`, and empirical `B/A` are not
interchangeable with the persistence selector — empirical stability and half-life are
downstream comparators and are not selector inputs.

Columns in the executed run carrying `EMPIRICAL_B_PER_A_PEAK_CANDIDATE` or
`EMPIRICAL_STABLE_TIE` are labelled candidates awaiting native derivation. They are not
SEAM predictions and are not presented as such.

---

## 6. Molecular layer — current state

### 6.1 What is established

Under the v18.6 variational contract: **Cu–Cu resolves positive. H–He is correctly rejected
as a negative control.** The evaluator discriminates.

### 6.2 The open defect

H–H produces no finite entropy maximum above the separated state.

```
S_separated / k_B        = 3.511853499981017
best overlapping S / k_B = 3.511826296100812   at N_r = 1.987866108786611
ΔS / k_B                 = −2.7203880205e−05
interior_local_maxima    : []
finite_entropy_closure   : false
```

The deficiency lies in the present relational/field admissible-state formulation or
evaluator, not in the observation. Because the aggregate construction uses the same
unconditioned entropy selector, this defect is relevant to molecular and aggregate closures
generally and is stated here rather than left in an evidence file.

### 6.3 Retained negative results

These are part of the record, not omissions from it:

- **`REJECTED_H2_UNIFORM_SHELL_CONTRACT`** — under uniform unit-width top-hat shell support,
  two disjoint uniform balls have separation-independent field entropy. `S_field` rises then
  goes flat; the coupling term decreases monotonically to zero. No interior maximum exists.
  The apparent peak is a plateau-edge artifact.
- **`RUN-H2-RHO-VOLUME-01`** — the entire fixed-support-rescaling class is rejected. A linear
  rescaling cannot create an extremum where none exists.
- **Radial shape sensitivity (noncanonical sensitivity tests).** With a support-aligned
  evaluator, `R = 1` frozen and λ frozen: linear profile `u(r) = √(15/2π)(1−r)` →
  `RESOLVED_INTERIOR_MAXIMUM`, `N_r* = 1.6008992282173213`, `S/k_B = 2.779426544263546`,
  `D² = −0.3218`. Quadratic `u(r) = √(105/32π)(1−r²)` → `N_r* = 1.7017708805671177`. Edge
  profile `u(r) = √(5/4π)·r` → `REJECTED_NO_INTERIOR_MAXIMUM`. Disposition:
  `RADIAL_SHAPE_SENSITIVITY_DEMONSTRATED`. These are sensitivity tests, not canonical law.

---

## 7. Metrology

```
L_A = N_A · λ_A          native atomic baseline length
τ_A = M_A / ν_A          native interval
L   = N_D · L_A          projected length
T(X) = n_Cs(X) / 9,192,631,770
```

Time is count-resolved against the Cs-133 hyperfine transition; evidence card
`EVID-CS-TIME-001` embeds the external reference used to check the statement.

**Scope boundary, stated explicitly:** the Appendix N fixture (`λ_A = 3/7`, `N_A = 14`,
`L_A = 6`) is deliberately synthetic. It is not a calibration of a physical atomic length,
and a PASS on it does not calibrate the empirical magnitude of `L_A`. The metrology chain
is established as a projection structure; the physical magnitude binding is a separate
question.

---

## 8. The interaction law

One law governs across scale (FP-04). The atomic, molecular, and aggregate cases differ in
construction and configuration, not in governing principle.

Downstream projections — Hamiltonian correspondence quantities, pair energies, forces,
macroscopic chains — are **facets** of the resolved state `C*`, not separate runtime stages.
An expression such as `E_H[C*]` names an evaluation of the retained state. Functional
notation alone does not create a handoff; a handoff exists only where a
`consumes / operation / produces` boundary is explicitly declared.

---

## 9. What would falsify this

Stated affirmatively, because a framework that cannot say this is not doing science:

- **The shell ceiling.** A confirmed element at `Z ≥ 129` falsifies the capacity vector and
  the admissibility construction built on it.
- **The formation envelope.** An observed nuclide outside `[N_low, N_high]` for its `Z`,
  under evaluated-experimental status, falsifies the `Γ` envelope. Three are currently
  retained as failures (Li-3, Be-5, B-6); they are recorded, not excluded.
- **The entropy selector.** A configuration that is realized in nature but is not the
  entropy maximum over the admissible set falsifies FP-05.
- **Single interaction law.** A binding regime requiring an independent force law not
  reducible to the entropy-governed interaction falsifies FP-04.
- **Derivation without primitives.** Any canonical result shown to require an undeclared
  external assumption falsifies FP-10 and voids the closure that used it.

A failure traced to implementation, input, contract, or projection is bounded. A failure
traced to the canonical mathematics is foundational. The distinction is not a shield — it
determines what has actually been learned.
