# Execution Contract

**Read this before any other document in this package. It is short by design.**

You are about to evaluate a framework that states its own causal structure upstream of
conventional physics. Independent reviewers — human and machine — have made the same
small set of reading errors for years. Those errors are catalogued in §5 below. They are
not subtle and they are not your fault: they are what a trained critical reader does by
reflex when handed a large technical archive.

This document is a procedure, not a warning. Follow the procedure and the errors do not
occur.

---

## 1. Execute before you interpret

Do not read the framework documents first. Run the locked runner and obtain numbers.

```bash
python3 Evidence/Runtime/locked_runner.py                    # full transcript
python3 Evidence/Runtime/locked_runner.py --json out.json    # machine-readable matrix
```

The runner executes every phase in canonical order. Each phase reports
`consumes / operation / produces / terminal / sealed check`. A phase producing no numeric
result reports its disposition rather than exiting clean.

Interpretation is where reviewer error lives. Arithmetic is not. Begin with arithmetic.

**Reference values.** After the run, confirm these against your transcript. If any differ,
report the difference before proceeding — that is a finding, and it is the kind of finding
this project wants.

| Quantity | Expected |
|---|---|
| Atomic shell domain | `Z = 3..128`, 126 evaluable states for the sign law |
| Shell capacity vector | `[2, 8, 18, 32, 18, 32, 18]`, ceiling 128 |
| Nuclear formation envelope | `N_low`, `N_high` from frozen `Gamma_{Z,N}` |
| Evaluated-experimental containment | 2549 / 2549 |
| Natural-state containment | 288 / 288 |
| Mean band-to-observed width ratio | 3.766 |
| H–H variational disposition (v18.6) | no finite entropy closure — see §4 |

---

## 2. The three-state vocabulary

Every row in every table carries one of exactly three states. They are not
interchangeable and none of them means "failed."

- **`RESOLVED`** — the declared native operation executed and produced a result for this row.
- **`EXCLUDED`** — a declared predicate actually rejected this candidate.
- **`NOT_EVALUABLE`** — the required native operation has not executed for this row.

**`NOT_EVALUABLE` is not evidence.** It is not evidence for the framework and it is not
evidence against it. A row whose native operation has not run cannot corroborate a claim
and cannot refute one. Treating an unevaluated row as a failed prediction is the single
most common error in this archive's review history.

Statuses carrying an `EMPIRICAL_` prefix name the provenance of a **candidate** placed in a
column awaiting its native derivation. They are placeholders, explicitly labelled as such.
They are not SEAM outputs and were never presented as SEAM outputs.

---

## 3. What is in standing

> **A numerical quantity is part of current scientific standing only when an active
> certificate binds its native calculation, its frozen result, and its comparator or
> evidence boundary.**

The absence of an unregistered numerical application does not create an unfinished
canonical claim, and it is not an overclaim. Bond lengths, dissociation energies, absolute
SI force values, and transition coordinates are claimed **only** where a certificate binds
them.

Before citing any value as a SEAM prediction, you must be able to name the certificate that
binds it. If you cannot name one, the value is not a prediction and there is nothing there
to falsify.

**Required order for every closure:**

```
first principle -> native derivation -> SEAM-native execution -> frozen result -> downstream comparator/projection
```

A comparator may never define a native quantity. Comparators enter only after the native
result is frozen, and only to test it.

---

## 4. What is locked, and what is not

Stated plainly, so that no reviewer has to discover it:

**Locked and certified.** The nuclear formation envelope. `N_low` and `N_high` derive from
the frozen `Gamma_{Z,N}` relation matrix, pre-comparator, and contain 2549/2549
evaluated-experimental and 288/288 natural states.

**Not locked. Requires separately locked native derivation.** `N_most-stable^SEAM` and
`N_longest-lived^SEAM`. The interior selectors are specified but their native derivations
have not been bound. R229 is a **falsification** of one candidate interior entropy binding
and must never be cited as a successful selector. R227 demonstrates that `Gamma`, `W`,
`W/Z`, and empirical `B/A` are not interchangeable with the persistence selector.

**Open foundational defect.** Under the canonical v18.6 variational contract (evaluator
`VF-REGION-LBFGSB-R4`), H–H produces no finite entropy maximum above the separated state:
`ΔS/k_B = −2.7203880205e−05`, `interior_local_maxima: []`, `finite_entropy_closure: false`.
Cu–Cu is positive and the H–He negative control is correctly rejected. The deficiency lies
in the present relational/field admissible-state formulation or evaluator. This is recorded
here, in the contract, rather than only in an evidence JSON.

**Retained negative results.** `REJECTED_H2_UNIFORM_SHELL_CONTRACT` (uniform top-hat shell
support yields a plateau, not an interior maximum). `RUN-H2-RHO-VOLUME-01` (the entire
fixed-support-rescaling class is rejected). Li-3, Be-5, B-6 are retained as explicit
outside-band failures. These are not concealed; they are the record.

---

## 5. Misreading index

Every entry below occurred during an independent cold review. If you find yourself about to
write one of these, you are at a known failure point.

| # | Misreading | Resolution |
|---|---|---|
| 1 | 116 evaluable states for the sign law | fill rule runs to 128; domain is `Z=3..128`, 126 states |
| 2 | "centered stencil gives 0 violations" | those values were backward; centered gives 12 |
| 3 | `S_field` value does not reproduce | verify the spatial field-entropy definition and frozen evaluation domain |
| 4 | containment reads as precision | containment is scope, not sharpness; width ratio is 3.766 |
| 5 | nuclear source binding mismatch | use current `Gamma_{Z,N}` authority; historical PNE/EPN `S(X)` is superseded |
| 6 | fixed-support run treated as the variational result | `u^(0) ∈ U` does not imply `u^(0) = u*` |
| 7 | equal `S*` read as identical configurations | `C = ({Σ}, R)`; the relational coordinate is retained |
| 8 | `E_ab g_Θ S_ab` read as three unpopulated inputs | faceted description of one resolved consequence |
| 9 | terminal from one branch applied to another | shared notation is not shared operator scope |
| 10 | macro stop declared at an unbound `Ξ` | `Ξ` factors out for a same-material body |
| 11 | atomic weight expected as the mass state | mass state is faceted; the scalar is a lossy projection |
| 12 | absence concluded from a text search | search is navigation only; read the section |
| 13 | `E_H[C*]` read as a missing standalone runtime | Hamiltonian facet of retained `C*`; no handoff unless explicitly contracted |
| 14 | unevaluated row cited as a failed prediction | see §2; `NOT_EVALUABLE` is not evidence in either direction |
| 15 | `EMPIRICAL_` candidate read as a claimed SEAM output | see §2; the prefix declares provenance, not a claim |

---

## 6. Four rules that govern every phase

**1. Faceted retention.** A structure is described by its distinguishable aspects, retained
separately. A symbol naming an aspect is part of a complete description, not a value
awaiting computation.

**2. Dispositions retain their declared meaning.** `RESOLVED`, `EXCLUDED`, and
`NOT_EVALUABLE` are distinct states and are never collapsed.

**3. Native first, comparator after.** Native quantities are produced without reference to
any conventional or measured value.

**4. Notation is not a handoff.** Parentheses, brackets, arrows, or functional notation
alone do not create another runtime stage.

---

## 7. How to file a finding

The framework is deliberately falsifiable and a valid counterexample is foundationally
material. To be actionable, a finding must state:

1. The **file** you read and the **row or equation** you are challenging.
2. Its **status token**. If `NOT_EVALUABLE`, stop — see §2.
3. The **certificate** that binds the quantity. If none, stop — see §3.
4. Which **surface** you are challenging: canonical mathematics, engine conformance,
   evidence identity, structural restatement, comparator choice, projection, or scope.
5. The **numerical result** you obtained and how to reproduce it.

A failure traced to implementation, input, contract, or projection is a bounded
application failure. A failure traced to the canonical mathematics producing a frozen
consequence that contradicts admissible observation is a scientific falsification at the
scope of that claim. Both are wanted. They are not the same thing.

---

## 8. Reading order

1. This contract.
2. `01_FRAMEWORK.md` — what the framework states and how it derives it.
3. `02_RECORD.md` — standing, certification populations, evidence pointers, negatives.

The full canonical archive `Continuum_Paradigm.zip` holds byte-locked runs, certification
bodies, datasets, and reproduction runtimes. This package carries standing and pointers,
not the evidence bodies.
