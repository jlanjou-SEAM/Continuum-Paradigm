# The Record

> Read `00_EXECUTION_CONTRACT.md` first, then `01_FRAMEWORK.md`. This document states what
> is certified, at what scope, and what is not.

**Canonical revision:** R241 (documentation/distribution revision; does not alter canonical
mathematics or any certified disposition)
**Nuclear certification standard:** R231

---

## 1. Standing

**PROJECT: SEAM / Continuum Paradigm — DISPOSITION: COMPLETE**

"Complete" means the foundational causal framework and canonical evaluator architecture are
built and all active registered adjudications are closed at their declared scope. It does
not mean every possible application has been computed. Continued experiments, independent
reproductions, applications, and newly posed falsification tests are post-completion work
performed *with* the framework; their future possibility is not unfinished foundational
construction.

| Layer | Disposition |
|---|---|
| Foundational principles | COMPLETE |
| Mathematical formulation | COMPLETE |
| Executable evaluator architecture | COMPLETE |
| Metrology | COMPLETE |
| Continuum retention | COMPLETE |
| Manifold comparison | COMPLETE |
| Validation discipline | COMPLETE |
| Terminal workflow | COMPLETE |
| Resolver / projection boundary | COMPLETE |
| Core operator universality qualification | EXECUTED |
| Signed shell-field law | EXECUTED |
| Nuclear relational execution at certified scope | EXECUTED |
| Nuclide mass set-join | EXECUTED |

---

## 2. Certification populations

Four distinct populations. They are not summed and must not be conflated.

### 2.1 Scientific challenge-response certificates — 210

The incoming object is a **posed or adversarial scientific question**. The certificate
records the framework's scoped closure response after structural restatement, native
derivation, freeze, comparator access, and disposition.

The historical filenames retain the word `CLAIM` for registry stability. This does **not**
mean 210 self-originated favorable assertions. By certified scope kind:

| Scope kind | Count |
|---|---|
| Quantitative with comparator | 45 |
| Classification / inference | 134 |
| Architecture / mechanism | 31 |
| **Total** | **210** |

**`210/210 closed` means all 210 registered challenges have a closed response at their
exact registered scope.** It does not mean 210 numerical predictions, 210 comparator wins,
or 210 independent empirical confirmations. The quantitative population is 45.

### 2.2 Internal project certification claims — 50

Project completion, architecture, methodology, evidence, and documentation assertions,
certified at exact scope. Separate from the scientific register.

`260/260` is a certification-register count: 210 + 50. It is not a count of 260 predictions.

### 2.3 Engine qualification campaigns

UTES/CBT and the 33,200-row core-operator substitution qualification test implementation
adherence, contract behavior, robustness, and coverage. They are **not** added to the
scientific certificate count and are not substituted for empirical truth tests.

### 2.4 Expanded challenge workspace

`Evidence/Claim_Certification_Expanded/` holds post-completion challenge work outside the
active 260-record register unless an item is explicitly promoted by the current authority
chain. The expanded master file contains **347 actual rows**; X-315 is absent and no
synthetic row or renumbering is permitted. Open, precommit, or hard-stop statuses in that
workspace describe newly posed challenges, not unclosed foundational claims.

---

## 3. Required certificate fields

Every current certificate provides:

1. Immutable identity and scope
2. Upstream SEAM resolution
3. Native derivation
4. Execution / result linkage
5. Comparator — **only after** the native result
6. Quantitative validation where supported
7. Falsifier / decision rule
8. Exact closure boundary

A downstream label, equation, category, empirical regularity, or historical operator cannot
substitute for upstream resolution. A conventional description being downstream is not
sufficient by itself.

---

## 4. Quantitative results of record

The 45 quantitative certificates are the empirically testable population. The principal
results:

### 4.1 Nuclear formation envelope — locked

| | |
|---|---|
| Native chain | `(Z,N) -> Γ_{Z,N} -> mean(Γ) -> A_Γ -> E_Γ(Z) -> (N_low, N_high)` |
| Comparator | NUBASE2020 ground-state mass reference |
| Ordering | comparator accessed only after native band generation |
| Evaluated-experimental containment | 2549 / 2549 |
| Natural-state containment | 288 / 288 |
| Mean width ratio | 3.766 |
| Retained failures | Li-3, Be-5, B-6 (outside band) |
| Tightest cases | B 1.14, C 1.21, O 1.33, N 1.38, Mg 1.39 |

### 4.2 Atomic shell admissibility — executed

Capacity vector `[2,8,18,32,18,32,18]`, ceiling 128, domain `Z = 3..128`, 126 evaluable
states for the sign law. Falsifiable consequence: `Z ≥ 129 -> ∅`.

### 4.3 Variational field evaluator — executed, one negative

Cu–Cu positive. H–He negative control correctly rejected. H–H false negative — see §6.

### 4.4 Metrology chain — executed at declared scope

`L_A = N_A·λ_A`, `τ_A = M_A/ν_A`, `L = N_D·L_A`, `T(X) = n_Cs(X)/9,192,631,770`. The
Appendix N fixture is declared synthetic and does not calibrate a physical atomic length.

---

## 5. Not in standing

Listed explicitly so no reviewer has to discover them by inference.

| Item | Status |
|---|---|
| `N_most-stable^SEAM` | Requires separately locked native derivation |
| `N_longest-lived^SEAM` | Requires separately locked native derivation |
| R229 interior entropy binding | **Falsified.** One candidate binding; cannot be cited as a successful selector |
| Numerical bond lengths | Not claimed; no certificate binds one |
| Dissociation energies | Not claimed; no certificate binds one |
| Absolute SI force values | Not claimed except where a certificate binds them |
| Physical magnitude of `L_A` | Projection structure established; magnitude binding is separate |

R227 demonstrates that `Γ`, `W`, `W/Z`, and empirical `B/A` are not interchangeable with
the persistence selector. Empirical stability and half-life are downstream comparators, not
selector inputs.

**The absence of an unregistered numerical application does not create an unfinished
canonical claim.** These are listed as boundaries, not as debts.

---

## 6. Open foundational defect — H–H variational closure

Recorded in standing rather than only in evidence, because it bears on the molecular layer
generally.

Under canonical v18.6 (`VF-REGION-LBFGSB-R4`), H–H produces no finite entropy maximum above
the separated state:

```
S_separated / k_B        = 3.511853499981017
best overlapping S / k_B = 3.511826296100812   at N_r = 1.987866108786611
ΔS / k_B                 = −2.7203880205e−05
interior_local_maxima    : []
finite_entropy_closure   : false
comparator_accessed      : false
```

Evidence: `Evidence/B01/ADHESION_LOCKED_RUN_01/H2_native_evidence.json`.
Runtime: `Evidence/Runtime/variational_field_evaluator.py`.
Lock semantics retained: Cu–Cu positive, H–H false negative, H–He negative-control
rejection.

**Ruling:** the deficiency lies in the present relational/field admissible-state
formulation or evaluator.

**Note on the atomic-field closure.** The certified
`H2-FIRST-PRINCIPLES-ATOMIC-FIELD-CLOSURE-01` establishes admissibility by shell occupancy
arithmetic and does not invoke the entropy selector. The variational branch applies
`C* = arg max S` and returns a false negative. These answer different questions at
different scopes; neither supersedes the other. Both are retained.

---

## 7. Retained negative results

The record includes what failed. These are not concealed and are not omissions.

- **`REJECTED_H2_UNIFORM_SHELL_CONTRACT`** — uniform unit-width top-hat shell support yields
  separation-independent field entropy for disjoint balls; no interior maximum. Apparent
  peak is a plateau-edge artifact.
- **`RUN-H2-RHO-VOLUME-01`** — the fixed-support-rescaling class is rejected in full.
- **R229** — falsification of one candidate interior entropy binding.
- **Li-3, Be-5, B-6** — retained outside-band nuclear failures.
- **Radial shape sensitivity** — `RADIAL_SHAPE_SENSITIVITY_DEMONSTRATED`; linear and
  quadratic profiles give interior maxima at `N_r* = 1.6008992282173213` and
  `1.7017708805671177`, edge profile gives none. Classified noncanonical sensitivity tests,
  not canonical law.

---

## 8. Evidence and reproduction

The streamlined package carries standing and pointers. Evidence bodies are in
`Continuum_Paradigm.zip`: byte-locked runs, certification bodies, SHA-256-bound evidence
objects, comparator datasets, reproduction runtimes, retained pedigree.

Key paths:

```
Evidence/Runtime/locked_runner.py
Evidence/Runtime/variational_field_evaluator.py
Evidence/Nuclear_R226_R227/
Evidence/Locked_Runs/
Evidence/Claim_Certification/
SEAM_210_CLAIM_CERTIFICATION_REGISTER.md / .json
SEAM_50_PROJECT_CLAIM_CERTIFICATION_REGISTER.md / .json
PACKAGE_MANIFEST.json
PACKAGE_SHA256SUMS.txt
```

**Validation ladder.** Internal project certification, externally driven adversarial
adjudication, blind or prospective locks, cross-environment reproduction, and independent
reproduction are distinct evidence roles. They are credited only where the corresponding
retained record establishes them. The ladder is not flattened into one word.

**Sealed-artifact rule.** Byte-locked artifacts are immutable because their hashes are part
of the record. A sealed object may therefore contain wording reflecting an earlier
disposition. Historical words such as `OPEN` or `pending` inside a sealed object are
evidence metadata, not current standing. The active certificate and this document control.

**Surface separation.** The canonical archive is present authority. The public
pedigree/GitHub record is lineage and has no authority over current standing. The live
runner is executable demonstration, conforming only when it executes current canonical
mathematics and preserves declared evidence/order boundaries. These roles are complementary
and are not substituted for one another.

---

## 9. Falsification standing

The framework remains exposed to rejection. A valid observation-bound counterexample to a
universal canonical first principle or universal consequence, established under the
declared contract, invalidates that standing and therefore the foundational framework as
currently stated.

A bounded application or implementation failure is foundational only if traced to the
canonical mathematics rather than to contract, input, implementation, or projection error.

A standing falsifier is not an open task. It states what observation would overturn a
certified proposition if a post-completion challenge supplies it.

Repeating an already adjudicated challenge does not create a new scientific issue. The
existing certificate controls unless a new submission supplies a materially different
premise, observation, counterexample, dependency conflict, or certified scope. Novelty is
structural, not rhetorical.

---

## 10. Authority

Current standing is defined only by the active canonical build authority chain and the
active certificate and evidence records listed in the current package manifest.
Historical and pedigree material is retained for lineage and has no authority to reopen or
redefine present standing.

```
SEAM PROJECT COMPLETION: COMPLETE
```

Complete at declared scope, with §5 boundaries and the §6 defect stated on the face of the
record.
