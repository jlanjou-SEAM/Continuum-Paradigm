# R175 Expanded Claim Closure Action Matrix

## Accounting

- Existing canonical claims: **260**
- Claim 261 nuclear-isomer claim: **1**
- Top-50 anomaly claims: **50** (Claims 262–311)
- Paradox structural-evidence claims: **24** (Claims 312–335)
- Additional live-session extraction claims: **14** (Claims 336–349)
- **Total registered claims: 349**

This count intentionally preserves the Top-50 and Paradox entries as separately auditable claims even when subjects overlap. Subject overlap does not itself constitute duplicate certification because the claim contract may differ.

## Closure discipline

Every numbered claim requires a claim-specific locked scientific package containing its first-principles derivation, empirical foundations, Verification, Falsification, Prediction, exact run/evidence binding, scientific comparator, adjudication, scope, provenance and hashes. One locked run may support multiple claims only through explicit claim-specific callouts.

Automated repository triage located at least one candidate existing evidence artifact for **74 of the 88 newly enumerated Claims 262–349** and no keyword/path candidate for **14**. Candidate identification is not evidence certification; each candidate must be inspected for exact sealed-output support before reuse.

## Required execution order

1. Finish Claim 261 fixed isomer run and package.
2. Complete neutron point-selector and Z=0…130 fixed-run package already precommitted in R174.
3. Inspect candidate evidence bindings for Claims 262–349; reuse only qualifying locked outputs.
4. For every unmatched claim, precommit V/F/P and execute a new blind locked run.
5. Seal each claim-specific scientific package and only then promote its standing to CLOSED.
