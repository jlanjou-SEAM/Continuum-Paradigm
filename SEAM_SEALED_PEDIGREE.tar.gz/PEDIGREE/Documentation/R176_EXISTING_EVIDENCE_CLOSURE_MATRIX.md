# R176 Existing-Evidence Closure Matrix

Closed by exact sealed-evidence reuse: **16** claims.

| Claim | Topic | Standing |
|---:|---|---|
| 265 | Dark matter identity | CLOSED — exact bounded reuse package |
| 266 | Accelerated expansion / dark energy | CLOSED — exact bounded reuse package |
| 290 | Biological evolution | CLOSED — exact bounded reuse package |
| 296 | Nuclear isomers | CLOSED — exact bounded reuse package |
| 297 | Nuclear decay / half-life structure | CLOSED — exact bounded reuse package |
| 299 | Particle mass ontology | CLOSED — exact bounded reuse package |
| 300 | Higgs interpretation | CLOSED — exact bounded reuse package |
| 301 | Gauge-boson ontology | CLOSED — exact bounded reuse package |
| 302 | Gravity ontology | CLOSED — exact bounded reuse package |
| 304 | Orbital dynamics | CLOSED — exact bounded reuse package |
| 307 | Vacuum / zero-point interpretations | CLOSED — exact bounded reuse package |
| 310 | Physical constants / metrology primitives | CLOSED — exact bounded reuse package |
| 339 | Complete elemental electron/shell reconstruction and operator validation at its exact executed scope. | CLOSED — exact bounded reuse package |
| 341 | Signed shell-field law and architectural-domain substitution/continuation tests. | CLOSED — exact bounded reuse package |
| 343 | Mass adjudication chain at its exact executed scope. | CLOSED — exact bounded reuse package |
| 346 | Evolution as the downstream biological projection of successive entropy-selected states with retained structural history. | CLOSED — exact bounded reuse package |

All other Claims 261–349 retain their prior open/review standing unless separately closed. Candidate evidence was not promoted merely because of keyword or subject similarity.
