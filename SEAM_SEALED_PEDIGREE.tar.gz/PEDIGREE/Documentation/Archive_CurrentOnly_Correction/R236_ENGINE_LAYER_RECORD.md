# R236 — Engine-layer capability audit: Wu 1957 predictability

## Standing

`CAPABILITY_AUDIT_ONLY — NOT A BASE-MATHEMATICS RESULT, NOT A PREDICTION`

## What was done

The R27 executable path was audited blind against the Wu 1957 configuration: Co-60 in
a cerium magnesium nitrate host, polarizing solenoid reversed between two runs,
everything else held identical.

Co-60 resolves cleanly at the engine layer — `Z=27`, shell vector
`[2,8,17,0,0,0,0]`, `S_config/k_B = 2.890371757896165`,
`S_field/k_B = 4.707370687074315`, with `N=33` inside the admissible band
`7 <= N <= 54`.

The audit then returned two terminals:

```
INDETERMINATE: UNDECLARED_ORIENTATION_INPUT_FOR_CANONICAL_FIELD_CONSTRUCTOR
INDETERMINATE: NO_EXECUTABLE_CO60_BETA_ANGULAR_DISTRIBUTION_OPERATOR
```

## Why this is recorded

The diagnosis is more precise than "SEAM lacks weak-interaction physics." The
polarizing-field direction is not admitted as an input at any stage. Both experimental
cases therefore reduce to the same representable state before any downstream operator
is reached. No operator added later can distinguish inputs that were never
distinguished at entry.

The gap is therefore located at the input boundary, and it forecloses everything
downstream of it. That is a structural finding about where the missing construction
sits, and it is useful precisely because it is negative.

## Layer discipline

See `Evidence/Engine_Layer_Wu_R27/LAYER_CLASSIFICATION.md`. The runner is a capability
audit — it reads the atomic matrix as data, tests for two literal sentences in the
technical foundations, and regex-searches the runtime for eight operator terms. It is
not an execution of base mathematics and not an engine computation that attempted and
failed to distinguish two states. The reported state identity is structural in the
runner, not computed.

Citing this record as a SEAM prediction, derivation, or falsification would misstate
what it is.

## Open items created

1. Admit an orientation input to a declared field constructor, per the §4.15.4
   procedure for declaring a constructor extension.
2. Derive the sign of that orientation from the apparatus rather than assigning it.
3. Establish an executable operator taking a polarized nuclear state to an emission
   angular distribution.

`Evidence/Engine_Layer_Wu_R27/WU_PREDICTION_SEAL.md` freezes the three test
conditions in advance of any such construction.

## Scope

Additive. No sealed Evidence payload modified, no claim promoted, no claim standing
changed.
