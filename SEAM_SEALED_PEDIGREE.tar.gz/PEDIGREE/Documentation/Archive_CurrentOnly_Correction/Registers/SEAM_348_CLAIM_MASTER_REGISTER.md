# SEAM 349-Claim Master Register

R177 master register. Registered claims: **349**. Certified/closed claims: **282**. Expanded claims are closed only where claim-specific packages bind exact sealed evidence.

| # | ID | Class | Claim / domain | Standing | Candidate evidence |
|---:|---|---|---|---|---:|
|  | D-002 | D | The entropy and Xi hierarchy is the native state-selection and evolution hierarchy. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-003 | D | Interaction-to-force and transfer relations are downstream projection interfaces from resolved native structure. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-004 | D | Domain-specific observables are produced through an extensible library of declared projection operators. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-005 | D | Macroscopic attraction follows the entropy-selected structural interaction and variational-field projection path without an independent gravity primitive. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-006 | D | Propagation is state-to-state transfer through matter and structural fields under entropy-directed evolution. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-007 | D | Bulk thermodynamic observables are projections of evolving material and Manifold state. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-008 | D | Nuclear transition and decay are represented as entropy-directed restructuring or shedding followed by complete-state reevaluation. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-009 | D | Electromagnetic and electrochemical observables are transfer and structural-state projections. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-010 | D | Fluid, acoustic, and transport observables are aggregate projections of constituent transfer and Manifold evolution. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-011 | D | Reaction and molecular-transport rates are counts of resolved structural events over Cs-resolved intervals. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-012 | D | Optical, radiative, and detector response is a sequence of matter-mediated state changes. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-013 | D | Biological structure is represented through inherited blueprint, local Manifold context, available material, and Xi-directed evolution. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-014 | D | Genetics, inheritance, and evolution map to blueprint transmission, mutation, environmental realization, and differential persistence. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-015 | D | Protein folding is molecular structural resolution under the entropy and Xi architecture. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-016 | D | Population and ecological dynamics are aggregate Manifold observations of interacting entities and shared constraints. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-017 | D | Environmental and hydrologic change is evaluated through explicit boundary storage and transfer accounting. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-018 | D | Physiology, electrophysiology, and homeostasis are overlapping projections of biological state change. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-019 | D | Pharmacokinetic and pharmacodynamic behavior is a perturbation-and-observation projection of subsequent state evolution. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-020 | D | Epidemiology and diagnostics are population and sampling projections of biological state transitions. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-021 | D | Language, semantics, and translation are evaluated as explicit representational correspondences. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-022 | D | Cognition and memory are evidence-limited application domains rather than foundational primitives. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-023 | D | Semiotic and symbolic interpretation is a scoped representational correspondence requiring operational criteria for empirical use. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-024 | D | Historical causality and periodization are scoped evidence-and-model domains with explicit falsification rules. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-025 | D | Humanities interpretation is a scoped analytical domain whose empirical uses require operational definitions. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-026 | D | Normative evaluation requires an externally supplied objective and does not create an empirical truth primitive. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-027 | D | Selection among admissible states or models uses the native entropy criterion rather than a separate parsimony rule. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-028 | D | Impact, restitution, and propulsion are represented through boundary-state reconstruction and structural transfer accounting. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | D-029 | D | Empirical closure propagates the freeze-before-reveal, provenance, uncertainty, and terminal-disposition protocol to each empirical claim. | PASS — upstream SEAM mechanism explicitly answers the project claim; cited scientific closures and retained evidence instantiate that mechanism. | 0 |
|  | E-001 | E | The frozen core-operator qualification partitions all 33,200 tested substitutions into admissible closure or correct refusal without silent or inadmissible emission. | PASS — retained sealed evidence directly records the claimed execution result. | 0 |
|  | E-002 | E | The declared neutron-closure interval contains the observed neutron-state set across all 118 evaluated elements. | PASS — retained sealed evidence directly records the claimed execution result. | 0 |
|  | E-003 | E | The atomic mass adjudication covers all 118 evaluated elements with 110 measured admissions, 8 matched extrapolations, and 0 unmatched cases. | PASS — retained sealed evidence directly records the claimed execution result. | 0 |
|  | E-004 | E | Under the declared compact-support radial-profile contracts, the linear and quadratic H2 cases exhibit finite local entropy maxima and the uniform and edge cases do not. | PASS — retained sealed evidence directly records the claimed execution result. | 0 |
|  | L-001 | L | ESIH, ESAM, SEAM, Continuum, and Manifold form one dependency stack with distinct layer responsibilities; downstream layers do not redefine upstream primitives. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-002 | L | Reality is represented through continuous relational structure and traceable state transformation. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-003 | L | Fresh atomic construction begins from the electron count Z(n); other atomic coordinates are downstream state modifiers. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-004 | L | A candidate physical state is a complete declared configuration whose shell occupancies obey the seven-shell capacity architecture and count conservation. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-005 | L | The native selector chooses the admissible configuration that maximizes the declared entropy functional. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-006 | L | Physical evolution proceeds through configuration change and entropy resolution, with Xi representing the current resolved state. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-007 | L | Atomic, molecular, composite, and macroscopic interactions use one entropy-governed structural interaction architecture. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-008 | L | The signed shell-field operator is the canonical second-difference response of the declared shell-field entropy. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-009 | L | Native structural resolution precedes projection into conventional observables, equations, units, categories, or empirical comparison. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-010 | L | Time and operational distance are resolved through the declared count-based SEAM metrology before conventional-unit reporting. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-011 | L | A physically set-valued resolved state remains set-valued through evaluation and adjudication. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-012 | L | Operational closure is a composed sequence of representation, structural closure, transfer, coherence, Manifold comparison, and validation. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-013 | L | A run terminates under its declared terminal predicate and a successor run cannot rewrite the sealed result. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-014 | L | First-principle derivation and empirical confirmation are distinct stages with distinct authority. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-015 | L | No undeclared value, transform, function, default, branch, unit, scale, boundary, tolerance, or external source may enter execution implicitly. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-016 | L | A resolver may translate a supported primitive result but may not invent missing mathematics or replace a terminal refusal or indeterminate result. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | L-017 | L | An empirical SEAM claim is tested by freezing the native consequence before comparator reveal and adjudicating the result without allowing evidence to define the operator. | PASS — canonical text and retained verification evidence agree on the stated law/contract. | 0 |
|  | P-001 | P | SEAM is complete as the foundational causal and evaluator framework defined by the canonical package. | PASS — all subordinate registered claims have explicit closed standing in R164. | 0 |
|  | C-001 | C | Quarks | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-002 | C | Top quark | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-003 | C | Muons | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-004 | C | Muon neutrino | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-005 | C | Gluons | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-006 | C | W boson | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-007 | C | Z boson | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-008 | C | Higgs boson | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-009 | C | Photon | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | C-010 | C | Particle accelerator data | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-011 | C | Electric charge | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-012 | C | Particle taxonomy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-013 | C | Atomic element labels | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-014 | C | Isotope labels | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-015 | C | Ion labels | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-016 | C | Isomer labels | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-017 | C | Vacuum | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-018 | C | Vacuum energy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-019 | C | Dark matter | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-020 | C | Dark energy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-021 | C | Gravity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-022 | C | Spacetime | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-023 | C | Curvature | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-024 | C | Magnetic field | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-025 | C | Electric field | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-026 | C | Force | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-027 | C | Temperature | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-028 | C | Pressure | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-029 | C | Heat | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-030 | C | Phonon | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-031 | C | Natural selection | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-032 | C | Disease etiology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-033 | C | Pathology | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-034 | C | Epidemiologic risk | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-035 | C | Drug clearance | CLOSED — DOWNSTREAM OF LOCKED BIOLOGY EVIDENCE + SCIENTIFIC COMPARATOR | 0 |
|  | C-036 | C | Scientific disciplines | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-037 | C | Regime labels | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-038 | C | Classical vs quantum | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-039 | C | Quantum/classical transition | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-040 | C | Randomness | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-041 | C | Noise | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-042 | C | Correction terms | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-043 | C | Predictive success | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-044 | C | Hamiltonian | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-045 | C | Wavefunction | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-046 | C | Lagrangian | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-047 | C | Parsimony | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-048 | C | Empirical fit | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-049 | C | Simulation | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-050 | C | Formal closure | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-051 | C | Classification as proof | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-052 | C | Semantic labels | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-053 | C | Reference data | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-054 | C | Missing local artifact | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-055 | C | Runtime vs theory | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-056 | C | Refusal | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-057 | C | Question answerability | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-058 | C | Particle collision events | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-059 | C | Geological drivers | CLOSED — R158 GEOLOGY ONTOLOGY/PROJECTION CLOSURE | 0 |
|  | C-060 | C | Geostrophic force balance | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-061 | C | Darwinian selector | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-062 | C | Genetic blueprint | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-063 | C | Epigenetics | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-064 | C | Clinical equations | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | C-065 | C | Historical causality | CLOSED — LOCKED RUN + METHODOLOGICAL EVIDENCE | 0 |
|  | C-066 | C | Language semantics | CLOSED — LOCKED RUN + METHODOLOGICAL EVIDENCE | 0 |
|  | C-067 | C | Normative claims | CLOSED — LOCKED RUN + METHODOLOGICAL EVIDENCE | 0 |
|  | C-068 | C | Cognition | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | C-069 | C | RF anomaly | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | C-070 | C | Sensor anomaly | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-001 | O | Newtonian gravity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-002 | O | Schwarzschild geometry | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-003 | O | Riemann curvature | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-004 | O | Mercury perihelion | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-005 | O | Gravitational lensing | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-006 | O | Gravitational redshift | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-007 | O | Shapiro delay | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-008 | O | Geodetic precession | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-009 | O | Orbital mechanics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-010 | O | Fermat principle | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-011 | O | Refractive index | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-012 | O | Snell / refraction | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-013 | O | Dispersion | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-014 | O | Cherenkov radiation | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-015 | O | Spectra | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-016 | O | Attenuation | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-017 | O | Radiative intensity | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-018 | O | Vacuum Hamiltonian | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-019 | O | Hamiltonian correspondence | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-020 | O | Wave equations | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-021 | O | Fixed c | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | O-022 | O | Debye T^3 law | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-023 | O | Curie-Weiss law | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-024 | O | Temperature | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-025 | O | Pressure | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-026 | O | Heat flow | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-027 | O | Material energy balance | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-028 | O | Cyclotron frequency | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-029 | O | Electric charge relation | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-030 | O | Voltage | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-031 | O | Current | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-032 | O | Nernst equation | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-033 | O | Goldman-Hodgkin-Katz | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-034 | O | Ohmic membrane current | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-035 | O | Navier-Stokes | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-036 | O | Reynolds number | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-037 | O | Fick diffusion | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-038 | O | Poiseuille flow | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-039 | O | Continuity equation | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-040 | O | Geostrophic flow | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-041 | O | Ekman transport | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-042 | O | Plate tectonics | CLOSED — R158 GEOLOGY ONTOLOGY/PROJECTION CLOSURE | 0 |
|  | O-043 | O | Mass action | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-044 | O | Polymerization mass balance | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-045 | O | Radioactive decay law | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-046 | O | Half-life | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-047 | O | Decay branching | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-048 | O | Mass defect / binding energy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-049 | O | H2 bond profile | CLOSED WITHIN DECLARED RUN CONTRACT | 0 |
|  | O-050 | O | Classical force curve | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-051 | O | Electron affinity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-052 | O | Periodic-table trends | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-053 | O | Hardy-Weinberg | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-054 | O | Mendelian ratios | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-055 | O | Natural-selection statistics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-056 | O | Population growth | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-057 | O | Lotka-Volterra | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-058 | O | Protein folding equilibrium | CLOSED — DOWNSTREAM OF LOCKED BIOLOGY EVIDENCE + SCIENTIFIC COMPARATOR | 0 |
|  | O-059 | O | Pharmacokinetic clearance | CLOSED — DOWNSTREAM OF LOCKED BIOLOGY EVIDENCE + SCIENTIFIC COMPARATOR | 0 |
|  | O-060 | O | One-compartment PK | CLOSED — DOWNSTREAM OF LOCKED BIOLOGY EVIDENCE + SCIENTIFIC COMPARATOR | 0 |
|  | O-061 | O | LD50 / toxicity curves | CLOSED — DOWNSTREAM OF LOCKED BIOLOGY EVIDENCE + SCIENTIFIC COMPARATOR | 0 |
|  | O-062 | O | Epidemiology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-063 | O | Diagnostics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-064 | O | Sensor logs | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-065 | O | RF mapping | CLOSED — R157 RF STRUCTURAL PROJECTION | 0 |
|  | O-066 | O | Environmental field anomalies | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-067 | O | Lunar DEM | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-068 | O | Solar-system count | CLOSED — R159 LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | O-069 | O | N-body simulation | CLOSED — DOWNSTREAM OF LOCKED ORIGIN EVIDENCE | 0 |
|  | O-070 | O | Model residuals | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-001 | S | Gravity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-002 | S | Gravity / GR | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-003 | S | Gravity / Newtonian | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-004 | S | Gravity / scale | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-005 | S | Vacuum | CLOSED — R151 EXACT-SCOPE OPTICS RECONCILIATION | 0 |
|  | S-006 | S | Light / propagation | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | S-007 | S | Light / c | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | S-008 | S | Photon ontology | CLOSED — R154 FORMAL STRUCTURAL CLOSURE | 0 |
|  | S-009 | S | Electromagnetism | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-010 | S | Magnetism | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-011 | S | Electrochemistry | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-012 | S | Atomic ontology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-013 | S | Atomic identity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-014 | S | Shell structure | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-015 | S | Neutron state | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-016 | S | Mass | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-017 | S | Isotope ontology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-018 | S | Ions | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-019 | S | Isomers | CLOSED — LOCKED RUN + SCIENTIFIC/METHODOLOGICAL EVIDENCE | 0 |
|  | S-020 | S | Nuclear decay | CLOSED — R156 NUCLEAR ONTOLOGY/MECHANISM CLOSURE | 0 |
|  | S-021 | S | Nuclear interaction | CLOSED — R156 NUCLEAR ONTOLOGY/MECHANISM CLOSURE | 0 |
|  | S-022 | S | Chemical bonding | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-023 | S | Molecular scale | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-024 | S | Protein folding | CLOSED — DOWNSTREAM OF LOCKED BIOLOGY EVIDENCE + SCIENTIFIC COMPARATOR | 0 |
|  | S-025 | S | Biology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-026 | S | Genetics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-027 | S | Evolution | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-028 | S | Disease | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-029 | S | Pathogenesis | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-030 | S | Pharmacology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-031 | S | Thermodynamics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-032 | S | Thermodynamics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-033 | S | Thermodynamics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-034 | S | Phonons | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-035 | S | Acoustics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-036 | S | Vibration | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-037 | S | Fluids | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-038 | S | Diffusion | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-039 | S | Viscosity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-040 | S | Reaction kinetics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-041 | S | Optics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-042 | S | Fields | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-043 | S | Time | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-044 | S | Space / distance | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-045 | S | Regimes | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-046 | S | Force taxonomy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-047 | S | Dark matter | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-048 | S | Dark energy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-049 | S | Vacuum energy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-050 | S | Quantum mechanics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-051 | S | Hamiltonian ontology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-052 | S | QFT ontology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-053 | S | Particle taxonomy | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-054 | S | Quarks | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-055 | S | Muons | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-056 | S | Gluons | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-057 | S | W/Z bosons | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-058 | S | Higgs | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-059 | S | Neutrinos | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-060 | S | Cosmology | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-061 | S | Geology | CLOSED — R158 GEOLOGY ONTOLOGY/PROJECTION CLOSURE | 0 |
|  | S-062 | S | Ocean/atmosphere dynamics | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-063 | S | Environmental systems | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-064 | S | Cognition / memory | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-065 | S | Information continuity | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-066 | S | Noise | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-067 | S | Electrolysis / electrochemistry | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-068 | S | Environmental sensing | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-069 | S | Planetary system | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-070 | S | Lunar / terrain structure | CLOSED — LOCKED RUN + SCIENTIFIC EVIDENCE | 0 |
|  | S-071 | S | Fixed-count nuclear isomer pairs are natively structurally distinguishable when their complete retained relational states differ. | CLOSED — R219 SCOPE CORRECTION / R179 D_iso > 0 | 1 |
| 262 | X-262 | X | Big Bang initial-state ontology | CLOSED — R181 causal-boundary adjudication | 8 |
| 263 | X-263 | X | Inflation / early-universe expansion | CLOSED — R181 forward successor chain; no numerical inflation parameter claimed | 8 |
| 264 | X-264 | X | Hubble tension / expansion-rate discrepancy | CLOSED — R184 structural projection-discrepancy lock | 8 |
| 265 | X-265 | X | Dark matter identity | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 266 | X-266 | X | Accelerated expansion / dark energy | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 267 | X-267 | X | Matter–antimatter asymmetry | CLOSED — R185 closure-space premise adjudication | 8 |
| 268 | X-268 | X | Neutrino mass | CLOSED — R218 NO INDEPENDENT NEUTRINO ENTITY; MASS-SENSITIVE OBSERVATIONS RETAINED AS DOWNSTREAM SOURCE/FIELD/RECEIVER PROJECTION OBLIGATION; NO NUMERICAL MASS CLAIMED | 8 |
| 269 | X-269 | X | Neutrino mass ordering | CLOSED — R218 NO THREE INDEPENDENT SEAM NEUTRINO ENTITY MASSES PROMOTED; MEASURED ORDERING RELATIONS RETAINED AS DOWNSTREAM FIELD/RECEIVER PROJECTIONS | 8 |
| 270 | X-270 | X | Dirac vs Majorana neutrino identity | CLOSED — R218 DICHOTOMY NOT NATIVE WITHOUT INDEPENDENT NEUTRINO ENTITY/ANTIENTITY STRUCTURE; ANY EMPIRICAL DISCRIMINATOR REMAINS BINDING | 8 |
| 271 | X-271 | X | Quantum measurement problem | CLOSED — R190 PREMISE/MECHANISM | 8 | — CLOSED R190 PREMISE/MECHANISM
| 272 | X-272 | X | Born rule | CLOSED — R193 FIELD-INTENSITY PROJECTION ADJUDICATION | 8 |
| 273 | X-273 | X | Wave–particle duality | CLOSED — R194 DUAL-PROOF COMPLETE | 8 |
| 274 | X-274 | X | Double-slit interference and associated paradox | CLOSED — R191–R194 STRUCTURAL-ORIGIN CHAIN; COMBINED SCOPE | 8 |
| 275 | X-275 | X | EPR correlations | CLOSED — R204 EVIDENTIARY SCOPE: CORRELATION OBSERVED; PROPOSED NONLOCAL STRUCTURED EVENT NOT OBSERVED AS A STRUCTURAL EVENT | 8 |
| 276 | X-276 | X | Bell correlations | CLOSED — R204 EVIDENTIARY SCOPE: BELL CORRELATION OBSERVED; PROPOSED NONLOCAL STRUCTURED EVENT NOT OBSERVED AS A STRUCTURAL EVENT | 8 |
| 277 | X-277 | X | Delayed-choice experiments | CLOSED — R205 NOW-TO-NOW FIELD-TRANSFER REPLAY; NO RETROCAUSAL OR PHOTON OBJECT REQUIRED | 8 |
| 278 | X-278 | X | Quantum eraser | CLOSED — R207 EMPIRICAL COINCIDENCE CORRELATIONS RETAINED; NO STRUCTURAL EVIDENCE OF RETROACTIVE ERASURE OR ALTERATION OF EARLIER EVENT | 8 |
| 279 | X-279 | X | Quantum gravity | UPHELD — R208–R210 TESTED GRAVITATIONAL PROJECTION STRUCTURALLY INDISTINGUISHABLE; SEAM USES UNIFIED FIELD/MANIFOLD METHOD ACROSS FIELD-FORCE REGIMES | 8 |
| 280 | X-280 | X | Black-hole singularity | CLOSED — R214 CURRENT STANDING; STRUCTURALLY REPRESENTABLE AS INFINITE COMPRESSION; R212 HARD-STOP SUPERSEDED | 1 |
| 281 | X-281 | X | Black-hole information problem | CLOSED/REPEAT — EXISTING RESULT; INFORMATION RETAINED UNDER SINGULAR COMPRESSION, NOT DESTROYED | 8 |
| 282 | X-282 | X | Hawking radiation interpretation | REPEAT/APPLICATION — EXISTING TRANSITION -> SHED/RELEASE -> FIELD-TRANSFER MECHANISM; NO NEW PRIMITIVE | 8 |
| 283 | X-283 | X | Renormalization | CLOSED — DOWNSTREAM MATHEMATICAL/PROJECTION PROCEDURE; NOT A DISTINCT PHYSICAL SEAM OPERATION | 1 |
| 284 | X-284 | X | Hierarchy problem | CLOSED — R217 NOT A NATIVE SEAM STRUCTURAL PROBLEM; HIGGS PARAMETER HIERARCHY REMAINS DOWNSTREAM FORMALISM | 7 |
| 285 | X-285 | X | Fine tuning / free parameters | CLOSED — R217 FITTED PARAMETER SENSITIVITY DOES NOT GENERATE PHYSICAL TUNING OPERATION | 8 |
| 286 | X-286 | X | Cosmological constant problem | CLOSED — R217 EXPANSION RETAINED; COSMOLOGICAL CONSTANT REMAINS DOWNSTREAM PROJECTION NOT NATIVE ENTITY | 8 |
| 287 | X-287 | X | Arrow of time | MAPPED — CANONICAL SUCCESSOR/TIME ARCHITECTURE; NO NEW PHYSICAL PRIMITIVE | 8 |
| 288 | X-288 | X | Entropy and irreversibility | MAPPED — EXISTING ENTROPY/DIFFUSION/COMPLETE-EVENT LOCKS; NO NEW PRIMITIVE | 8 |
| 289 | X-289 | X | Origin of life / abiogenesis | MAPPED — EXISTING PREBIOLOGICAL PERSISTENCE/FULL-LIFECYCLE EVIDENCE; NO NEW PRIMITIVE | 8 |
| 290 | X-290 | X | Biological evolution | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 291 | X-291 | X | Consciousness / measurement claims | MAPPED — MEASUREMENT REQUIRES NO CONSCIOUSNESS-SPECIFIC OPERATOR; CONSCIOUSNESS ONTOLOGY NOT ESTABLISHED BY MEASUREMENT | 8 |
| 292 | X-292 | X | Turbulence | MAPPED — EXISTING FLUID AGGREGATE-TRANSFER LOCK; TURBULENCE-SPECIFIC QUANTITATIVE PROJECTION NOT CLAIMED | 3 |
| 293 | X-293 | X | High-temperature superconductivity | CLOSED — R213 STRUCTURAL EXISTENCE / MECHANISM-CLASS; COMPLETE MATERIAL STATE, NO NEW SEAM PRIMITIVE; QUANTITATIVE Tc/MICROSCOPIC CAUSE NOT CLAIMED | 1 |
| 294 | X-294 | X | Superconducting mechanism generally | MAPPED/APPLICATION — R213 + EXISTING COMPLETE-MATERIAL-STATE MECHANISM; NO NEW SUPERCONDUCTIVITY PRIMITIVE | 8 |
| 295 | X-295 | X | Nuclear stability / isotope selection | MAPPED — EXISTING NUCLEAR STABILITY/SELECTOR EVIDENCE; NO NEW RUN | 8 |
| 296 | X-296 | X | Nuclear isomers | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 297 | X-297 | X | Nuclear decay / half-life structure | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 298 | X-298 | X | Strong-force confinement ontology | MAPPED — EXISTING CONFINEMENT/ENTROPY EVIDENCE; NO NEW PRIMITIVE | 8 |
| 299 | X-299 | X | Particle mass ontology | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 300 | X-300 | X | Higgs interpretation | CLOSED — R217 DUAL-PROOF REPAIRED AT REGISTERED INTERPRETATION SCOPE | 8 |
| 301 | X-301 | X | Gauge-boson ontology | CLOSED — R217 DUAL-PROOF REPAIRED AT REGISTERED W/Z ONTOLOGY SCOPE | 4 |
| 302 | X-302 | X | Gravity ontology | MAPPED — EXISTING GRAVITY/FIELD CLOSURES INCLUDING R208–R211; NO NEW RUN | 8 |
| 303 | X-303 | X | Equivalence / inertial-gravitational behavior | MAPPED — EXISTING MASS/WEIGHT/FIELD EVIDENCE; NO NEW RUN | 8 |
| 304 | X-304 | X | Orbital dynamics | MAPPED — EXISTING ORBITAL LOCKS INCLUDING R209–R210; NO NEW RUN | 8 |
| 305 | X-305 | X | Galaxy rotation | MAPPED WITH BOUNDARY — R182/R183 STRUCTURAL ROTATION DISCRIMINATORS; SPECIFIC GALAXY ROTATION CURVE NOT CLAIMED | 8 |
| 306 | X-306 | X | Large-scale structure formation | MAPPED WITH BOUNDARY — EXISTING FORMATION/CROSS-SCALE CONTINUITY EVIDENCE; SPECIFIC COSMOLOGICAL STRUCTURE HISTORY NOT CLAIMED | 8 |
| 307 | X-307 | X | Vacuum / zero-point interpretations | MAPPED/PROJECTION — VACUUM/ZERO-POINT LABEL DOES NOT ADD A SEAM PHYSICAL PRIMITIVE | 8 |
| 308 | X-308 | X | Casimir effect | CLOSED STRUCTURAL MECHANISM — R217 BOUNDARY-CONDITIONED FIELD SELECTION + HAMILTONIAN FORCE PROJECTION; NUMERICAL COEFFICIENT UNCLAIMED | 8 |
| 309 | X-309 | X | Entanglement nonlocality claims | MAPPED — R197–R204 ONTOLOGY/EVIDENCE CHAIN; NO NEW RUN | 0 |
| 310 | X-310 | X | Physical constants / metrology primitives | MAPPED — CANONICAL CS-133 TIME-FIRST METROLOGY / NATIVE COUNT PRIMITIVES | 8 |
| 311 | X-311 | X | Emergence and cross-scale continuity | MAPPED — EXISTING CROSS-SCALE CONTINUITY/ONE-LAW EVIDENCE; NO NEW PRIMITIVE | 8 |
| 312 | X-312 | X | Schrödinger’s cat | MAPPED — R197/R198 + R190 MEASUREMENT PREREQUISITE; NO NEW RUN | 8 |
| 313 | X-313 | X | Tree falls in a forest | MAPPED — OBSERVATION DOES NOT CREATE STRUCTURE; NO NEW PHYSICAL PRIMITIVE | 8 |
| 314 | X-314 | X | Wigner’s friend | MAPPED — R197/R198 + R190 MEASUREMENT PREREQUISITE; NO NEW RUN | 0 |
| 316 | X-316 | X | EPR | DUPLICATE/MAPPED — X-275 / R199–R204 | 8 |
| 317 | X-317 | X | Bell correlations | DUPLICATE/MAPPED — X-276 / R203–R204 | 8 |
| 318 | X-318 | X | Delayed choice | DUPLICATE/MAPPED — X-277 / R205–R206 | 8 |
| 319 | X-319 | X | Quantum eraser | DUPLICATE/MAPPED — X-278 / R207 | 8 |
| 320 | X-320 | X | Wave–particle duality | DUPLICATE/MAPPED — X-273 / R194 | 8 |
| 321 | X-321 | X | Measurement problem | DUPLICATE/MAPPED — X-271 / R190 | 8 |
| 322 | X-322 | X | Twin paradox | R215 CLOSED — CLOSED — STRUCTURAL PARADOX RESOLVED; QUANTITATIVE RELATIVISTIC COUNT DIFFERENCE NOT DERIVED | 1 |
| 323 | X-323 | X | Black-hole information paradox | DUPLICATE/MAPPED — X-281; INFORMATION RETAINED UNDER COMPRESSION | 8 |
| 324 | X-324 | X | Maxwell’s demon | MAPPED — COMPLETE EVENT/ENTROPY ACCOUNTING; DEMON LABEL ADDS NO NEW OPERATOR | 8 |
| 325 | X-325 | X | Loschmidt paradox | R215 CLOSED — CLOSED — NO REVERSAL CONTRADICTION IN COMPLETE RETAINED-HISTORY STATE | 1 |
| 326 | X-326 | X | Poincaré recurrence | MAPPED — RETAINED-HISTORY SUCCESSOR STATE PREVENTS LABEL-ONLY RECURRENCE FROM BEING COMPLETE-STATE IDENTITY | 8 |
| 327 | X-327 | X | Fermi paradox | R215 CLOSED — CLOSED AS INFERENCE ERROR / NOT A PHYSICAL CONTRADICTION | 1 |
| 328 | X-328 | X | Olbers’ paradox | R215 CLOSED — CLOSED AS PREMISE/PROJECTION CONTRADICTION, NOT NEW PHYSICAL MECHANISM | 1 |
| 329 | X-329 | X | Ship of Theseus | MAPPED — ENTITY IDENTITY IS COMPLETE RETAINED STRUCTURE/HISTORY, NOT NAME OR MATERIAL COUNT ALONE | 8 |
| 330 | X-330 | X | Grandfather paradox | R215 CLOSED — CLOSED — PROPOSED HISTORY IS NOT AN ADMISSIBLE SEAM SUCCESSOR CHAIN | 1 |
| 331 | X-331 | X | Bootstrap paradox | R215 CLOSED — CLOSED — CLOSED SELF-ORIGINATING CAUSAL LOOP IS NOT A CANONICAL SUCCESSOR CHAIN | 1 |
| 332 | X-332 | X | Zeno paradoxes | R215 CLOSED — CLOSED — MATHEMATICAL SUBDIVISION IS NOT PHYSICAL SUCCESSOR MULTIPLICATION | 1 |
| 333 | X-333 | X | Liar paradox | NONPHYSICAL/FORMAL — SELF-REFERENTIAL PROPOSITION, NOT A PHYSICAL SEAM STATE | 8 |
| 334 | X-334 | X | Russell’s paradox | R215 NONPHYSICAL — REMOVED FROM PHYSICAL LOCKED-RUN QUEUE — FORMAL SET-CONSTRUCTION ISSUE | 1 |
| 335 | X-335 | X | Sorites paradox | R215 NONPHYSICAL — REMOVED FROM PHYSICAL LOCKED-RUN QUEUE — SEMANTIC CLASSIFICATION ISSUE | 1 |
| 336 | X-336 | X | PNE invariance / same-count discriminator limitation and the demonstrated need to retain relational state. | MAPPED — EXISTING SAME-COUNT RELATIONAL-STATE DISCRIMINATION EVIDENCE | 8 |
| 337 | X-337 | X | Excitation/retained structural state as an independent discriminator where primitive counts coincide. | MAPPED — EXISTING EXCITATION/RETAINED-STATE DISCRIMINATION EVIDENCE | 8 |
| 338 | X-338 | X | Charge-state structural discrimination (including H+, H, H− where supported by the archive). | MAPPED — EXISTING CHARGE-STATE STRUCTURAL DISCRIMINATION EVIDENCE | 8 |
| 339 | X-339 | X | Complete elemental electron/shell reconstruction and operator validation at its exact executed scope. | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 340 | X-340 | X | Shell-closure ionization signature at its exact executed scope. | MAPPED — EXISTING SHELL-CLOSURE/IONIZATION EVIDENCE; NO NEW RUN | 8 |
| 341 | X-341 | X | Signed shell-field law and architectural-domain substitution/continuation tests. | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 342 | X-342 | X | Neutron admissible-set containment and the new point-selector extension after the R174 fixed run. | MAPPED — EXISTING NEUTRON ADMISSIBLE-SET/POINT-SELECTOR EVIDENCE | 8 |
| 343 | X-343 | X | Mass adjudication chain at its exact executed scope. | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 344 | X-344 | X | Failed proposed scalar constructions retained as negative evidence; reclassify only after checking whether the underlying SEAM first-principles question was actually executed. | MAPPED AS NEGATIVE EVIDENCE — FAILED SCALAR CONSTRUCTIONS RETAINED; NO AUTOMATIC POSITIVE CLOSURE | 8 |
| 345 | X-345 | X | Autogenous biological organization/life result at its executed scope. | MAPPED — EXISTING PREBIOLOGICAL/AUTOGENOUS LIFE-BASIN EVIDENCE | 8 |
| 346 | X-346 | X | Evolution as the downstream biological projection of successive entropy-selected states with retained structural history. | CLOSED — CLAIM-SPECIFIC SEALED EVIDENCE PACKAGE ALREADY COMPLETE | 8 |
| 347 | X-347 | X | Environmental/Manifold perturbation changing admissible successor structure and downstream cellular-growth projection. | CLOSED — EXISTING SEALED EVIDENCE REUSED; CLAIM-SPECIFIC PACKAGE COMPLETE | 8 |
| 348 | X-348 | X | Cross-regime recoverability: one event recoverable from structurally continuous measurements outside its conventional measurement regime. | MAPPED — R166 ONE-LAW/CROSS-REGIME CONTINUITY EVIDENCE; NO NEW RUN | 8 |


### R206 standing clarification — X-277
CLOSED at structural/mechanism and empirical-consistency scope. First divergence is retrospective wave/particle history assignment, not the observed open/closed detector behavior.

### R208 standing clarification — X-279
DERIVATION DISCRIMINATOR CLOSED: 88/88 canonical Z=1..88 elemental cases preserve the SEAM exterior inverse-square exponent; QG-EFT and SEAM agree at leading radial order and differ beyond leading order. Empirical adjudication of the QG-specific correction remains a separate evidence question.


### R209 annotation — X-279
R209 executes the canonical long-range finite-body operator simultaneously for N+1 through N+5 primary bodies over 100 B1 revolutions, with a B3 satellite and retrograde B4. All retained structures remain bound. Current long-range authority remains pair-summed; no irreducible many-body term is emitted. This is a structural-survival result and discriminator, not final X-279 closure.

### R210 correction and test — X-279
R210 supersedes the R209 causal interpretation that the SEAM engine itself was established to be pair-summed. R209's numerical survival record remains evidence, but SEAM resolves the complete embedded Manifold state and the pair-force expression may be a projection of that complete-state resolution. R210 executes the conventional low-energy quantum-gravity EFT static-potential correction on the identical N+1 through N+5 / 100-revolution configuration. All 18 tracked projections remain closed, including the B3 satellite and retrograde B4. At the one-AU reference scale the genuine hbar-dependent correction is approximately 1.52e-92 of the leading potential and is not numerically resolvable in the orbital trajectory. X-279 therefore has a positive low-energy EFT projection-closure result, while complete quantum-gravity N-body ontology remains outside what this EFT run establishes.


### R211 final standing — X-279
R211 closes the R208–R210 comparison. Within the tested exterior and N+1 through N+5 / 100-revolution gravitational projection, no structural effect distinguishes the executable low-energy quantum-gravity/GR-EFT description from the SEAM gravitational projection. The specifically hbar-dependent EFT correction is not resolved at the tested planetary scale and is therefore retained as an untested higher-order prediction, not treated as a demonstrated structural difference. X-279 is UPHELD within tested gravitational scope. The documented methodological distinction is scope: the tested QG/GR-EFT formalism is gravity-specific, whereas SEAM obtains the gravitational projection through the same unified Manifold/field-resolution method used across its field-force regimes. This does not establish that quantum gravity is false, nor that its unresolved correction is absent.
