# R177 Existing-Evidence Closure Matrix

Total expanded claims closed by exact sealed-evidence reuse: **22**.

Second-pass additions: **6**.

| Claim | Topic | Standing |
|---:|---|---|
| 265 | Dark matter identity | CLOSED — claim-specific package |
| 266 | Accelerated expansion / dark energy | CLOSED — claim-specific package |
| 273 | Wave–particle duality | CLOSED — claim-specific package |
| 276 | Bell correlations | CLOSED — claim-specific package |
| 290 | Biological evolution | CLOSED — claim-specific package |
| 296 | Nuclear isomers | CLOSED — claim-specific package |
| 297 | Nuclear decay / half-life structure | CLOSED — claim-specific package |
| 299 | Particle mass ontology | CLOSED — claim-specific package |
| 300 | Higgs interpretation | CLOSED — claim-specific package |
| 301 | Gauge-boson ontology | CLOSED — claim-specific package |
| 302 | Gravity ontology | CLOSED — claim-specific package |
| 304 | Orbital dynamics | CLOSED — claim-specific package |
| 307 | Vacuum / zero-point interpretations | CLOSED — claim-specific package |
| 310 | Physical constants / metrology primitives | CLOSED — claim-specific package |
| 315 | Double slit | CLOSED — claim-specific package |
| 317 | Bell correlations | CLOSED — claim-specific package |
| 339 | Complete elemental electron/shell reconstruction and operator validation at its exact executed scope. | CLOSED — claim-specific package |
| 341 | Signed shell-field law and architectural-domain substitution/continuation tests. | CLOSED — claim-specific package |
| 343 | Mass adjudication chain at its exact executed scope. | CLOSED — claim-specific package |
| 346 | Evolution as the downstream biological projection of successive entropy-selected states with retained structural history. | CLOSED — claim-specific package |
| 347 | Environmental/Manifold perturbation changing admissible successor structure and downstream cellular-growth projection. | CLOSED — claim-specific package |

No remaining claim is promoted by keyword similarity alone.
