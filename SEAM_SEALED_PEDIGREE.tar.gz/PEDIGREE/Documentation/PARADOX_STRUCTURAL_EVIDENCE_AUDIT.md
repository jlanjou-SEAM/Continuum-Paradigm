# Paradoxes — Structural Evidence Audit

The entries remain under the historical **Paradoxes** category, but the audit asks whether each is actually paradoxical once the complete structure is resolved. The governing rule is **structure first; observation is evidence, not cause**. A paradox is not accepted merely because an observation plus an unsupported assumption appears contradictory.

Every physical entry must ultimately contain: native structural statement; Verification; Falsification; Prediction; empirical evidence/citation; and final disposition as paradox or resolved physical event.

| # | Item | Type | SEAM audit statement |
|---:|---|---|---|
| 1 | Schrödinger’s cat | Thought experiment | ABSOLUTE GARBAGE — epistemic uncertainty is not physical state creation. An entity exists by its complete structure; observation supplies evidence of state, not state itself. |
| 2 | Tree falls in a forest | Philosophical thought experiment | Physical event and its structural consequences occur independently of a human observer; evidence may persist in surrounding structures. |
| 3 | Wigner’s friend | Thought experiment | Audit observer-dependent knowledge versus observer-independent complete structure. |
| 4 | Double slit | Canonical experiment | Retain measured interference; test the structural interaction that produces the fringe relation without promoting the observation label to ontology. |
| 5 | EPR | Canonical thought experiment / experiment family | Audit whether the apparent paradox is introduced by assumed primitive state ontology rather than measured correlations. |
| 6 | Bell correlations | Canonical experiment family | Retain measured correlations and separately test structural interpretation. |
| 7 | Delayed choice | Canonical experiment | Separate later measurement choice from prior physical existence of complete structure. |
| 8 | Quantum eraser | Canonical experiment | Separate information availability/projection from physical creation or retroactive alteration of structure. |
| 9 | Wave–particle duality | Interpretive paradox | Test whether one complete structure can produce different downstream projections without dual primitive ontologies. |
| 10 | Measurement problem | Interpretive paradox | State resolution is structural; measurement is an evidence/projection interface. |
| 11 | Twin paradox | Relativity thought experiment | Recover physical trajectory/clock-history structure and compare accumulated count/time projection. |
| 12 | Black-hole information paradox | Theoretical paradox | Audit whether information loss follows from structural evolution or from the chosen projection/ontology. |
| 13 | Maxwell’s demon | Thermodynamic thought experiment | Include demon/memory/measurement/erasure in the complete state and entropy accounting. |
| 14 | Loschmidt paradox | Thermodynamic paradox | Audit microscopic reversibility assumption against complete retained-history state and entropy-selected succession. |
| 15 | Poincaré recurrence | Statistical-mechanical paradox | Distinguish mathematical recurrence conditions from physical complete-state accessibility. |
| 16 | Fermi paradox | Observational inference paradox | Separate absence of detected evidence from proof of nonexistence. |
| 17 | Olbers’ paradox | Cosmological paradox | Resolve from complete source/propagation/history structure rather than static infinite-universe assumptions. |
| 18 | Ship of Theseus | Identity thought experiment | Define identity by retained structural continuity rather than labels or material-token count alone. |
| 19 | Grandfather paradox | Causal thought experiment | Audit admissibility of the proposed complete history before treating contradiction as a physical state. |
| 20 | Bootstrap paradox | Causal thought experiment | Audit whether the proposed closed causal history is structurally admissible. |
| 21 | Zeno paradoxes | Kinematic thought experiments | Distinguish mathematical subdivision from the resolved physical trajectory/count process. |
| 22 | Liar paradox | Logic paradox | Nonphysical reference/self-reference audit; do not treat as a physical ontology problem. |
| 23 | Russell’s paradox | Set-theory paradox | Formal-language/set-construction issue; not a physical-state paradox. |
| 24 | Sorites paradox | Semantic paradox | Classification-boundary issue; structural state does not depend on vague naming threshold. |
