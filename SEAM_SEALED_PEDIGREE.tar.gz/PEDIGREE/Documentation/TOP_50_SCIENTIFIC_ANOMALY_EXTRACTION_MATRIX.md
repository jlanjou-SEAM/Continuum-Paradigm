# Top-50 Scientific Anomaly Benchmark — Extraction / Elevation Matrix

Purpose: recover existing SEAM resolutions, mathematics, locked runs and negative evidence. **Not yet extracted does not mean not addressed.** Each recovered item must be rewritten under the Verification / Falsification / Prediction precommitment rule.

| # | Topic | Action |
|---:|---|---|
| 1 | Big Bang initial-state ontology | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 2 | Inflation / early-universe expansion | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 3 | Hubble tension / expansion-rate discrepancy | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 4 | Dark matter identity | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 5 | Accelerated expansion / dark energy | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 6 | Matter–antimatter asymmetry | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 7 | Neutrino mass | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 8 | Neutrino mass ordering | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 9 | Dirac vs Majorana neutrino identity | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 10 | Quantum measurement problem | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 11 | Born rule | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 12 | Wave–particle duality | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 13 | Double-slit interference | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 14 | EPR correlations | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 15 | Bell correlations | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 16 | Delayed-choice experiments | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 17 | Quantum eraser | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 18 | Quantum gravity | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 19 | Black-hole singularity | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 20 | Black-hole information problem | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 21 | Hawking radiation interpretation | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 22 | Renormalization | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 23 | Hierarchy problem | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 24 | Fine tuning / free parameters | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 25 | Cosmological constant problem | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 26 | Arrow of time | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 27 | Entropy and irreversibility | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 28 | Origin of life / abiogenesis | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 29 | Biological evolution | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 30 | Consciousness / measurement claims | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 31 | Turbulence | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 32 | High-temperature superconductivity | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 33 | Superconducting mechanism generally | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 34 | Nuclear stability / isotope selection | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 35 | Nuclear isomers | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 36 | Nuclear decay / half-life structure | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 37 | Strong-force confinement ontology | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 38 | Particle mass ontology | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 39 | Higgs interpretation | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 40 | Gauge-boson ontology | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 41 | Gravity ontology | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 42 | Equivalence / inertial-gravitational behavior | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 43 | Orbital dynamics | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 44 | Galaxy rotation | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 45 | Large-scale structure formation | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 46 | Vacuum / zero-point interpretations | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 47 | Casimir effect | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 48 | Entanglement nonlocality claims | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 49 | Physical constants / metrology primitives | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
| 50 | Emergence and cross-scale continuity | Search archive; bind existing resolution/run; identify exact scope; elevate only what evidence supports |
