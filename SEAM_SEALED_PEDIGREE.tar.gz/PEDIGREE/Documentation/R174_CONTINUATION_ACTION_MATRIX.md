# R174 Continuation Action Matrix

This file carries the decisions made in the 2026-09-12 live continuation into the fixed-run repository. It distinguishes documentation changes from evidence that still requires execution.

| Item | Repository action | Standing after this update |
|---|---|---|
| Claim methodology | Add mandatory Verification / Falsification / Prediction precommitment to every claim | DOCUMENTED |
| First-principles discipline | State empirically derived first principles + blind adjudication against withheld target answers | DOCUMENTED |
| Neutron range | Preserve `N_low..N_high` as set-valued admissibility result | PRESERVED |
| Most stable neutron count | Add explicit entropy-selected integer `N_stable` | FORMALIZED; RUN REQUIRED |
| Longest-lived neutron count | Add explicit persistence-question entropy-selected integer `N_long` | FORMALIZED; RUN REQUIRED |
| Z sweep | Expand falsification domain to integer Z=0..130 inclusive, retaining rejects and ionic contributions | CONTRACTED; RUN REQUIRED |
| Claim 261 | Nuclear isomer-pair structural discrimination with quantitative `D_iso` | PRECOMMITTED; RUN REQUIRED |
| Claims 262+ | Mine prior executed results and elevate unique claims without suppressing negative runs | EXTRACTION QUEUE |
| Failed constructions | Preserve as evidence-chain stages; do not mislabel an unasked SEAM question as a paradigm falsification | METHODOLOGY ANNOTATED |
| Autogenous life | Elevate existing biology result and retained-history/entropy successor rule | EXTRACTION QUEUE |
| Evolution | Record as downstream biological projection of successive entropy-selected retained-history states | EXTRACTION QUEUE |
| Environmental/manifold perturbation | Elevate differential successor/growth result under changed admissible state | EXTRACTION QUEUE |
| Cross-regime recoverability | Elevate event reconstruction from measurements outside the conventional regime | EXTRACTION QUEUE |
| HIGHPOINT | Tag as cross-orbital structural derivation: measurements associated with one orbital body used in derivation concerning another | EXTRACTION / EVIDENCE-BINDING REVIEW |
| Top-50 anomalies | Treat as extraction/elevation benchmark, not an assertion that SEAM has not addressed them | QUEUED |
| Paradoxes | Create resolved-paradox evidence audit: structure first, observation as adjudication | QUEUED |
