#!/usr/bin/env python3
"""
verify_lookup.py — independent verifier for SEAM_CLAIM_EVIDENCE_LOOKUP.json

Re-opens every cited artifact, re-hashes it, resolves every locator, and confirms
the recorded value is what the sealed file actually contains. Exits non-zero on
any mismatch. Run from the Continuum Paradigm package root.

    python3 verify_lookup.py SEAM_CLAIM_EVIDENCE_LOOKUP.json
"""
import json, sys, os, hashlib

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()

def resolve_json_pointer(obj, ptr):
    if ptr in ("", "/"): return obj
    cur = obj
    for tok in ptr.lstrip("/").split("/"):
        tok = tok.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, list): cur = cur[int(tok)]
        else: cur = cur[tok]
    return cur

def resolve_md_section(path, heading):
    want = heading.lstrip("# ").strip()
    cur, buf, hit = None, [], None
    for line in open(path, errors="replace"):
        if line.startswith("#"):
            if cur == want: hit = "".join(buf); break
            cur = line.strip().lstrip("# ").strip(); buf = []
        else: buf.append(line)
    if hit is None and cur == want: hit = "".join(buf)
    return hit

def main(idx_path):
    idx = json.load(open(idx_path))
    hashes, bad, checked = {}, [], 0
    for c in idx["claims"]:
        for a in c["anchors"]:
            f, loc, kind = a["file"], a["locator"], a["locator_kind"]
            if not os.path.exists(f):
                bad.append((c["claim_id"], f, "FILE_MISSING")); continue
            if f not in hashes: hashes[f] = sha256(f)
            if hashes[f] != a["file_sha256"]:
                bad.append((c["claim_id"], f, "HASH_MISMATCH")); continue
            try:
                if kind == "json_pointer":
                    got = resolve_json_pointer(json.load(open(f, errors="replace")), loc)
                elif kind == "md_section":
                    got = resolve_md_section(f, loc)
                    if got is None: raise KeyError("heading not found")
                else:
                    got = None
                if got is not None:
                    rec, act = str(a["value_at_locator"]).strip(), str(got).strip()
                    if not (act.startswith(rec[:120]) or rec.startswith(act[:120])):
                        bad.append((c["claim_id"], f + " " + loc, "VALUE_MISMATCH")); continue
                checked += 1
            except Exception as e:
                bad.append((c["claim_id"], f + " " + loc, "UNRESOLVABLE: %s" % e))
    print("claims:            %d" % len(idx["claims"]))
    print("artifacts hashed:  %d" % len(hashes))
    print("locators verified: %d" % checked)
    print("failures:          %d" % len(bad))
    for b in bad[:40]: print("  FAIL", b)
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "SEAM_CLAIM_EVIDENCE_LOOKUP.json"))
