# R50 Full Evidentiary Cycle — Reproduction Package

This directory is the reproducibility lock for **R50 — Entropy-Selected Persistent Organization Under Prebiotic Continuum Conditions**.

## Contents
- `Results/`: every retained JSON result from the R37–R88 exploratory and validated cycle.
- `Runtime/`: every retained runtime used during the cycle, plus an explicitly labeled R79 contract reproducer.
- `Inputs/Canonical_Snapshot/`: the Continuum Paradigm canonical files used at the terminal photosynthesis stage.
- `Inputs/Photosynthesis/`: the R49 OEC closed block and B01 light-phase formulation.
- `Inputs/Data/`: atomic shell matrix used by the retained atomic-state runners.
- `Scientific_Bindings/`: external geological/photosynthetic evidence used only to bind empirical conditions.
- `RUN_CONTRACT.json`: scope, environment, and reproducibility levels.
- `EXECUTION_ORDER.json`: locked result order and exact terminal numeric replay order.
- `ADJUDICATION.json`: closed/open boundary.
- `LOCK_MANIFEST.json` / `SHA256SUMS.txt`: immutable file hashes.
- `Tools/verify_lock.py`: byte-level integrity verifier.
- `Tools/stage_and_replay_terminal.py`: stages the standardized paths and runs the terminal numeric chain.

## Scientific reproducibility rule
A reproducer must not infer a missing historical runner from the result unless that reconstruction is explicitly labeled. The archive therefore distinguishes:
1. exact byte-level evidence replay;
2. exact terminal numeric rerun from the retained precursor state; and
3. historical output-only evidence where an exploratory runner was not preserved at creation time.

This prevents the evidence lock from claiming more reproducibility than the retained artifacts actually support.
