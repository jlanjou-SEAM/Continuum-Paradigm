#!/usr/bin/env python3
"""Stage the full-cycle lock into the historical absolute-path contract and replay the terminal numeric chain.
Requires a writable /mnt/data. Existing /mnt/data/continuum_run or continuum_new are backed up by suffix `.pre_r50_replay` rather than overwritten.
"""
import pathlib, shutil, subprocess, sys, json
root=pathlib.Path(__file__).resolve().parents[1]
data=pathlib.Path('/mnt/data'); run=data/'continuum_run'; new=data/'continuum_new'
for target in [run,new]:
 if target.exists():
  bak=target.with_name(target.name+'.pre_r50_replay')
  if bak.exists(): shutil.rmtree(bak)
  target.rename(bak)
run.mkdir(parents=True); (run/'Evidence/Runtime').mkdir(parents=True); (run/'Evidence/Data/Z001_Z128_Blind_Matrix').mkdir(parents=True)
new.mkdir(parents=True)
for p in (root/'Results').glob('*.json'): shutil.copy2(p,run/p.name)
for p in (root/'Runtime').glob('*.py'): shutil.copy2(p,run/'Evidence/Runtime'/p.name)
mat=root/'Inputs/Data/Z001_Z128_ATOMIC_SHELL_MATRIX.csv'
if mat.exists(): shutil.copy2(mat,run/'Evidence/Data/Z001_Z128_Blind_Matrix'/mat.name)
# stage canonical/photo snapshot for r85 and source audit
for p in (root/'Inputs/Canonical_Snapshot').glob('*'): shutil.copy2(p,new/p.name)
if (root/'Inputs/Photosynthesis').exists(): shutil.copytree(root/'Inputs/Photosynthesis',new/'Evidence',dirs_exist_ok=True)
# Ensure B01 light path expected by r85 exists exactly.
src=root/'Inputs/Photosynthesis/B01_LIGHT_PHASE'
if src.exists(): shutil.copytree(src,new/'Evidence/Records/B01_LIGHT_PHASE',dirs_exist_ok=True)
order=json.loads((root/'RUN_CONTRACT.json').read_text())['terminal_execution_order']
logs=[]
for f in order:
 p=run/'Evidence/Runtime'/f
 if not p.exists(): logs.append({'runner':f,'status':'MISSING'}); continue
 cp=subprocess.run([sys.executable,str(p)],cwd=str(run),text=True,capture_output=True)
 logs.append({'runner':f,'exit_code':cp.returncode,'stdout_tail':cp.stdout[-2000:],'stderr_tail':cp.stderr[-2000:]})
 if cp.returncode: break
(root/'TERMINAL_REPLAY_LOG.json').write_text(json.dumps(logs,indent=2))
print(json.dumps(logs,indent=2))
sys.exit(logs[-1].get('exit_code',1) if logs and logs[-1].get('exit_code',0)!=0 else 0)
