#!/usr/bin/env python3
import json, hashlib, pathlib, sys
root=pathlib.Path(__file__).resolve().parents[1]
m=json.loads((root/'LOCK_MANIFEST.json').read_text())
bad=[]
for e in m['files']:
 p=root/e['path']
 if not p.exists(): bad.append((e['path'],'MISSING')); continue
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=e['sha256']: bad.append((e['path'],h))
print(json.dumps({'lock_id':m['lock_id'],'files_checked':len(m['files']),'failures':bad,'pass':not bad},indent=2))
sys.exit(1 if bad else 0)
