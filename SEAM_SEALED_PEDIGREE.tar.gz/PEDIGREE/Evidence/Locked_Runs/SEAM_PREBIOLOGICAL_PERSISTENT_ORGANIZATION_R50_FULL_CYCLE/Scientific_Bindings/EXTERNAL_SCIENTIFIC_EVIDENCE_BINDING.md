# R50 Full-Cycle Scientific Evidence Binding

## Purpose
This file identifies external empirical constraints used to parameterize or cross-check the R37–R88 prebiological Continuum cycle. These sources are not substituted for the Continuum equations; they bind environmental or established photosynthetic facts used by the run contract.

## A. Archean shallow/restricted brine constraint

**de Ronde et al., Earth and Planetary Science Letters 150 (1997), 325–335.**
“The Cl−Br−I− composition of ~3.23 Ga modified seawater: implications for the geological evolution of ocean halide chemistry.” DOI: 10.1016/S0012-821X(97)00101-5.

Relevant evidence: fluid inclusions from the Barberton Greenstone Belt show a bimodal aqueous salinity distribution, including a high-salinity population of approximately **0.9–1.8 mol/L Cl−**. This was the empirical basis for the R62/R63 restricted-shallow-brine sweep.

**de Ronde et al., Geochimica et Cosmochimica Acta (1997/1998 record).**
“Fluid chemistry of Archean seafloor hydrothermal vents: Implications for the composition of circa 3.2 Ga seawater.” PII: S0016703797002056.

Relevant reconstructed seawater end-member values used to set relative ionic proportions: **Cl 920 mmol/L, Na 789 mmol/L, K 18.9 mmol/L, Mg 50.9 mmol/L, Ca 232 mmol/L**. The paper characterizes the ambient seawater component as an evaporative NaCl–CaCl2 brine.

## B. Photosystem II / oxygen-evolving-complex recurrence

The archive-native R49 OEC block is accompanied by its own `EXTERNAL_SCIENTIFIC_EVIDENCE_BINDING.md`. The following independent literature facts are consistent with the event vector used in R88:

- Photosystem II OEC contains a Mn4CaOx cluster and advances through S-state redox intermediates.
- Four sequential one-electron photo-oxidation events accumulate oxidizing equivalents.
- Completion of one water-oxidation turnover yields one O2 from two water molecules and transfers four electrons and four protons.

Representative scientific references retained by title in the evidence discussion include:

1. “Computational Insights into the O2-evolving complex of photosystem II,” *Phil. Trans. R. Soc. B* / PMC2728911.
2. “Photosystem II: commonality and diversity with emphasis on the extrinsic subunits,” PMC12661325.
3. “Water oxidation chemistry of photosystem II,” PMC2614092.

## C. Evidentiary separation

External evidence is used only for:
1. geological environment bounds; and
2. the established photosynthetic/OEC comparator/event ledger.

The following are Continuum-derived run outputs and are **not external empirical claims**: spontaneous partial enclosure, retained promoted state, successor enhancement, unconstrained electrolyte assembly, and R88 day/night persistence/growth.
