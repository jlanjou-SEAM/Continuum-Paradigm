# Chlorophyll-a native ingress test

## Empirical apparatus baseline
- Formula: C55H72MgN4O5
- Connectivity source: PubChem chlorophyll a canonical isomeric SMILES
- Explicit heavy-atom graph: 65 nodes
- Implicit hydrogens: 72
- Total nuclei/atomic constituents: 137

## SEAM atomic states recovered from R33
- H (Z=1): [1,0,0,0,0,0,0]
- C (Z=6): [2,4,0,0,0,0,0]
- N (Z=7): [2,5,0,0,0,0,0]
- O (Z=8): [2,6,0,0,0,0,0]
- Mg (Z=12): [2,8,2,0,0,0,0]

## Existing molecular runtime contract
VF-REGION-LBFGSB-R4 accepts one shell vector N and one capacity vector c, then constructs two identical nodes at one native separation N_r. It has no input for:
- heterogeneous node identities,
- N>2 constituent graph,
- molecular connectivity graph,
- complete {r_ij, chi_ijkl} for a many-atom molecule,
- multi-input excitation history.

## Test disposition
ATOMIC LIFT: PASS
FORMULA/CONNECTIVITY INGEST: PASS
R4 REPRESENTATION OF CHLOROPHYLL-A: REJECTED_BY_CONTRACT
REASON: reducing C55H72MgN4O5 to a single aggregate N vector or two identical nodes violates complete-state/no-reduction requirements.
EMPIRICAL UV/VIS COMPARATOR: NOT REVEALED/NOT USED FOR NATIVE TUNING

## First executable gap
A versioned N-node heterogeneous molecular variational evaluator is required that consumes:
C = ({S_i}, R), R={r_ij, chi_ijkl}
and resolves the full molecular field under the existing entropy selector without replacing the molecular graph by a two-node surrogate.
