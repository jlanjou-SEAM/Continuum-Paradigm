# Continuum Paradigm — Phase-by-Phase Execution Guide

> **No-reduction rule (see `00_README.md`).** Structure in this archive is retained faceted and is never collapsed to a scalar. A faceted or symbolic form is a complete description of a *resolved* structure, not a deferred value. It does not license reading an unevaluated row as resolved: see the three-state status vocabulary (`RESOLVED` / `EXCLUDED` / `NOT_EVALUABLE`) in `00_README.md`.

**Runner:** `Evidence/Runtime/locked_runner.py`
**Contract ID:** `LOCKED_RUNNER_R30`
**Purpose:** one entry point that executes every declared phase in canonical order, verifies each against its sealed value where one exists, and reports a terminal per branch.

---


## Canonical architecture and execution scope

The Continuum Paradigm uses one integrated architecture with distinct responsibilities:

\[
\boxed{
\text{ESIH}
=
\text{definition of permissible structure and possible existence}
}
\]

\[
\boxed{
\text{AEPS}
=
\text{definition of how energy interacts with and distributes across structure}
}
\]

\[
\boxed{
\text{SEAM}
=
\text{mathematical representation and execution of structure, relation, interaction, and state change}
}
\]

ESAM is the mathematical-formalization lineage through which the ESIH structural principles are expressed in the SEAM mathematics.

The narrative definition states the physical meaning of a principle. The formalism supplies the complete mathematical state required to calculate that principle in a particular case:

\[
\boxed{
\text{formalism}
=
\text{mathematical realization of the narrative definition}
}
\]

The existence standard distinguishes possible and realized existence:

\[
\boxed{
\mathcal C_{\rm possible}
=
\mathcal A_{\rm SEAM}
}
\]

\[
\boxed{
\mathcal C_{\rm realized}
\subseteq
\mathcal A_{\rm SEAM}
}
\]

The Continuum is the physical domain. The Continuum Manifold is the retained and normalized record of observed or resolved portions of that domain:

\[
\boxed{
\mathcal M_t
=
\operatorname{RetainNormalize}
\left(
\operatorname{ObservedResolved}(\mathcal C_{\rm realized})
\right).
}
\]

### Current quantitative execution scope

Architectural scope and executed numerical scope are recorded separately.

The atomic structural domain carries the fully explicit numerical admissibility implementation presently retained in the archive. Molecular, aggregate, electromagnetic, propagation, material, biological, and macroscopic domains inherit the same structural admissibility and interaction architecture through their declared native constructors.

Chemistry and biology retain the same structural architecture. B01 supplies an executed single-frequency light-transfer contract, receiver/emitter recursion, entropy-successor controls, explicit partnership controls, and a frozen bulk chemistry start; the heterogeneous full-apparatus field/entropy successor remains an unexecuted application binding.

Bond interaction architecture is retained where documented. Numerical bond lengths and dissociation energies enter the evidence standing when their native calculation, seal, and comparator record are present.

Macroscopic interaction and force architecture are retained where documented. Absolute SI force values and a numerical derivation of \(G\) enter the evidence standing through their own completed native execution and evidence records.

Continued calculation expands quantitative coverage while preserving the same first-principles architecture.


## How to read this document

Each phase below states five things and nothing else:

| field | meaning |
|---|---|
| **Consumes** | exactly what enters the phase |
| **Operation** | the declared transformation, by name |
| **Produces** | what leaves the phase |
| **Terminal** | the phase's own disposition string |
| **Reads as** | the misreadings this phase has actually attracted, and why they are wrong |

The **Reads as** field exists because the cold-review provenance records identify recurring misreadings at specific phases. Naming them at the phase where they occur keeps each correction attached to the state it governs.

---

## Four rules that govern every phase

**1. Faceted retention.** A structure is described by its distinguishable aspects, retained separately. A symbol naming an aspect is part of a complete description. It is not a value awaiting computation.

**2. Phase dispositions retain their declared meaning.** `RESOLVED`, `EXCLUDED`, and `NOT_EVALUABLE` are distinct states. Exclusion is recorded only where a declared predicate has actually rejected a candidate. `NOT_EVALUABLE` records that the required native operation has not executed for that row.

**3. Native first, comparator after.** Native quantities are produced without reference to any conventional or measured value. Comparators enter only after the native result is frozen, and only to test it. A comparator may never define a native quantity.

**4. Notation is not a handoff.** An expression such as `E_H[C*]` names an evaluation/facet of the retained state unless this guide or a provenance binding explicitly declares a separate consumes / operation / produces boundary. Parentheses, brackets, arrows, or functional notation alone do not create another runtime stage.

---

## PHASE 0 — Environment capture

**Consumes:** nothing
**Operation:** record interpreter and numeric library versions
**Produces:** Python, NumPy, SciPy, platform
**Terminal:** `ENV_CAPTURED`

Reference execution:

```
python 3.12.3    numpy 2.4.4    scipy 1.17.1
```

The archive's pinned reference environment is Python 3.13.5 / NumPy 2.3.5 / SciPy 1.17.0. Sealed values reproduce **exactly** on both. That cross-environment match is itself evidence: the sealed results are properties of the declared mathematics, not artefacts of one numeric stack.

**Reads as:** nothing. Recorded so that a reproduction on a third environment can be compared.

---

## PHASE 1 — Atomic shell resolution

**Consumes:** `Z` in 1..128; `c_shell = [2, 8, 18, 32, 18, 32, 18]`
**Operation:** `Z -> N(Z)` by strict fill-before-skip (Technical Foundations §5.3.3), stated as a closed-form piecewise function
**Produces:** 128 resolved shell states
**Terminal:** `ATOMIC_SHELL_STATE_RESOLVED`

```
Z=26  -> [2, 8, 16,  0,  0,  0, 0]
Z=29  -> [2, 8, 18,  1,  0,  0, 0]
Z=74  -> [2, 8, 18, 32, 14,  0, 0]
Z=79  -> [2, 8, 18, 32, 18,  1, 0]
Z>=129 -> not admissible
```

Shell closures fall at `Z = 2, 10, 28, 60, 78, 110, 128`.

**Reads as:** the two numbers 118 and 128 are frequently conflated. **128** is the architectural admissibility count — the capacity vector sums to 128 and the fill rule is defined to 128. **118** is the empirical comparison range, because 118 elements are presently known. Neither number is a rounding of the other. Statements about admissibility use 128; statements about comparison against observation use 118.

---

## PHASE 2 — Atomic entropy properties

**Consumes:** resolved shell states from Phase 1
**Operation:**

```
S_config = sum_n ln C(c_n, N_n)
S_field  = ln E - (1/E) sum_n N_n ln(N_n / V_n),    V_n = (4pi/3)[n^3 - (n-1)^3]
```

**Produces:** both quantities per element
**Terminal:** `ATOMIC_ENTROPY_RESOLVED`
**Sealed:** MATCH (5 of 5)

```
Fe  S_config = 5.030437921392435    S_field = 4.701856904349989
Cu                                  S_field = 4.873141663921901
W                                   S_field = 6.057692190418670
Au                                  S_field = 6.177105205898307
```

**Reads as:** an earlier reader-facing table carried a *different* quantity under the name `S_field` — the Bernoulli entropy of the fractional fill of the outermost shell. That duplicate was corrected. Only the spatial field entropy above is canonical. If a `S_field` value is encountered that does not reproduce from the formula above, it is the withdrawn quantity.

---

## PHASE 3 — Signed shell-field operator

**Consumes:** `S_field` over `Z = 1..128`
**Operation:** **backward** second difference, `O(Z) = S(Z) - 2S(Z-1) + S(Z-2)`
**Produces:** sign disposition at every evaluable `Z`
**Terminal:** `SHELL_SIGN_LAW_CLOSED`

```
evaluable states (Z = 3..128) : 126
violations                    : 0
shell openings                : Z = 1, 3, 11, 29, 61, 79, 111
```

**The stencil is the claim.** The same data under the three conventions gives:

| stencil | violations |
|---|---|
| **backward** | **0** |
| forward | 11 |
| centered | 12 |

**Reads as:** two errors have occurred here. First, an audit reported "centered, 117/117" — the values were in fact generated with the backward stencil and mislabelled; the true centered stencil gives 12 violations. Second, the evaluable domain has been stated as 116 states over `Z = 3..118`. The fill rule is defined to 128, so the domain is `Z = 3..128` and there are **126** evaluable states.

**Non-genericity.** This result is not an arithmetic identity. Tested against 2000 systems with randomised capacity vectors and randomised shell volumes, **2000 of 2000 produce violations.** Zero violations is a joint property of the canonical capacity vector and the annular geometry; perturb either and it fails.

---

## PHASE 4 — EPN neutron band and containment

**Consumes:** resolved shell states; NUBASE2020 **as comparator only, after native band generation**
**Operation:** native `[N_low, N_high]` per `Z`, then containment check
**Produces:** bands for `Z = 1..128`, containment disposition, forward bands above 118
**Terminal:** `EPN_BAND_CLOSED_CONTAINMENT_PASS`

```
containment                     : 2549 / 2549 experimental states
band cells (Z = 1..118)         : 9822
observed span cells             : 2608
mean band width / observed span : 3.766
```

**Reads as:** containment is a **scope** result, not a precision result. The bands are literal fill-capable admissibility boundaries, so they are wider than what nature realises — by a factor of about 3.8 on average, and by far more at high `Z`. 2549/2549 says nothing was excluded that exists. It does not say the bands are tight. **The width ratio must be reported alongside the containment figure**, or a reader will take containment for precision.

**Forward content.** Bands for `Z = 119..128` have no observational counterpart. Nothing above `Z = 118` could have entered any calibration. These are the only bands in the table that are out-of-sample by construction.

---

## PHASE 5 — Stability selector (NOT RUN — operator absent)

**Consumes:** in-scope `(Z, N)` candidates
**Operation:** `N_best = argmax_N I`, with `I = W(P,N)(1 + e^{H*(T)} / dim T)`
**Produces:** nothing — the operator required to produce it is not in the archive
**Terminal:** `SELECTOR_NOT_RUN_OPERATOR_ABSENT`

```
in_scope_candidates : 13059
evaluated           :     0
resolved            :     0
excluded            :     0
not_evaluable       : 13059
blocking_operator   : operators/atomic_pne.py::S(X) entrywise relation kernel
```


**R33 propagation rule:** the Phase 5 disposition governs every summary of this phase. `not_evaluable = 13059` means exactly that the selector operation has not executed for those rows. The result matrix, misreading index, and runner contract use that same disposition vocabulary.

**Reads as:** the selector has not run. Every row carries `winner_status = NOT_EVALUABLE` and
`selector_status = UNRESOLVED_UNTIL_SX_KERNEL_BOUND`, exactly as
`Evidence/Runtime/epn_stability_selector_table.py` declares in its module docstring. No candidate has been
tested and rejected here. A reviewer who reads `not_evaluable: 13059` as "13059 candidates were
screened out" is reading it wrong in the archive's favour, and earlier revisions of this guide
invited that reading.

**This is not the eliminatory stage.** Exclusion happens at phase 1, where every `Z >= 129` fails
`leftover_count > 0` against `sum(c_shell) = 128`. That is a real rule producing a real, unbounded
exclusion, and it is reported there as a predicate. It rests on one decision, so it is deliberately
not multiplied out into an extrapolated `(Z,N)` cell count — doing so would present a single rule
as thousands of independent tests.

**Not substituted.** The archive declines to substitute `argmax W` for the full selector, on
grounds reproducible from archive-resident quantities (Evidence 37,
`Evidence/Runtime/selector_substitution_bound.py`). The `W` peak is flat to within 0.19% across the
permitted band, while `H* ∈ [0, ln 10]` gives `(1+r_T)` an admissible spread of 1.818x — enough to
move the optimum for 118/118 elements. And `argmax W` alone reproduces the dominant natural
isotope for **0 of 84** elements, mean deviation 14.3 neutrons. A `W`-only table would have been
wrong everywhere while appearing complete. Declining to populate is correct.

**What would close it.** Bind `S(X)`, run `S -> T -> spectrum -> H* -> r_T -> I` for every in-scope
row, and emit `N_best` for `Z = 1..118`. That column is checkable against NUBASE ground states
immediately and can fail on nearly every element. It is the sharpest near-term test in the archive.

---

## PHASE 6 — Molecular variational field

**Consumes:** resolved constituent states; native separation `N_r`
**Operation:** `{u*} = argmax_{ {u} in prod U_{i,n} } S[C; N_r, {u}]`, giving `S*(N_r)`
**Produces:** selected field profiles and the optimised entropy
**Terminal:** `VARIATIONAL_FIELD_RESOLVED`
**Sealed:** MATCH

```
Cu2 at N_r = 6.2 :  S*/k_B = 12.502276251235417   (bit-exact against seal)
```

The admissible class is `U_{i,n} = { u >= 0 : supp u subset Omega_{i,n}, int |u|^2 = 1 }`. The uniform indicator `u^(0) = 1_Omega / sqrt(V_n)` is the **isolated baseline**, not the general solution — it is the maximiser only when supports are disjoint.

**Reads as:** the optimisation is over `{u}` at fixed `C` and fixed `N_r`. `u^(0) in U` does not imply `u^(0) = u*`, and a fixed-support calculation is not a substitute for the variational selection. Equally, factorisation of the field profiles is **not** identity of the complete configurations: `C = ({Sigma_i}, R)` retains the relational coordinate, and two configurations with equal entropy are not thereby the same configuration.

---

## PHASE 7 — Two-stage pair relation

**Consumes:** two independently resolved states, plus native separation
**Operation:**

```
resolve A -> Sigma_A
resolve B -> Sigma_B
(Sigma_A, Sigma_B, N_R) -> C*_ab -> {u*} -> F_C -> q_C -> O_ab -> S_coupling -> S*_ab
```

**Produces:** resolved pair state and its faceted pair consequence
**Terminal:** `SEAM_RESOLVED_STATE_PAIR_RELATION_CLOSED`
**Sealed:** MATCH (3 of 3)

```
Fe-Fe  RESOLVED  S* = 15.455879927694806  S_coupling = 0.0
Fe-Cu  RESOLVED  S* = 13.964296139243187  S_coupling = 1.951989e-04   overlap 3-4 = 0.007027161940875693
Cu-Cu  RESOLVED  S* = 12.502276251235417  S_coupling = 1.147028e-04
```

The mixed Fe-Cu pair emits a cross-state overlap that **neither** homonuclear pair produces. That is the evidence that stage 2 consumes the structures resolved by stage 1, rather than replaying one generic same-element relation.

**Reads as:** the pair relation is **two-stage**. No third producer is required. `E_ab`, `g_Theta,ab` and `S_ab` are the **faceted description** of one already-resolved pair consequence — distinguishable aspects retained separately by rule. They are not three independent constructors awaiting population, and a symbolic form there is a complete description, not a deferred value. The same rule applies to the earlier Hamiltonian notation `E_H[C*]`: it is the Hamiltonian facet/evaluation of the retained selected state, not an undeclared third runtime between `C*` and `Delta H`. Inserting a third handoff between the resolved pair state and its declared consequence produces a spurious binding-absent terminal; that terminal is an artefact of the extra handoff and does not arise in the two-stage path.

---

## PHASE 8 — Retained mass state

**Consumes:** `Z`; a body mass label; density
**Operation:** isotope set -> populations -> retained body mass state
**Produces:** one mass entry per nuclide, plus populations
**Terminal:** `RETAINED_MASS_STATE_RESOLVED`

10 kg Fe reference execution:

```
54Fe  N=28  m = 53.939608206 u   5.845 %   6.303039e+24 atoms
56Fe  N=30  m = 55.934935541 u  91.754 %   9.894424e+25 atoms
57Fe  N=31  m = 56.935391947 u   2.119 %   2.285054e+24 atoms
58Fe  N=32  m = 57.933273544 u   0.282 %   3.040987e+23 atoms

N_total = 1.078364e+26     electrons = 2.803747e+27     R = 0.0671798 m
mass state cardinality = 4 (natural)   /  32 (all admitted nuclides)
```

**Reads as:** the mass state is faceted. `M_Z = M(Q_res, N)` is a set with one entry per nuclide, and the molecular continuation `M_X2 = M_Z x M_Z` retains isotopologue identity. A single scalar "atomic weight" is a projection that discards this structure, and the archive does not adopt it as the mass state.

The scale of what a scalar would discard: tungsten's isotopologue family spans **12.015 u**, while the binding-mass correction is of order **5e-9 u** — ten orders of magnitude smaller than the structure a collapse would throw away.

---

## PHASE 9 — Macro source and body continuation

**Consumes:** retained body mass state; body geometry
**Operation:**

```
sigma_B(x) = rho_m,B(x) Xi_B(x)
S_M        = integral sigma_B dV
Lambda(r) ~ -S_M / r        ->      -grad Lambda ~ -S_M / r^2
F_AB       ~ S_A S_B / r^2
```

**Produces:** native body source and exterior continuation
**Terminal:** `MACRO_CONTINUATION_SYMBOLIC_NORMALIZATION_OPEN`

```
S_M(10 kg Fe) = Xi_Fe * 10.000000 kg
F(r) / F(2r)          = 4.000000     (parameter-free)
F(2M,2M) / F(M,M)     = 4.000000     (parameter-free)
first unresolved scalar: macro normalization  (K*Xi one-body; G_S*Xi^2 two-body)
```

**Same-material cancellation.** For a single-material homogeneous body, `Xi_B(x)` is constant and factors out of the volume integral: `S_M = Xi * M`. The composition expansion is therefore **not required** for a same-material target. A phase that stops at "the composition function is unbound" has stopped too early — the correct test is whether the unresolved coordinate is actually required by the requested calculation.

**Reads as:** the two parameter-free ratios above are genuine predictions, testable against a torsion balance with no calibration whatsoever, because both unresolved scalars cancel. The remaining open item is the single macroscopic normalization, and it is a **normalization**, not a per-configuration fit: fixed once, it may never be adjusted again.

**Transfer boundary.** A normalization fixed on an Fe-Fe configuration transfers to a different-material pair **only if** `Xi` is composition-universal. Earth is heterogeneous, so `Xi` does not factor out of `int rho_m Xi dV` for a terrestrial body. The transfer is therefore itself an equivalence-principle test, and the constraint is severe: MICROSCOPE (2022) gives `eta(Ti,Pt) = (-1.5 +/- 2.3 +/- 1.5) x 10^-15`.

**Admissibility rule for any future `Xi` binding.** Composition universality must follow from the native construction. Equivalence-principle measurements may **test** that consequence; they may not be used to fit or define the coefficients of `Xi`. Fitting them would make the comparator define the native operator, which the directionality rule prohibits.

---

## Result matrix

| # | Phase | Branch | Terminal | Sealed |
|---|---|---|---|---|
| 0 | Environment capture | meta | `ENV_CAPTURED` | — |
| 1 | Atomic shell resolution | atomic | `ATOMIC_SHELL_STATE_RESOLVED` | — |
| 2 | Atomic entropy properties | atomic | `ATOMIC_ENTROPY_RESOLVED` | **MATCH** 5/5 |
| 3 | Signed shell-field operator | atomic | `SHELL_SIGN_LAW_CLOSED` | 0/126 violations |
| 4 | EPN band + containment | empirical | `EPN_BAND_CLOSED_CONTAINMENT_PASS` | 2549/2549 |
| 5 | Stability selector | empirical | `SELECTOR_NOT_RUN_OPERATOR_ABSENT` | 13059 not evaluable; `S(X)` absent |
| 6 | Molecular variational field | molecular | `VARIATIONAL_FIELD_RESOLVED` | **MATCH** |
| 7 | Two-stage pair relation | molecular | `SEAM_RESOLVED_STATE_PAIR_RELATION_CLOSED` | **MATCH** 3/3 |
| 8 | Retained mass state | mass | `RETAINED_MASS_STATE_RESOLVED` | — |
| 9 | Macro source continuation | macro | `MACRO_CONTINUATION_SYMBOLIC_NORMALIZATION_OPEN` | — |

**All sealed values reproduce: TRUE** — on an environment differing from the pinned reference in interpreter and both numeric libraries.

---

## Misreading index

Every entry below occurred during an independent cold review. Each is listed with the phase it arises at and the fact that resolves it.

| # | Misreading | Phase | Resolution |
|---|---|---|---|
| 1 | 116 evaluable states for the sign law | 3 | fill rule runs to 128; domain is `Z=3..128`, 126 states |
| 2 | "centered stencil gives 0 violations" | 3 | those values were backward; centered gives 12 |
| 3 | `S_field` value does not reproduce | 2 | a withdrawn Bernoulli-fill quantity shared the name |
| 4 | 118/118 containment reads as precision | 4 | containment is scope; width ratio is 3.766 |
| 5 | `SOURCE_BINDING_REQUIRED` / `NOT_EVALUABLE` read as elimination | 5 | selector has not run; the rows remain unevaluated until `S(X)` is bound |
| 6 | fixed-support run treated as the variational result | 6 | `u^(0) in U` does not imply `u^(0) = u*` |
| 7 | equal `S*` read as identical configurations | 6 | `C = ({Sigma}, R)`; the relational coordinate is retained |
| 8 | `E_ab g_Theta S_ab` read as three unpopulated inputs | 7 | faceted description of one resolved consequence |
| 9 | terminal from one branch applied to another | 7 | shared notation is not shared operator scope |
| 10 | macro stop declared at an unbound `Xi` | 9 | `Xi` factors out for a same-material body |
| 11 | atomic weight expected as the mass state | 8 | mass state is faceted; the scalar is a lossy projection |
| 12 | absence concluded from a text search | all | search is navigation only; read the section |
| 13 | `E_H[C*]` read as a missing standalone runtime | 6–7 | Hamiltonian facet/evaluation of retained `C*`; no handoff exists unless explicitly contracted |

---

## Contract

```
LOCKED_RUNNER_R30

  - every phase executes in canonical order; none may be skipped or reordered
  - every phase reports consumes / operation / produces / terminal / sealed check
  - each phase reports the counts appropriate to its declared state vocabulary; Phase 5 reports evaluated / resolved / excluded / not_evaluable without reclassifying unevaluated rows as eliminated
  - a phase producing no numeric result reports its disposition, not a clean exit
  - environment is captured; sealed values must reproduce across environments
  - comparators enter only after the native result of their phase is frozen
```

Invocation:

```bash
python3 Evidence/Runtime/locked_runner.py                    # full transcript
python3 Evidence/Runtime/locked_runner.py --json out.json    # machine-readable matrix
python3 Evidence/Runtime/locked_runner.py --quiet --json out.json
```


## PHASE 7A — Single-frequency receiver/emitter chain and chemistry handoff

**Input:** a resolved emitter state, a complete receiver molecular/material state, and a frozen native periodicity coordinate.

For the B01 controlled run,

\[
f_t=500\ \mathrm{THz}.
\]

1. Evaluate the receiver under the incoming complete excitation.
2. If native structured transfer is nonzero and compatible, retain the resulting excited receiver state.
3. Record any simultaneous local field/entropy/thermal response without presuming attenuation, augmentation, or frequency change.
4. Use the resulting excited receiver state as the emitter for the next link under the same transfer relation.
5. At the chemistry handoff, retain the actual atomic partnership graph of the excited molecular composition.
6. Reevaluate existing partnerships under the excited field using the complete entropy selector.
7. Classify each calculated relation as retained, shifted, or lost/split-favored only from the entropy result.
8. After any accepted relational change, recompute the entire molecular field/entropy state before continuing.
9. Stop only at a structural terminal. Apply energy projection afterward.

**Current B01 execution boundary:** the current runtime does not provide the heterogeneous N-node complete-field/entropy evaluator needed for the chlorophyll + 6CO2 + 6H2O excited graph. Do not substitute R4 or preselect products.


## Universal interaction execution cycle

For every SEAM interaction, irrespective of scale or conventional domain:

1. Freeze the complete incoming structure \(Y_i^{pre}\).
2. Apply or receive the admissible perturbation \(\Delta Y_{pert}\).
3. Resolve the complete resulting structure \(Y_i^{post}\).
4. Compute the native structured transfer:
   \[
   T_i=\mathfrak D_{\rm struct}[Y_i^{pre}\rightarrow Y_i^{post}].
   \]
5. Re-resolve entropy and relational closure in the post-perturbation state.
6. If the relational state changes, treat the resulting complete state as the next pre-perturbation structure.
7. Repeat until the post-perturbation structure no longer changes under the admitted input/history.

Canonical shorthand:

\[
\boxed{
\text{structure}\rightarrow\text{perturbation}\rightarrow\text{structure}
}
\]

This cycle applies equally to propagation, material reception, atomic interaction, molecular restructuring, thermal response, and subsequent composite-state evolution. No separate domain operator replaces it.
