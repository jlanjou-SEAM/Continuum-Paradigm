import json,sys,math
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import r56_parallel_ionic as r
D=json.load(open('/mnt/data/continuum_run/SEAM_IONIC_PAIR_WEIGHTED_R56.json')); W={}
for q in D['weights']: W[q['a'],q['b']]=W[q['b'],q['a']]=q['norm']

def media(scale):
    base={'H':60,'O':30}
    ions={'Na':6,'Cl':6,'Mg':2,'Ca':1,'K':2,'S':1}
    for e,n in ions.items(): base[e]=max(0,int(round(n*scale)))
    return base

def relax(elements,W,seed,steps=800,init_R=20.0):
    rng=np.random.default_rng(seed); n=len(elements); x=r.ball(n,init_R,rng)
    rad=np.array([r.RAD[e] for e in elements],float); r0=rad[:,None]+rad[None,:];np.fill_diagonal(r0,1)
    WM=np.ones((n,n))
    for i in range(n):
      ei=elements[i]
      for j in range(i+1,n): WM[i,j]=WM[j,i]=np.clip(W[ei,elements[j]],.03,8.)
    last=None
    for t in range(steps):
      dv=x[None,:,:]-x[:,None,:]; d=np.linalg.norm(dv,axis=2); np.fill_diagonal(d,np.inf)
      u=dv/np.where(np.isfinite(d),d,1)[:,:,None]; far=d>r0; near=d<r0
      mf=np.where(far,np.minimum(1.,(r0/np.where(np.isfinite(d),d,1))**2)*WM,0)
      mn=np.where(near,np.clip((r0-d)/r0,0,1)*WM,0)
      f=((mf-mn)[:,:,None]*u).sum(axis=1)/max(1,n-1); f-=f.mean(axis=0)
      dt=.03*(.25+.75*(1-t/steps)); dx=dt*f; x+=dx
      if t==steps-1: last={'rms':float(np.sqrt(np.mean(dx*dx))),'overlaps':int(np.triu(d<r0,1).sum())}
    x-=x.mean(axis=0); return x,last

def coverage(x,elements,me,nprobe=1600):
    L=me.get('layer')
    if not L: return 0.0,0,None
    rr=np.linalg.norm(x,axis=1); mask=(rr>=L['rlo'])&(rr<L['rhi']); pts=x[mask]
    if len(pts)<4:return 0.0,len(pts),None
    types=[elements[i] for i in np.where(mask)[0]]; Rs=np.array([r.RAD[e] for e in types],float)
    R=float(np.median(np.linalg.norm(pts,axis=1)))
    k=np.arange(nprobe); z=1-2*(k+.5)/nprobe; phi=math.pi*(3-math.sqrt(5))*k
    dirs=np.c_[np.sqrt(1-z*z)*np.cos(phi),np.sqrt(1-z*z)*np.sin(phi),z]; surf=R*dirs
    cov=np.zeros(nprobe,dtype=bool)
    for p,rad in zip(pts,Rs): cov |= (np.linalg.norm(surf-p,axis=1)<=rad)
    return float(cov.mean()),len(pts),R

rows=[]
for cs,initR in [(0.5,16.0),(0.5,22.0),(1.0,16.0),(1.0,22.0),(2.0,16.0),(2.0,22.0)]:
    els=r.expand(r.POOLS['B_ionic'])+r.expand(media(cs))
    seed=6000+int(cs*100)+int(initR)
    x,last=relax(els,W,seed,steps=380,init_R=initR); me=r.metrics(x,els); cov,ln,lr=coverage(x,els,me)
    rows.append({'brine_scale':cs,'init_R':initR,'nodes':len(els),'seed':seed,'layered':me['layered'],'layer':me['layer'],'coverage':cov,'layer_nodes':ln,'layer_radius':lr,'rmax':me['rmax'],'central_count':me['central_count'],'last':last})
rows=sorted(rows,key=lambda z:z['coverage'],reverse=True)
out={'run_id':'R60_BRINE_CONFINEMENT_SWEEP','excitation':'held at R56 pair-state contract; no additional excitation remapping in this screen','rows':rows,'best':rows[:6]}
Path('/mnt/data/continuum_run/SEAM_BRINE_CONFINEMENT_SWEEP_R60.json').write_text(json.dumps(out,indent=2))
print(json.dumps(rows[:10],indent=2))
