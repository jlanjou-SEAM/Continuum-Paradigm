#!/usr/bin/env python3
import json, importlib.util
from pathlib import Path
import numpy as np
from scipy.stats import qmc

ROOT=Path('/mnt/data/continuum_run'); HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r78', HERE/'r78_compartment_promoted_chain.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
ck=json.load(open(ROOT/'SEAM_R63_COMPARTMENT_CHECKPOINT_R78A.json'))
x=np.asarray(ck['coordinates'],float); elements=list(ck['elements'])

# Actual R63/R78 local compartment field, centered on the same nearest O protocol.
rr=np.linalg.norm(x,axis=1); Oidx=[i for i,e in enumerate(elements) if e=='O']; oi=min(Oidx,key=lambda i:rr[i]); origin=x[oi].copy()
locidx=np.where(np.linalg.norm(x-origin,axis=1)<=7.0)[0]

CANDS=['H','C','N','O','P','S','Na','Mg','Cl','K','Ca']
DIRS=np.array([[1.,0,0],[0,1.,0],[0,0,1.],[-1.,0,0],[0,-1.,0],[0,0,-1.]])

# Build compartment environment and remove one local representative for the explicit seed C/O only.
remove={oi}
for typ in ['C']:
    cand=[i for i,e in enumerate(elements) if e==typ and i not in remove]
    if cand: remove.add(min(cand,key=lambda i:np.linalg.norm(x[i]-origin)))
keep=[i for i in locidx if i not in remove]
env_elements=[elements[i] for i in keep]; env_cent=x[keep]-origin
shenv=np.vstack([r.AT[e] for e in env_elements]) if env_elements else np.empty((0,7),int)

# Seed = validated carbon + promoted oxygen geometry, with no preselected ionic binder.
base=np.vstack([r.AT['C'],r.AT['O']]); seed_sh=base.copy(); seed_sh[1]=r.promoted(r.AT['O'])
d=.88*(r.outer(r.AT['C'])+r.outer(r.AT['O']))
seed_cent=np.array([[-d/2,0,0],[d/2,0,0]],float)
seed_labels=['C','O*']

LO=np.array([-15.,-15.,-15.]); HI=-LO

def evalS(sh,ce,eps,seed,pow):
    pts=LO+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(HI-LO)
    return r.eval_fixed(sh,ce,eps,pts,LO,HI)

def near_position(chain_cent, cand, direction):
    com=np.mean(chain_cent,axis=0)
    # native contact scale from mean retained outer support + candidate support
    # promoted O retains O support under this excitation contract.
    meanr=np.mean([np.linalg.norm(c-com) for c in chain_cent])
    support=max(1.0, meanr*0.35) + r.outer(r.AT[cand])
    pos=com+direction*.88*support
    # deterministic nudge away from coincident nodes
    if np.min(np.linalg.norm(chain_cent-pos,axis=1))<0.3:
        pos=pos+np.array([.37,.19,.23])
    return pos

def candidate_delta(chain_sh,chain_cent,cand,direction,eps,seed,pow):
    pn=near_position(chain_cent,cand,direction)
    com=np.mean(chain_cent,axis=0); pf=com+direction*13.5
    sh=np.vstack([shenv,chain_sh,r.AT[cand]])
    cn=np.vstack([env_cent,chain_cent,pn]); cf=np.vstack([env_cent,chain_cent,pf])
    # common quadrature for near/far subtraction
    pts=LO+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(HI-LO)
    return r.eval_fixed(sh,cn,eps,pts,LO,HI)-r.eval_fixed(sh,cf,eps,pts,LO,HI),pn

def scan_step(step,chain_sh,chain_cent):
    rows=[]
    seed0=87000+step*1000
    for ci,cand in enumerate(CANDS):
        best=None
        for di,dv in enumerate(DIRS):
            dm,pn=candidate_delta(chain_sh,chain_cent,cand,dv,.5,seed0+ci*20+di,10)
            dd,_=candidate_delta(chain_sh,chain_cent,cand,dv,0.0,seed0+500+ci*20+di,10)
            rec={'candidate':cand,'dir':di,'delta_moderate':float(dm),'delta_dark':float(dd),'position':pn.tolist()}
            # primary ordering: retained dark-positive, then moderate score
            score=(1 if dd>0 else 0, dm)
            if best is None or score>best['_score']:
                rec['_score']=score; best=rec
        best.pop('_score',None); rows.append(best)
    # Only retained candidates are admissible; select highest moderate delta.
    admiss=[z for z in rows if z['delta_moderate']>0 and z['delta_dark']>0]
    winner=max(admiss,key=lambda z:z['delta_moderate']) if admiss else None
    return rows,winner

steps=[]; chain_sh=seed_sh.copy(); chain_cent=seed_cent.copy(); labels=seed_labels.copy()
for step in range(1,6):
    rows,w=scan_step(step,chain_sh,chain_cent)
    steps.append({'step':step,'all_candidates':rows,'winner':w,'labels_before':labels.copy()})
    if w is None: break
    chain_sh=np.vstack([chain_sh,r.AT[w['candidate']]])
    chain_cent=np.vstack([chain_cent,np.asarray(w['position'],float)])
    labels.append(w['candidate'])

# Dense audit each selected step against same prior chain, 3 seeds x 2^14 and all 3 positive axes x 2^13.
audit=[]; chain_sh=seed_sh.copy(); chain_cent=seed_cent.copy(); labels=seed_labels.copy()
for srec in steps:
    w=srec['winner']
    if not w: break
    cand=w['candidate']; dv=DIRS[w['dir']]
    vals=[]
    for sd in [87901+srec['step']*10,87902+srec['step']*10,87903+srec['step']*10]:
        dm,pn=candidate_delta(chain_sh,chain_cent,cand,dv,.5,sd,14)
        dd,_=candidate_delta(chain_sh,chain_cent,cand,dv,0.0,sd+100,14)
        vals.append({'seed':sd,'moderate':float(dm),'dark':float(dd)})
    dirs=[]
    for di,dv2 in enumerate(DIRS[:3]):
        dm,p2=candidate_delta(chain_sh,chain_cent,cand,dv2,.5,88100+srec['step']*10+di,13)
        dd,_=candidate_delta(chain_sh,chain_cent,cand,dv2,0.0,88200+srec['step']*10+di,13)
        dirs.append({'dir':di,'moderate':float(dm),'dark':float(dd)})
    strict=all(v['moderate']>0 and v['dark']>0 for v in vals)
    robust_dirs=sum(v['moderate']>0 and v['dark']>0 for v in dirs)
    audit.append({'step':srec['step'],'parent':'-'.join(labels),'selected':cand,'coarse':w,
                  'dense':vals,'direction_audit':dirs,'strict_3seed':strict,'robust_positive_dirs':robust_dirs,
                  'means':{'moderate':float(np.mean([v['moderate'] for v in vals])),'dark':float(np.mean([v['dark'] for v in vals]))}})
    if not strict:
        break
    # preserve coarse winning position for continuation only after dense pass
    chain_sh=np.vstack([chain_sh,r.AT[cand]])
    chain_cent=np.vstack([chain_cent,np.asarray(w['position'],float)])
    labels.append(cand)

out={'run_id':'R87_UNCONSTRAINED_ELECTROLYTE_CONTINUATION',
     'contract':'Actual R63/R78 compartment field; seed C-O* only. Full CHNOPS + Na/K/Mg/Ca/Cl candidate reservoir restored. At each step all species compete; no binder sequence imposed. Winner=max positive retained deltaS at epsilon=.5 among candidates also positive in dark. Five-step coarse greedy screen followed by stepwise dense 3-seed and 3-direction audit.',
     'environment_nodes':len(env_elements),'candidate_pool':CANDS,'coarse_steps':steps,'dense_audit':audit,
     'validated_sequence':labels,'validated_additions':[a['selected'] for a in audit if a['strict_3seed']],
     'adjudication':None}
if audit and all(a['strict_3seed'] for a in audit) and len(audit)>=len([s for s in steps if s['winner']]):
    out['adjudication']='UNCONSTRAINED ELECTROLYTE CONTINUATION PASS THROUGH ALL SCREENED STEPS'
elif audit:
    firstfail=next((a for a in audit if not a['strict_3seed']),None)
    out['adjudication']='PARTIAL PASS; SEQUENCE VALIDATED UNTIL FIRST DENSE FAILURE'+(f" AT STEP {firstfail['step']} ({firstfail['selected']})" if firstfail else '')
else:
    out['adjudication']='NO RETAINED SUCCESSOR FOUND'
(ROOT/'SEAM_UNCONSTRAINED_ELECTROLYTE_CONTINUATION_R87.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'validated_sequence':out['validated_sequence'],'validated_additions':out['validated_additions'],'adjudication':out['adjudication'],'audit':[{'step':a['step'],'selected':a['selected'],'strict':a['strict_3seed'],'dirs':a['robust_positive_dirs'],'means':a['means']} for a in audit], 'coarse_winners':[s['winner']['candidate'] if s['winner'] else None for s in steps]},indent=2))
