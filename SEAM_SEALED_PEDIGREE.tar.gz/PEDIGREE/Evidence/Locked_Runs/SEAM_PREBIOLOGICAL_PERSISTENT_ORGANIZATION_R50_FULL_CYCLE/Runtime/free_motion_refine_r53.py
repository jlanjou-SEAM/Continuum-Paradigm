#!/usr/bin/env python3
import importlib.util,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('r52','/mnt/data/continuum_run/Evidence/Runtime/free_motion_near_far_r52.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
els=m.expand(m.POOLS['B_ionic'])+m.expand(m.MEDIA['fresh'])
rows=[]
for seed in [5202, 5311]:
    x,rad,h=m.relax(els,seed,steps=2200,dt0=0.05,init_R=20.0)
    met=m.boundary_metrics(x,rad,els); met.update(m.q_proxy_contrast(x,rad)); met['seed']=seed; met['history']=h
    rows.append(met)
out={'run_id':'SEAM-NEAR-FAR-FREE-MOTION-REFINE-R53','pool':'B_ionic','medium':'fresh','steps':2200,'rows':rows,'persistent_layer_count':sum(r['layered_boundary_candidate'] for r in rows),'disposition':'PERSISTENT_LAYER_CANDIDATE' if all(r['layered_boundary_candidate'] for r in rows) else 'NOT_REPRODUCIBLE_AS_BOUNDARY'}
p=Path('/mnt/data/continuum_run/SEAM_NEAR_FAR_FREE_MOTION_REFINE_R53.json');p.write_text(json.dumps(out,indent=2))
print(json.dumps({'disposition':out['disposition'],'rows':[{'seed':r['seed'],'layered':r['layered_boundary_candidate'],'layer':r['layer'],'contrast':r['contrast_proxy'],'hull_fraction':r['hull_fraction'],'center_count':r['central_count_r_lt_0p35_rmax'],'last':r['history'][-1]} for r in rows]},indent=2));print(p)
