import json, math, sys
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import r56_parallel_ionic as r

BASE=json.load(open('/mnt/data/continuum_run/SEAM_IONIC_PAIR_WEIGHTED_R56.json'))
R63=json.load(open('/mnt/data/continuum_run/SEAM_ARCHAEAN_EXCITATION_SCREEN_R63A.json'))
W0={}
for q in BASE['weights']:
    W0[(q['a'],q['b'])]=W0[(q['b'],q['a'])]=float(q['norm'])
# rebuild epsilon-specific weights exactly from saved R63 slope ratios
EXC=['H','C','N','O','Mg']
def W_for(eps):
    w=dict(W0)
    s0=R63['excitation_slopes']['0.0']; se=R63['excitation_slopes'][str(eps)]
    for i,a in enumerate(EXC):
      for b in EXC[i:]:
        key=f'{a}-{b}' if f'{a}-{b}' in s0 else f'{b}-{a}'
        a0=float(s0[key]); ae=float(se[key]); ratio=ae/a0 if a0>1e-12 else 1.0
        w[(a,b)]=w[(b,a)]=W0[(a,b)]*ratio
    return w
WE={e:W_for(e) for e in [0.0,0.5,1.0]}

REF={'Cl':0.92,'Na':0.789,'Mg':0.0509,'Ca':0.232,'K':0.0189}
BASEION={'Cl':24,'Na':21,'Mg':1,'Ca':6,'K':1}
WATER={'H':60,'O':30}
def medium(cl=1.75):
    sc=cl/REF['Cl']; d=dict(WATER)
    for e,n in BASEION.items(): d[e]=max(1,int(round(n*sc)))
    return d

def expand(d):
    out=[]
    for e,n in d.items(): out += [e]*int(n)
    return out

def shallow_init(n, seed, Rxy=16.0, h=5.0):
    rng=np.random.default_rng(seed)
    th=2*np.pi*rng.random(n); rr=Rxy*np.sqrt(rng.random(n)); z=(rng.random(n)-0.5)*h
    return np.c_[rr*np.cos(th),rr*np.sin(th),z]

def matrices(elements,W):
    n=len(elements); rad=np.array([r.RAD[e] for e in elements],float)
    r0=rad[:,None]+rad[None,:]; np.fill_diagonal(r0,1.0)
    WM=np.ones((n,n))
    for i in range(n):
      for j in range(i+1,n): WM[i,j]=WM[j,i]=np.clip(W[(elements[i],elements[j])],.03,8.)
    return rad,r0,WM

def phase_relax(x,elements,W,steps,h=5.0,dt0=.028,localized=None):
    n=len(elements); rad,r0,WM=matrices(elements,W)
    last=None
    for t in range(steps):
      dv=x[None,:,:]-x[:,None,:]; d=np.linalg.norm(dv,axis=2); np.fill_diagonal(d,np.inf)
      u=dv/np.where(np.isfinite(d),d,1)[:,:,None]
      far=d>r0; near=d<r0
      mf=np.where(far,np.minimum(1.,(r0/np.where(np.isfinite(d),d,1))**2)*WM,0)
      mn=np.where(near,np.clip((r0-d)/r0,0,1)*WM,0)
      f=((mf-mn)[:,:,None]*u).sum(axis=1)/max(1,n-1)
      # open shallow-water vertical confinement: soft restoring only at water-column limits
      z=x[:,2]; over=np.maximum(np.abs(z)-h/2,0); f[:,2] += -0.12*np.sign(z)*over
      if localized is not None:
        # declared localized manifold impulse: radial outward field from a bottom-localized source
        center=np.array([0.,0.,-h/2])
        vv=x-center; dd=np.linalg.norm(vv,axis=1)+1e-9
        f += localized*(vv/dd[:,None])*np.exp(-(dd/5.0)**2)[:,None]
      f-=f.mean(axis=0)
      dt=dt0*(.35+.65*(1-t/max(1,steps)))
      dx=dt*f; x+=dx
      # retain only shallow-water constraint, no lateral wall
      x[:,2]=np.clip(x[:,2],-h/2,h/2)
      last=float(np.sqrt(np.mean(dx*dx)))
    x-=x.mean(axis=0)
    return x,last

def contacts(x,elements,tol=1.08):
    rad=np.array([r.RAD[e] for e in elements],float); r0=rad[:,None]+rad[None,:]
    d=np.linalg.norm(x[None,:,:]-x[:,None,:],axis=2)
    A=(d<=tol*r0); np.fill_diagonal(A,False)
    return A

def graph_stats(A):
    n=A.shape[0]; seen=np.zeros(n,bool); comps=[]
    for s in range(n):
      if seen[s]: continue
      stack=[s];seen[s]=1;c=[]
      while stack:
        i=stack.pop();c.append(i)
        for j in np.flatnonzero(A[i]):
          if not seen[j]: seen[j]=1;stack.append(j)
      comps.append(c)
    E=int(np.triu(A,1).sum()); C=len(comps); cycle_rank=E-n+C
    largest=max(map(len,comps)) if comps else 0
    return {'edges':E,'components':C,'largest_component':largest,'cycle_rank':int(cycle_rank)}

def local_enclosure(x,elements):
    # fraction of nodes strictly inside convex hull of outer 30% by xy-radius, if hull exists
    rho=np.linalg.norm(x[:,:2],axis=1); cut=np.quantile(rho,.70); mask=rho>=cut
    pts=x[mask]
    if len(pts)<4:return {'outer_nodes':int(mask.sum()),'enclosed_fraction':0.0,'hull_volume':0.0}
    try:
      h=ConvexHull(pts); eq=h.equations
      inside=np.all(x@eq[:,:3].T + eq[:,3] <= 1e-9,axis=1)
      inner=~mask
      frac=float(np.mean(inside[inner])) if inner.any() else 0.0
      return {'outer_nodes':int(mask.sum()),'enclosed_fraction':frac,'hull_volume':float(h.volume)}
    except Exception:
      return {'outer_nodes':int(mask.sum()),'enclosed_fraction':0.0,'hull_volume':0.0}

def snap(x,elements,prevA=None):
    A=contacts(x,elements); g=graph_stats(A); enc=local_enclosure(x,elements)
    persist=None
    if prevA is not None:
      old=int(np.triu(prevA,1).sum()); both=int(np.triu(A & prevA,1).sum()); persist=(both/old if old else 0.0)
    return A, {**g,**enc,'contact_persistence_from_prev_dark':persist}

def run(seed, volcanic=False, cycles=6, cl=1.75):
    elements=expand(r.POOLS['B_ionic'])+expand(medium(cl))
    x=shallow_init(len(elements),seed)
    phases=[('dawn',0.5,25),('day',1.0,35),('dusk',0.5,25),('night',0.0,40)]
    hist=[]; prev_dark=None
    for c in range(cycles):
      ph=[]
      for name,eps,steps in phases:
        impulse=None
        # one intermittent bottom-localized perturbation on cycle 3 daylight only
        if volcanic and c==2 and name=='day': impulse=.20
        x,rms=phase_relax(x,elements,WE[eps],steps,h=5.0,localized=impulse)
        if name=='night':
          A,st=snap(x,elements,prev_dark); prev_dark=A.copy(); st.update({'cycle':c+1,'phase':name,'epsilon':eps,'rms':rms,'volcanic_impulse':bool(impulse)})
          hist.append(st)
    # ratchet: compare dark endpoints first vs last
    first,last=hist[0],hist[-1]
    ratchet={
      'edge_delta':last['edges']-first['edges'],
      'cycle_rank_delta':last['cycle_rank']-first['cycle_rank'],
      'largest_component_delta':last['largest_component']-first['largest_component'],
      'enclosed_fraction_delta':last['enclosed_fraction']-first['enclosed_fraction'],
      'persistent_last':last['contact_persistence_from_prev_dark'],
      'positive_structural_ratchet': bool((last['cycle_rank']>first['cycle_rank'] and last['largest_component']>=first['largest_component']) or last['enclosed_fraction']>first['enclosed_fraction']+.05)
    }
    return {'seed':seed,'volcanic':volcanic,'nodes':len(elements),'Cl_M':cl,'water_height_native':5.0,'history':hist,'ratchet':ratchet}

runs=[]
for volcanic in [False,True]:
  for seed in [6701]: runs.append(run(seed,volcanic,cycles=4))
out={'run_id':'R67_SHALLOW_OPEN_WATER_DAY_NIGHT_RATCHET','contract':{'environment':'sterile shallow open aqueous/brine pool; no biological structure','Cl_M':1.75,'day_night_epsilon':[0.5,1.0,0.5,0.0],'cycles':4,'water_height_native':5.0,'volcanic_branch':'single declared localized bottom-field impulse on cycle 3 daylight; qualitative perturbation only, not mapped to geological energy'},'runs':runs}
out['summary']={
 'daynight_only_passes':sum(q['ratchet']['positive_structural_ratchet'] for q in runs if not q['volcanic']),
 'daynight_volcanic_passes':sum(q['ratchet']['positive_structural_ratchet'] for q in runs if q['volcanic']),
 'of_each':1
}
Path('/mnt/data/continuum_run/SEAM_SHALLOW_DAYNIGHT_RATCHET_R67.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'summary':out['summary'],'runs':[{'seed':q['seed'],'volcanic':q['volcanic'],'ratchet':q['ratchet'],'dark_cycle_rank':[h['cycle_rank'] for h in q['history']],'dark_edges':[h['edges'] for h in q['history']],'enclosure':[round(h['enclosed_fraction'],3) for h in q['history']]} for q in runs]},indent=2))
