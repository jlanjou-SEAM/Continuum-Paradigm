#!/usr/bin/env python3
"""Reproduce R79 final dense audit from the retained R78 checkpoint/evaluator.
This script was reconstructed for the full-cycle archive from the locked R79 contract.
It does not alter the mathematical contract: same R63/R78 checkpoint, local field,
seeds 79001..79003, and 2^17 Sobol quadrature.
"""
import json, importlib.util
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/continuum_run'); HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r78', HERE/'r78_compartment_promoted_chain.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
ck=json.load(open(ROOT/'SEAM_R63_COMPARTMENT_CHECKPOINT_R78A.json'))
x=np.asarray(ck['coordinates'],float); elements=ck['elements']
rows=[]
for chain in ['C','N']:
    vals=[]; meta=None
    for seed in [79001,79002,79003]:
        v,meta=r.reaction_test(x,elements,chain,seed,pow=17); vals.append(v)
    accepted=all(v['parent_adv_1']>0 and v['parent_adv_0.5']>0 and v['parent_adv_0']>0 and v['promoted_add_0.5']>0 and v['enhance_0.5']>0 and v['promoted_add_0']>0 for v in vals)
    keys=['parent_adv_1','parent_adv_0.5','parent_adv_0','promoted_add_0.5','enhance_0.5','promoted_add_0']
    rows.append({'chain':f'{chain}-O* + Na','accepted':accepted,'vals':vals,'meta':meta,'means':{k:float(np.mean([v[k] for v in vals])) for k in keys}})
out={'run_id':'R79_FINAL_COMPARTMENT_PROMOTED_CHAIN_AUDIT','contract':'same serialized R78A R63-like checkpoint; local complete field within 7 native units; 3 independent Sobol x 2^17; exact comparator geometry; strict dark-retention criterion','rows':rows,'accepted_count':sum(x['accepted'] for x in rows)}
(ROOT/'SEAM_FINAL_COMPARTMENT_PROMOTED_CHAIN_R79_REPRODUCED.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'accepted_count':out['accepted_count'],'means':[x['means'] for x in rows]},indent=2))
