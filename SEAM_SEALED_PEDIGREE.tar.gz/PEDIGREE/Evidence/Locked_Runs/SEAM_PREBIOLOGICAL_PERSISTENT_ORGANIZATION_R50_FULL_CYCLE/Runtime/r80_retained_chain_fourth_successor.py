#!/usr/bin/env python3
import json, math, importlib.util
from pathlib import Path
import numpy as np
from scipy.stats import qmc

ROOT=Path('/mnt/data/continuum_run')
HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r78', HERE/'r78_compartment_promoted_chain.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
ck=json.load(open(ROOT/'SEAM_R63_COMPARTMENT_CHECKPOINT_R78A.json'))
x=np.asarray(ck['coordinates'],float); elements=list(ck['elements'])
CANDS=['H','C','N','O','P','S','Na','Mg','Cl','K','Ca']
CHAINS=['C','N']
DIRS=np.array([[1,0,0],[0,1,0],[0,0,1]],float)

# Same local complete field extraction used by R78.
def local_env(chain):
    rr=np.linalg.norm(x,axis=1); Oidx=[i for i,e in enumerate(elements) if e=='O']; oi=min(Oidx,key=lambda i:rr[i]); origin=x[oi].copy()
    locidx=np.where(np.linalg.norm(x-origin,axis=1)<=7.0)[0]
    remove={oi}
    for typ in [chain,'Na']:
        cand=[i for i,e in enumerate(elements) if e==typ and i not in remove]
        remove.add(min(cand,key=lambda i:np.linalg.norm(x[i]-origin)))
    keep=[i for i in locidx if i not in remove]
    env_elements=[elements[i] for i in keep]; env_cent=x[keep]-origin
    shenv=np.vstack([r.AT[e] for e in env_elements]) if env_elements else np.empty((0,7),int)
    return shenv,env_cent,len(env_elements)

def chain_geom(a):
    # Reproduce R78 parent and retained Na geometry.
    base=np.vstack([r.AT[a],r.AT['O']]); psh=base.copy(); psh[1]=r.promoted(r.AT['O'])
    d=.88*(r.outer(r.AT[a])+r.outer(r.AT['O']))
    pc=np.array([[-d/2,0,0],[d/2,0,0]],float)
    dNa=.88*((r.outer(r.AT[a])+r.outer(r.AT['O']))/2+r.outer(r.AT['Na']))
    na_near=np.array([0,dNa,0.],float); na_far=np.array([0,12.,0.],float)
    return psh,pc,na_near,na_far

def t_near_pos(a,t,direction):
    # Add around retained 3-node chain COM at native near-contact radius.
    meanr=(r.outer(r.AT[a])+r.outer(r.AT['O'])+r.outer(r.AT['Na']))/3
    dt=.88*(meanr+r.outer(r.AT[t]))
    return direction*dt

def eval_case(a,t,direction,seed,pow=14):
    shenv,envcent,nenv=local_env(a); psh,pc,na_near,na_far=chain_geom(a)
    tn=t_near_pos(a,t,direction); tf=np.array([0.,0.,13.])
    # avoid exact overlap if direction accidentally puts t on another node: slight deterministic tilt
    if np.min(np.linalg.norm(np.vstack([pc,na_near])-tn,axis=1))<0.25:
        tn=tn+np.array([.31,.17,.23])
    lo=np.array([-14.,-14.,-14.]);hi=-lo
    pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
    def state(na_pos,t_pos):
        sh=np.vstack([shenv,psh,r.AT['Na'],r.AT[t]])
        ce=np.vstack([envcent,pc,na_pos,t_pos])
        return sh,ce
    out={'seed':seed,'env_nodes':nenv}
    for eps in [.5,0.]:
        sh, c11=state(na_near,tn); _,c10=state(na_near,tf)
        _, c01=state(na_far,tn); _,c00=state(na_far,tf)
        s11=r.eval_fixed(sh,c11,eps,pts,lo,hi); s10=r.eval_fixed(sh,c10,eps,pts,lo,hi)
        s01=r.eval_fixed(sh,c01,eps,pts,lo,hi); s00=r.eval_fixed(sh,c00,eps,pts,lo,hi)
        add_with=s11-s10; add_without=s01-s00
        out[f'add_with_chain_{eps:g}']=add_with
        out[f'add_without_Na_{eps:g}']=add_without
        out[f'chain_enhancement_{eps:g}']=add_with-add_without
    return out

# Coarse scan 1 Sobol per geometry, 2^14. Then validate best positives at 3x2^16 and multiple directions.
rows=[]
seed=80001
for a in CHAINS:
    for t in CANDS:
        best=None
        for di,dv in enumerate(DIRS):
            v=eval_case(a,t,dv,seed+di,pow=11)
            score=v['chain_enhancement_0.5']
            rec={'chain':a,'third':'Na','fourth':t,'dir':di,'vals':v,'score':score,
                 'coarse_pass':(v['add_with_chain_0.5']>0 and v['chain_enhancement_0.5']>0 and v['add_with_chain_0']>0)}
            if best is None or score>best['score']: best=rec
        rows.append(best)
coarse_hits=[z for z in rows if z['coarse_pass']]
coarse_hits=sorted(coarse_hits,key=lambda z:z['score'],reverse=True)

# Validate top up to 8 unique chain/fourth candidates, preserving best direction plus two neighboring directions.
validated=[]
for rec in coarse_hits[:5]:
    a,t=rec['chain'],rec['fourth']; dirs=list(range(len(DIRS)))
    vals=[]
    for si,s in enumerate([81001,81002,81003]):
        # strongest coarse direction fixed for falsification; directions separately audited below.
        vals.append(eval_case(a,t,DIRS[rec['dir']],s,pow=14))
    strict=all(v['add_with_chain_0.5']>0 and v['chain_enhancement_0.5']>0 and v['add_with_chain_0']>0 for v in vals)
    dir_audit=[]
    for di in dirs:
        vv=eval_case(a,t,DIRS[di],82000+di,pow=13)
        dir_audit.append({'dir':di,**vv})
    robust_dirs=sum(v['add_with_chain_0.5']>0 and v['chain_enhancement_0.5']>0 and v['add_with_chain_0']>0 for v in dir_audit)
    validated.append({'chain':f'{a}-O*-Na','fourth':t,'best_dir':rec['dir'],'strict_3seed':strict,
                      'robust_dirs':robust_dirs,'vals':vals,'dir_audit':dir_audit,
                      'means':{k:float(np.mean([v[k] for v in vals])) for k in ['add_with_chain_0.5','add_without_Na_0.5','chain_enhancement_0.5','add_with_chain_0','chain_enhancement_0']}})

out={'run_id':'R80_RETAINED_CHAIN_FOURTH_SUCCESSOR',
     'contract':'Actual serialized R63 local compartment field; retained promoted-O + Na parent from R79; scan fourth constituent association. Criterion: fourth association positive with retained chain at epsilon=.5, enhanced vs same promoted parent with Na absent/far, and remains positive at epsilon=0. Coarse 3 orthogonal directions x 2^11; top candidates validated 3 independent Sobol x2^14 plus 3-direction 2^13 audit.',
     'coarse_tested':len(rows),'coarse_hits':len(coarse_hits),'coarse_top':coarse_hits[:12],
     'validated':validated,'validated_count':sum(v['strict_3seed'] for v in validated)}
(ROOT/'SEAM_RETAINED_CHAIN_FOURTH_SUCCESSOR_R80.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'coarse_tested':len(rows),'coarse_hits':len(coarse_hits),'validated_count':out['validated_count'],
                  'validated':[{'chain':v['chain'],'fourth':v['fourth'],'strict':v['strict_3seed'],'robust_dirs':v['robust_dirs'],'means':v['means']} for v in validated]},indent=2))
