#!/usr/bin/env python3
"""SEAM N-node complete-state uniform-shell evaluator.
Derived directly from canonical equations in 02_CONTINUUM_TECHNICAL_FOUNDATIONS.md §4.15 / Appendix S.
No empirical chemistry, bond, biological, or comparator inputs.

This is a new application runtime, not a modification of R4.
It evaluates a frozen N-node state C = ({S_i}, R) from node shell occupancies and center coordinates:
  F_C(xi)=sum_i,n sqrt(N_i,n) u_i,n(xi)
  q=|F|^2/int|F|^2
  S_field=-int q ln q
  O_ij^nm = Vol(shell_i,n ∩ shell_j,m)/sqrt(V_n V_m)
  S_coupling=sum_i<j,n,m rho_i,n rho_j,m O_ij^nm
  S_total=S_config+lambda_field*S_field+lambda_coupling*S_coupling
All values are reported in units of k_B.
"""
import math, json, argparse
from pathlib import Path
import numpy as np

RUNTIME_ID='NNODE-COMPLETE-STATE-R36'
CAP=np.array([2,8,18,32,18,32,18],dtype=int)
DEFAULT_LAMBDA_FIELD=1.0
DEFAULT_LAMBDA_COUPLING=0.1


def ball_intersection(R,r,d):
    if R<=0 or r<=0: return 0.0
    if d>=R+r: return 0.0
    if d<=abs(R-r): return 4.0*math.pi*min(R,r)**3/3.0
    return math.pi*(R+r-d)**2*(d*d+2*d*r-3*r*r+2*d*R+6*r*R-3*R*R)/(12*d)

def shell_intersection(n,m,d):
    return max(0.0, ball_intersection(n,m,d)-ball_intersection(n-1,m,d)-ball_intersection(n,m-1,d)+ball_intersection(n-1,m-1,d))

def shell_volume(n): return 4.0*math.pi*(n**3-(n-1)**3)/3.0


def sconfig(shells):
    s=0.0
    for row in shells:
        for n,N in enumerate(row):
            if N:
                s += math.log(math.comb(int(CAP[n]),int(N)))
    return s


def coupling(shells, centers):
    shells=np.asarray(shells,dtype=int); centers=np.asarray(centers,dtype=float)
    rho=shells/CAP[None,:]
    N=len(shells); total=0.0; pair_nonzero=0; max_overlap=0.0
    for i in range(N-1):
        ds=np.linalg.norm(centers[i+1:]-centers[i],axis=1)
        for off,d in enumerate(ds, start=i+1):
            pair_sum=0.0
            for n in np.nonzero(shells[i])[0]:
                for m in np.nonzero(shells[off])[0]:
                    O=shell_intersection(n+1,m+1,float(d))/math.sqrt(shell_volume(n+1)*shell_volume(m+1))
                    if O>0:
                        max_overlap=max(max_overlap,O)
                        pair_sum += rho[i,n]*rho[off,m]*O
            if pair_sum>0:
                pair_nonzero += 1
                total += pair_sum
    return total, pair_nonzero, max_overlap


def field_entropy_mc(shells, centers, samples=120000, seed=3601):
    """Deterministic quasi-MC-like uniform sampling of field support bounding box.
    Uses S_field = ln D - (1/D) int |F|^2 ln |F|^2, mathematically identical to -int q ln q.
    """
    shells=np.asarray(shells,dtype=int); centers=np.asarray(centers,dtype=float)
    occ=np.where(shells>0)
    max_shell=int(occ[1].max()+1) if len(occ[1]) else 1
    lo=centers.min(axis=0)-max_shell
    hi=centers.max(axis=0)+max_shell
    vol=float(np.prod(hi-lo))
    rng=np.random.default_rng(seed)
    pts=lo + rng.random((samples,3))*(hi-lo)
    f=np.zeros(samples,dtype=float)
    # chunk by nodes, vectorized over samples
    for i,row in enumerate(shells):
        d=np.linalg.norm(pts-centers[i],axis=1)
        for n,Nn in enumerate(row, start=1):
            if Nn<=0: continue
            mask=(d>=n-1) & (d<n)
            if mask.any():
                f[mask] += math.sqrt(float(Nn))/math.sqrt(shell_volume(n))
    f2=f*f
    mean_f2=float(f2.mean())
    D=vol*mean_f2
    pos=f2>0
    Ilog=vol*float(np.mean(np.where(pos,f2*np.log(np.where(pos,f2,1.0)),0.0)))
    Sf=math.log(D)-Ilog/D if D>0 else float('-inf')
    support_frac=float(pos.mean())
    # rough deterministic split-half residual
    h=samples//2
    def half(a):
        mf=float(a.mean()); Dh=vol*mf
        p=a>0; il=vol*float(np.mean(np.where(p,a*np.log(np.where(p,a,1.0)),0.0)))
        return math.log(Dh)-il/Dh if Dh>0 else float('-inf')
    residual=abs(half(f2[:h])-half(f2[h:2*h]))
    return Sf, {'D_mc':D,'bbox_volume':vol,'support_fraction':support_frac,'split_half_residual':residual,'samples':samples,'seed':seed}


def evaluate(shells, centers, lambda_field=DEFAULT_LAMBDA_FIELD, lambda_coupling=DEFAULT_LAMBDA_COUPLING, samples=120000, seed=3601):
    shells=np.asarray(shells,dtype=int); centers=np.asarray(centers,dtype=float)
    assert shells.ndim==2 and shells.shape[1]==7 and centers.shape==(len(shells),3)
    sc=sconfig(shells)
    sf,fd=field_entropy_mc(shells,centers,samples=samples,seed=seed)
    cp,npairs,maxo=coupling(shells,centers)
    st=sc+lambda_field*sf+lambda_coupling*cp
    return {
      'runtime_id':RUNTIME_ID,'node_count':len(shells),'lambda_field':lambda_field,'lambda_coupling':lambda_coupling,
      'S_total_over_kB':st,'S_config_over_kB':sc,'S_field_over_kB':sf,'S_coupling_over_kB':cp,
      'overlapping_node_pairs':npairs,'max_shell_overlap':maxo,'field_diagnostics':fd
    }

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('state_json'); ap.add_argument('--samples',type=int,default=120000)
    a=ap.parse_args(); obj=json.load(open(a.state_json))
    print(json.dumps(evaluate(obj['shells'],obj['centers'],obj.get('lambda_field',1.0),obj.get('lambda_coupling',0.1),a.samples,obj.get('seed',3601)),indent=2))
