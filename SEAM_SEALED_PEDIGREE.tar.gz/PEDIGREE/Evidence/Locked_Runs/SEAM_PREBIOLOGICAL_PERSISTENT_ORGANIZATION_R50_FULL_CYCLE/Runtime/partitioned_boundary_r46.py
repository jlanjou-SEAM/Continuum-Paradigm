#!/usr/bin/env python3
import sys,json,math,hashlib
from pathlib import Path
import numpy as np
from scipy.stats import qmc
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import reduced_aqueous_basin_r41 as r41
import boundary_geometry_r44 as r44
EPS=[0.0,0.5,1.0]; RAD=[4.0,5.5,7.0]; FRAC=[0.2,0.4,0.6,0.8]

def deterministic_partition(elements,frac):
    keyed=[]
    seen={}
    for i,e in enumerate(elements):
        k=seen.get(e,0); seen[e]=k+1
        h=int(hashlib.sha256(f'{e}:{k}:R46'.encode()).hexdigest()[:16],16)
        keyed.append((h,i))
    keyed.sort(); nb=max(3,min(len(elements)-1,round(frac*len(elements))))
    b=set(i for _,i in keyed[:nb]); return b

def interior_positions(n,radius,seed):
    rng=np.random.default_rng(seed)
    v=rng.normal(size=(n,3)); v/=np.linalg.norm(v,axis=1)[:,None]
    rr=(rng.random(n)**(1/3))*(0.45*radius)
    return v*rr[:,None]

def partition_geometry(elements,radius,frac):
    bidx=deterministic_partition(elements,frac); nb=len(bidx); ni=len(elements)-nb
    shell=r44.closed(nb,radius); inside=interior_positions(ni,radius,46000+len(elements)+int(frac*100))
    out=np.zeros((len(elements),3)); ib=0; ii=0
    for k in range(len(elements)):
        if k in bidx: out[k]=shell[ib]; ib+=1
        else: out[k]=inside[ii]; ii+=1
    return out,nb,ni

def run_branch(pn,mn):
    pels=r41.expand(r41.POOLS[pn]); mels=r41.expand(r41.MEDIA[mn]); els=pels+mels
    sh=np.asarray([r41.AT[e] for e in els],int); sc=r41.sconfig(sh)
    med=r41.medium_positions(len(mels), seed=44500+len(pels)+(0 if mn=='fresh' else 77),inner=12.0,outer=18.0)
    maxshell=max(np.nonzero(sh)[1])+1; L=22+maxshell; lo=np.array([-L]*3,float); hi=-lo; vol=float(np.prod(hi-lo))
    sob=qmc.Sobol(d=3,scramble=True,seed=46200+len(pels)+(0 if mn=='fresh' else 500)); pts=lo+sob.random_base2(m=10)*(hi-lo)
    rows=[]
    for eps in EPS:
      for rad in RAD:
        # comparators
        for gn,gf in [('compact',r44.compact),('closed_shell',r44.closed)]:
          cand=gf(len(pels),rad); sf,cp,d=r44.eval_state(sh,np.vstack([cand,med]),eps,pts,vol,rad)
          rows.append({'epsilon':eps,'radius':rad,'geometry':gn,'boundary_fraction':1.0 if gn=='closed_shell' else 0.0,'S_total_over_kB':sc+sf+r41.LAM_C*cp,'S_field_over_kB':sf,'S_coupling_over_kB':cp,**d})
        for frac in FRAC:
          cand,nb,ni=partition_geometry(pels,rad,frac); sf,cp,d=r44.eval_state(sh,np.vstack([cand,med]),eps,pts,vol,rad)
          rows.append({'epsilon':eps,'radius':rad,'geometry':'partitioned_compartment','boundary_fraction':frac,'boundary_nodes':nb,'interior_nodes':ni,'S_total_over_kB':sc+sf+r41.LAM_C*cp,'S_field_over_kB':sf,'S_coupling_over_kB':cp,**d})
    winners=[]
    for eps in EPS:
      rr=[x for x in rows if x['epsilon']==eps]
      best=max(rr,key=lambda x:x['S_total_over_kB'])
      bestpart=max([x for x in rr if x['geometry']=='partitioned_compartment'],key=lambda x:x['S_total_over_kB'])
      comp=max([x for x in rr if x['geometry']!='partitioned_compartment'],key=lambda x:x['S_total_over_kB'])
      winners.append({'epsilon':eps,'best_geometry':best['geometry'],'best_radius':best['radius'],'best_boundary_fraction':best.get('boundary_fraction'),'partition_best_radius':bestpart['radius'],'partition_best_fraction':bestpart['boundary_fraction'],'partition_delta_vs_best_comparator':bestpart['S_total_over_kB']-comp['S_total_over_kB'],'partition_q_contrast':bestpart['q_contrast'],'partition_pass':bool(bestpart['S_total_over_kB']>comp['S_total_over_kB'] and abs(bestpart['q_contrast'])>1e-4)})
    return {'pool':pn,'medium':mn,'rows':rows,'winners':winners}

def main():
    branches=[run_branch(p,m) for p in r41.POOLS for m in r41.MEDIA]
    passes=[{'pool':b['pool'],'medium':b['medium'],**w} for b in branches for w in b['winners'] if w['partition_pass']]
    out={'run_id':'SEAM-PARTITIONED-BOUNDARY-R46','contract':'STERILE-AQUEOUS-PARTITIONED-COMPARTMENT-R46','rules':{'partition':'deterministic composition-agnostic subset of candidate nodes assigned to closed boundary; remainder placed inside; no molecular connectivity or biological identity','boundary_fractions':FRAC,'radii':RAD,'quadrature':'common fixed-domain scrambled Sobol 2^10 coarse search','acceptance':'partitioned compartment must exceed compact and whole-shell comparators and retain nonzero inside/outside q contrast'},'branches':branches,'passes':passes,'disposition':'PARTITIONED_BOUNDARY_ATTRACTOR_FOUND' if passes else 'NO_PARTITIONED_BOUNDARY_ATTRACTOR_FOUND'}
    p=Path('/mnt/data/continuum_run/SEAM_PARTITIONED_BOUNDARY_R46.json');p.write_text(json.dumps(out,indent=2));print(json.dumps({'disposition':out['disposition'],'passes':passes,'summary':[{'pool':b['pool'],'medium':b['medium'],'winners':b['winners']} for b in branches]},indent=2));print(p)
if __name__=='__main__':main()
