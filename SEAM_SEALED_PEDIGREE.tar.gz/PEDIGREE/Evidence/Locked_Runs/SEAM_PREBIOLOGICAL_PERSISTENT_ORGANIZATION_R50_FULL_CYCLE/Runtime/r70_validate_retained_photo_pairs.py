#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
import importlib.util
HERE=Path('/mnt/data/continuum_run/Evidence/Runtime')
spec=importlib.util.spec_from_file_location('r69',HERE/'r69_retained_photo_pair_search.py'); r69=importlib.util.module_from_spec(spec); spec.loader.exec_module(r69)
AT=r69.AT
lo=np.array([-12.,-12.,-12.]); hi=-lo
r69out=json.load(open('/mnt/data/continuum_run/SEAM_RETAINED_PHOTO_PAIR_SEARCH_R69.json'))
cs=r69out['candidates']
rows=[]
for c in cs:
 a,b=c['pair'].split('-'); d=c['best']['d']; sh=np.asarray([AT[a],AT[b]],int); contact=c['contact']; sep=contact+2.0
 for seed in [70001,70002,70003]:
  sob=qmc.Sobol(3,scramble=True,seed=seed); pts=lo+sob.random_base2(17)*(hi-lo)
  cent=np.array([[-d/2,0,0],[d/2,0,0]],float); csep=np.array([[-sep/2,0,0],[sep/2,0,0]],float)
  rec={'pair':c['pair'],'seed':seed,'d':d}
  for eps in [1.0,.5,0.0]: rec[f'dS_{eps:g}']=r69.eval_fixed(sh,cent,eps,pts,lo,hi)-r69.eval_fixed(sh,csep,eps,pts,lo,hi)
  rows.append(rec)
summary=[]
for c in cs:
 rr=[r for r in rows if r['pair']==c['pair']]
 s={'pair':c['pair'],'forms_all_light':all(r['dS_1']>0 for r in rr),'retains_all_mod':all(r['dS_0.5']>0 for r in rr),'retains_all_dark':all(r['dS_0']>0 for r in rr),
    'mean_light':float(np.mean([r['dS_1'] for r in rr])),'mean_mod':float(np.mean([r['dS_0.5'] for r in rr])),'mean_dark':float(np.mean([r['dS_0'] for r in rr])),
    'vals':rr}
 summary.append(s)
accepted=[s for s in summary if s['forms_all_light'] and (s['retains_all_mod'] or s['retains_all_dark'])]
out={'run_id':'R70_VALIDATE_RETAINED_PHOTO_PAIRS','contract':'3 independent Sobol scrambles x 2^17 fixed-domain points; same R69 geometries; acceptance requires positive light formation across all seeds and positive retention at eps=.5 or 0 across all seeds','summary':summary,'accepted':accepted,'accepted_count':len(accepted)}
p=Path('/mnt/data/continuum_run/SEAM_RETAINED_PHOTO_PAIR_VALIDATE_R70.json'); p.write_text(json.dumps(out,indent=2))
print(json.dumps({'accepted_count':len(accepted),'accepted':[{k:s[k] for k in ['pair','forms_all_light','retains_all_mod','retains_all_dark','mean_light','mean_mod','mean_dark']} for s in accepted]},indent=2)); print(p)
