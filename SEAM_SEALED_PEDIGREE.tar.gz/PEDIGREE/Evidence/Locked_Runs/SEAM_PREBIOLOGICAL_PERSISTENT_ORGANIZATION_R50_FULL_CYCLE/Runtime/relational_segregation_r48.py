#!/usr/bin/env python3
import sys, math, json, hashlib
from pathlib import Path
import numpy as np
from scipy.stats import qmc
from scipy.spatial import ConvexHull
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import reduced_aqueous_basin_r41 as r41

ROLES=('B','I','O')
RADII=(4.5,5.5,6.5)
EPS=(0.0,0.5,1.0)


def unit_from_key(key):
    h=hashlib.sha256(key.encode()).digest()
    # deterministic pseudo-random normal direction
    seed=int.from_bytes(h[:8],'big') & 0xFFFFFFFF
    rng=np.random.default_rng(seed)
    v=rng.normal(size=3); v/=np.linalg.norm(v)
    return v, rng

def role_position(el,k,role,R):
    v,rng=unit_from_key(f'R48:{el}:{k}:{role}')
    if role=='B':
        return v*R
    if role=='I':
        rr=(0.10+0.35*(rng.random()**(1/3)))*R
        return v*rr
    # local exterior, not bulk reservoir
    rr=(1.20+0.45*rng.random())*R
    return v*rr

def atom_field(row,center,eps,pts,norms):
    d=np.linalg.norm(pts-center,axis=1)
    f=np.zeros(len(pts)); g=np.zeros(len(pts))
    for n,N in enumerate(row,1):
        if N<=0: continue
        mask=(d>=n-1)&(d<n)
        if not mask.any(): continue
        x=d[mask]-(n-1)
        u=((1-eps)+eps*(1-x))/norms[n]
        f[mask]+=math.sqrt(float(N))*u
        g[mask]+=(float(N)/r41.CAP[n-1])*u
    return f,g,g*g

def medium_precompute(mels,centers,eps,pts,norms):
    F=np.zeros(len(pts)); G=np.zeros(len(pts)); G2=np.zeros(len(pts))
    for el,c in zip(mels,centers):
        f,g,g2=atom_field(np.asarray(r41.AT[el]),c,eps,pts,norms)
        F+=f; G+=g; G2+=g2
    return F,G,G2

def build_class_precompute(pool_counts,R,eps,pts,norms):
    out={}
    positions={}
    for el,count in pool_counts.items():
        out[el]={}; positions[el]={}
        for role in ROLES:
            F=np.zeros(len(pts)); G=np.zeros(len(pts)); G2=np.zeros(len(pts)); pos=[]
            for k in range(count):
                c=role_position(el,k,role,R); pos.append(c)
                f,g,g2=atom_field(np.asarray(r41.AT[el]),c,eps,pts,norms)
                F+=f; G+=g; G2+=g2
            out[el][role]=(F,G,G2)
            positions[el][role]=np.asarray(pos)
    return out,positions

def eval_assign(assign,pre,Fm,Gm,G2m,vol,sc,pts,R):
    F=Fm.copy(); G=Gm.copy(); G2=G2m.copy()
    for el,role in assign.items():
        f,g,g2=pre[el][role]; F+=f; G+=g; G2+=g2
    f2=F*F; D=vol*float(f2.mean())
    if D<=0: return -math.inf,0,0,0,0
    pos=f2>0
    ilog=vol*float(np.mean(np.where(pos,f2*np.log(np.where(pos,f2,1.0)),0.0)))
    sf=math.log(D)-ilog/D
    cp=0.5*vol*float(np.mean(G*G-G2))
    total=sc+sf+r41.LAM_C*cp
    q=f2/D; rr=np.linalg.norm(pts,axis=1)
    im=rr<0.55*R; om=(rr>1.15*R)&(rr<1.75*R)
    qin=float(q[im].mean()) if im.any() else 0.0
    qout=float(q[om].mean()) if om.any() else 0.0
    contrast=(qin-qout)/(abs(qin)+abs(qout)+1e-30)
    return total,sf,cp,qin,qout,contrast

def boundary_closed(assign,positions,pool_counts):
    pts=[]
    for el,r in assign.items():
        if r=='B': pts.extend(positions[el]['B'])
    pts=np.asarray(pts,float)
    if len(pts)<8: return False,0.0
    try:
        hull=ConvexHull(pts)
        # origin inside hull iff all plane inequalities <= 0
        inside=bool(np.all(hull.equations[:,-1] <= 1e-9))
        coverage=float(hull.volume / ((4/3)*math.pi*(np.mean(np.linalg.norm(pts,axis=1))**3)))
        return inside,coverage
    except Exception:
        return False,0.0

def counts_by_role(assign,pool_counts):
    d={r:0 for r in ROLES}
    for el,r in assign.items(): d[r]+=pool_counts[el]
    return d

def coordinate_ascent(elements,pool_counts,pre,Fm,Gm,G2m,vol,sc,pts,R,seed,nrestart=24):
    rng=np.random.default_rng(seed)
    starts=[]
    starts.append({el:'I' for el in elements})
    starts.append({el:'B' if i%3==0 else 'I' for i,el in enumerate(elements)})
    starts.append({el:'O' if i%4==0 else ('B' if i%3==0 else 'I') for i,el in enumerate(elements)})
    while len(starts)<nrestart:
        starts.append({el:ROLES[int(rng.integers(0,3))] for el in elements})
    best=None
    for si,a0 in enumerate(starts):
        a=dict(a0); cur=eval_assign(a,pre,Fm,Gm,G2m,vol,sc,pts,R)[0]
        changed=True; passes=0
        while changed and passes<20:
            changed=False; passes+=1
            order=list(elements); rng.shuffle(order)
            for el in order:
                old=a[el]; local=(cur,old)
                for role in ROLES:
                    if role==old: continue
                    a[el]=role
                    val=eval_assign(a,pre,Fm,Gm,G2m,vol,sc,pts,R)[0]
                    if val>local[0]+1e-10: local=(val,role)
                a[el]=local[1]
                if local[1]!=old: cur=local[0]; changed=True
                else: a[el]=old
        ev=eval_assign(a,pre,Fm,Gm,G2m,vol,sc,pts,R)
        rec=(ev[0],dict(a),ev,si,passes)
        if best is None or rec[0]>best[0]: best=rec
    return best

def run_case(pn,mn,R,eps,seed_offset=0,m=12,restarts=24):
    pool=r41.POOLS[pn]; elements=list(pool)
    pels=r41.expand(pool); mels=r41.expand(r41.MEDIA[mn])
    sh=np.asarray([r41.AT[e] for e in pels+mels],int); sc=r41.sconfig(sh)
    maxshell=max(np.nonzero(sh)[1])+1; L=22.0+maxshell
    lo=np.array([-L]*3,float); hi=-lo; vol=float(np.prod(hi-lo))
    sob=qmc.Sobol(d=3,scramble=True,seed=48000+seed_offset+len(pels)+(0 if mn=='fresh' else 700)+int(R*10)+int(eps*100))
    pts=lo+sob.random_base2(m=m)*(hi-lo)
    norms={n:math.sqrt(r41.norm2(n,eps)) for n in range(1,maxshell+1)}
    med=r41.medium_positions(len(mels), seed=44500+len(pels)+(0 if mn=='fresh' else 77),inner=12.0,outer=18.0)
    Fm,Gm,G2m=medium_precompute(mels,med,eps,pts,norms)
    pre,pos=build_class_precompute(pool,R,eps,pts,norms)
    best=coordinate_ascent(elements,pool,pre,Fm,Gm,G2m,vol,sc,pts,R,seed=49000+seed_offset+len(pels)+int(eps*100),nrestart=restarts)
    base={el:'I' for el in elements}; base_ev=eval_assign(base,pre,Fm,Gm,G2m,vol,sc,pts,R)
    assignment=best[1]; ev=best[2]
    closed,cov=boundary_closed(assignment,pos,pool); rc=counts_by_role(assignment,pool)
    delta=ev[0]-base_ev[0]
    candidate_pass=bool(closed and rc['I']>0 and rc['B']>=8 and delta>0 and abs(ev[5])>1e-4)
    return {
      'pool':pn,'medium':mn,'radius':R,'epsilon':eps,'quadrature_m':m,'restarts':restarts,
      'assignment':assignment,'role_counts':rc,'boundary_closed':closed,'boundary_hull_volume_fraction':cov,
      'S_total_over_kB':ev[0],'S_field_over_kB':ev[1],'S_coupling_over_kB':ev[2],
      'q_inside_mean':ev[3],'q_outside_mean':ev[4],'q_contrast':ev[5],
      'all_interior_S_total_over_kB':base_ev[0],'delta_vs_all_interior':delta,'candidate_pass':candidate_pass,
      'restart_index':best[3],'coordinate_passes':best[4]
    }

def main():
    # Coarse role-optimization sweep. Trace pool gets fewer restarts but same criteria.
    rows=[]
    for pn in r41.POOLS:
      for mn in r41.MEDIA:
        for eps in EPS:
          for R in RADII:
            rows.append(run_case(pn,mn,R,eps,m=11,restarts=18 if pn!='C_trace' else 14))
    candidates=[r for r in rows if r['candidate_pass']]
    # Refine top candidate per pool-medium-epsilon (if any), using two independent denser quadratures.
    refined=[]
    keys={}
    for r in candidates:
        key=(r['pool'],r['medium'],r['epsilon'])
        if key not in keys or r['delta_vs_all_interior']>keys[key]['delta_vs_all_interior']: keys[key]=r
    for key,r in keys.items():
        reps=[]
        for so in (0,100000):
            reps.append(run_case(r['pool'],r['medium'],r['radius'],r['epsilon'],seed_offset=so,m=13,restarts=32))
        survive=all(x['candidate_pass'] for x in reps)
        refined.append({'source':r,'replicates':reps,'survives':survive})
    out={
      'run_id':'SEAM-RELATIONAL-SEGREGATION-R48',
      'contract':'ELEMENT-CLASS-ROLE-SEGREGATION-R48',
      'rules':{
        'optimization':'Each candidate element class chooses boundary, interior, or local exterior as a class; no molecules/connectivity/biological identity.',
        'boundary':'Boundary-role atoms occupy deterministic spherical surface slots; interior and local-exterior roles use deterministic radial slots.',
        'comparator':'Same material and environment with every candidate element class assigned to interior.',
        'closure_gate':'Convex hull of boundary-role atoms must enclose origin; >=8 boundary atoms and nonzero interior required.',
        'acceptance':'Entropy must exceed all-interior comparator and retain nonzero inside/outside q contrast; coarse successes require two independent denser replications.'
      },
      'coarse_rows':rows,'coarse_candidates':candidates,'refined':refined,
      'disposition':'SEGREGATED_BOUNDARY_ATTRACTOR_REPRODUCED' if any(x['survives'] for x in refined) else ('COARSE_SEGREGATION_ONLY' if candidates else 'NO_SEGREGATED_BOUNDARY_ATTRACTOR')
    }
    p=Path('/mnt/data/continuum_run/SEAM_RELATIONAL_SEGREGATION_R48.json'); p.write_text(json.dumps(out,indent=2))
    print(json.dumps({'disposition':out['disposition'],'n_coarse':len(candidates),'survivors':[{'pool':x['source']['pool'],'medium':x['source']['medium'],'epsilon':x['source']['epsilon'],'radius':x['source']['radius'],'assignment':x['source']['assignment'],'coarse_delta':x['source']['delta_vs_all_interior'],'replicate_deltas':[y['delta_vs_all_interior'] for y in x['replicates']]} for x in refined if x['survives']]},indent=2))
    print(p)
if __name__=='__main__': main()
