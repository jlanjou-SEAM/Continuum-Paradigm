#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import qmc

ROOT=Path('/mnt/data/continuum_run')
BASE=json.load(open(ROOT/'SEAM_IONIC_PAIR_WEIGHTED_R56.json'))
R63=json.load(open(ROOT/'SEAM_ARCHAEAN_EXCITATION_SCREEN_R63A.json'))
MATRIX=ROOT/'Evidence/Data/Z001_Z128_Blind_Matrix/Z001_Z128_ATOMIC_SHELL_MATRIX.csv'
# fallback matrix location from original archive tree if Evidence/Data absent
if not MATRIX.exists():
    MATRIX=Path('/mnt/data/continuum_paradigm/Evidence/Data/Z001_Z128_Blind_Matrix/Z001_Z128_ATOMIC_SHELL_MATRIX.csv')
Z={'H':1,'C':6,'N':7,'O':8,'Na':11,'Mg':12,'P':15,'S':16,'Cl':17,'K':19,'Ca':20}
CAP=np.array([2,8,18,32,18,32,18],int); LAMC=.1
POOLS={'B_ionic':{'C':30,'H':51,'O':12,'N':7,'P':1,'S':1,'K':2,'Na':1,'Mg':1,'Ca':1,'Cl':1}}
REF={'Cl':0.92,'Na':0.789,'Mg':0.0509,'Ca':0.232,'K':0.0189}; BASEION={'Cl':24,'Na':21,'Mg':1,'Ca':6,'K':1}; WATER={'H':60,'O':30}

def expand(d):
    out=[]
    for e,n in d.items(): out += [e]*int(n)
    return out

def medium(cl=1.75):
    sc=cl/REF['Cl']; d=dict(WATER)
    for e,n in BASEION.items(): d[e]=max(1,int(round(n*sc)))
    return d

def fill(e):
    rem=max(0,int(e));out=[]
    for c in CAP:
        n=min(rem,int(c));out.append(n);rem-=n
    return np.array(out,int)
AT={e:fill(z) for e,z in Z.items()}

def outer(sh):
    nz=np.flatnonzero(sh); return int(nz[-1]+1) if len(nz) else 1
RAD={e:outer(AT[e]) for e in Z}

def promoted(sh):
    x=sh.copy();nz=np.flatnonzero(x)
    if not len(nz): return None
    j=nz[-1]
    for k in range(j+1,len(CAP)):
        if x[k]<CAP[k]: x[j]-=1;x[k]+=1;return x
    return None

def sconfig(sh):
    s=0.
    for row in sh:
        for j,N in enumerate(row):
            if N:s+=math.log(math.comb(int(CAP[j]),int(N)))
    return s

def norm2(n,eps):
    xs,ws=np.polynomial.legendre.leggauss(24);x=(xs+1)/2;w=ws/2;h=1-x;g=(1-eps)+eps*h;r=(n-1)+x
    return float(4*math.pi*np.sum(w*r*r*g*g))

def eval_fixed(sh,cent,eps,pts,lo,hi):
    sh=np.asarray(sh,int);cent=np.asarray(cent,float);vol=float(np.prod(hi-lo));Np=len(pts)
    maxshell=max(1,max((outer(row) for row in sh),default=1)); norms={n:math.sqrt(norm2(n,eps)) for n in range(1,maxshell+1)}
    F=np.zeros(Np);G=np.zeros(Np);G2=np.zeros(Np)
    for i,row in enumerate(sh):
        d=np.linalg.norm(pts-cent[i],axis=1);gi=np.zeros(Np)
        for n,N in enumerate(row,1):
            if N<=0:continue
            m=(d>=n-1)&(d<n)
            if not m.any():continue
            x=d[m]-(n-1);prof=((1-eps)+eps*(1-x))/norms[n]
            F[m]+=math.sqrt(float(N))*prof;gi[m]+=(float(N)/CAP[n-1])*prof
        G+=gi;G2+=gi*gi
    f2=F*F;D=vol*float(f2.mean());pos=f2>0
    if D<=0:return -1e99
    ilog=vol*float(np.mean(np.where(pos,f2*np.log(np.where(pos,f2,1.)),0.)))
    sf=math.log(D)-ilog/D;cp=.5*vol*float(np.mean(G*G-G2))
    return sconfig(sh)+sf+LAMC*cp

W0={}
for q in BASE['weights']: W0[(q['a'],q['b'])]=W0[(q['b'],q['a'])]=float(q['norm'])
EXC=['H','C','N','O','Mg']
def W_for(eps):
    w=dict(W0);s0=R63['excitation_slopes']['0.0'];se=R63['excitation_slopes'][str(eps)]
    for i,a in enumerate(EXC):
      for b in EXC[i:]:
        key=f'{a}-{b}' if f'{a}-{b}' in s0 else f'{b}-{a}'
        ratio=float(se[key])/float(s0[key]) if float(s0[key])>1e-12 else 1.
        w[(a,b)]=w[(b,a)]=W0[(a,b)]*ratio
    return w

def ball(n,R,rng):
    v=rng.normal(size=(n,3));v/=np.linalg.norm(v,axis=1)[:,None];rr=R*rng.random(n)**(1/3);return v*rr[:,None]

def relax(elements,seed,steps=1000,eps=.5,R=16.):
    rng=np.random.default_rng(seed);x=ball(len(elements),R,rng);W=W_for(eps);n=len(elements)
    rad=np.array([RAD[e] for e in elements],float);r0=rad[:,None]+rad[None,:];np.fill_diagonal(r0,1.)
    WM=np.ones((n,n))
    for i in range(n):
      for j in range(i+1,n): WM[i,j]=WM[j,i]=np.clip(W[(elements[i],elements[j])],.03,8.)
    last={}
    for t in range(steps):
      dv=x[None,:,:]-x[:,None,:];d=np.linalg.norm(dv,axis=2);np.fill_diagonal(d,np.inf);u=dv/np.where(np.isfinite(d),d,1)[:,:,None]
      far=d>r0;near=d<r0;mf=np.where(far,np.minimum(1.,(r0/np.where(np.isfinite(d),d,1))**2)*WM,0);mn=np.where(near,np.clip((r0-d)/r0,0,1)*WM,0)
      f=((mf-mn)[:,:,None]*u).sum(axis=1)/max(1,n-1);f-=f.mean(axis=0);dt=.03*(.25+.75*(1-t/max(1,steps)));dx=dt*f;x+=dx
      if t==steps-1:last={'rms':float(np.sqrt(np.mean(dx*dx))),'overlaps':int(np.triu(d<r0,1).sum())}
    x-=x.mean(axis=0);return x,last

def layer_metric(x,bins=24):
    rr=np.linalg.norm(x,axis=1);hist,edges=np.histogram(rr,bins=bins,range=(0,max(rr.max(),1e-9)));best=None
    for k in range(2,len(hist)-1):
      if hist[k]>=hist[k-1] and hist[k]>=hist[k+1] and hist[k]>=max(3,int(.06*len(x))):
        inner=int(hist[:k-1].sum());val=int(hist[k-1])
        if inner>=max(5,int(.15*len(x))) and val<=.65*hist[k]:
          cand={'bin':k,'peak':int(hist[k]),'valley':val,'inner':inner,'rlo':float(edges[k]),'rhi':float(edges[k+1])}
          if best is None or cand['peak']-cand['valley']>best['peak']-best['valley']:best=cand
    return best

def reaction_test(x,elements,chain,seed,pow=16):
    # choose an interior location: nearest existing O to center, and use local compartment atoms within 7 native units.
    rr=np.linalg.norm(x,axis=1); Oidx=[i for i,e in enumerate(elements) if e=='O']; oi=min(Oidx,key=lambda i:rr[i]); origin=x[oi].copy()
    loc=np.linalg.norm(x-origin,axis=1)<=7.0; locidx=np.where(loc)[0]; env_elements=[elements[i] for i in locidx]; env_cent=x[locidx]-origin
    a=chain[0]; b='O'; t='Na'
    # place parent reaction pair at center; remove nearest existing O and nearest a/Na from env to avoid duplicate exact center occupancy
    # environment remains otherwise fixed and is identical across comparators.
    remove=set([oi])
    for typ in [a,'Na']:
      cand=[i for i,e in enumerate(elements) if e==typ and i not in remove]; remove.add(min(cand,key=lambda i:np.linalg.norm(x[i]-origin)))
    keep=[i for i in locidx if i not in remove]; env_elements=[elements[i] for i in keep]; env_cent=x[keep]-origin
    base=np.vstack([AT[a],AT['O']]);psh=base.copy();psh[1]=promoted(AT['O'])
    d=.88*(outer(AT[a])+outer(AT['O']));pc=np.array([[-d/2,0,0],[d/2,0,0]],float)
    d3=.88*((outer(AT[a])+outer(AT['O']))/2+outer(AT['Na'])); near=np.array([[0,d3,0]],float);far=np.array([[0,12,0]],float)
    # concatenate environment first; comparators differ only in parent promotion / Na location
    shenv=np.vstack([AT[e] for e in env_elements]) if env_elements else np.empty((0,7),int)
    def state(parent,na): return np.vstack([shenv,parent,AT['Na']]), np.vstack([env_cent,pc,na])
    lo=np.array([-14.,-14.,-14.]);hi=-lo;pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
    vals={'seed':seed,'local_env_nodes':len(env_elements)}
    for eps in [1.,.5,0.]:
      shG,cG=state(base,near);shP,cP=state(psh,near);shPf,cPf=state(psh,far)
      # parent promotion advantage measured with Na far, identical env
      # ground with Na far and promoted with Na far; to isolate parent promotion.
      shGf,cGf=state(base,far)
      vals[f'parent_adv_{eps:g}']=eval_fixed(shPf,cPf,eps,pts,lo,hi)-eval_fixed(shGf,cGf,eps,pts,lo,hi)
      vals[f'promoted_add_{eps:g}']=eval_fixed(shP,cP,eps,pts,lo,hi)-eval_fixed(shPf,cPf,eps,pts,lo,hi)
      vals[f'ground_add_{eps:g}']=eval_fixed(shG,cG,eps,pts,lo,hi)-eval_fixed(shGf,cGf,eps,pts,lo,hi)
      vals[f'enhance_{eps:g}']=vals[f'promoted_add_{eps:g}']-vals[f'ground_add_{eps:g}']
    return vals, {'origin_index':int(oi),'local_env_nodes':len(env_elements),'origin':origin.tolist()}

def main():
    elements=expand(POOLS['B_ionic'])+expand(medium(1.75))
    x,last=relax(elements,63101,steps=1000,eps=.5,R=16.)
    layer=layer_metric(x)
    ck={'seed':63101,'nodes':len(elements),'epsilon':.5,'Cl_M':1.75,'last':last,'layer':layer,'coordinates':x.tolist(),'elements':elements}
    (ROOT/'SEAM_R63_COMPARTMENT_CHECKPOINT_R78A.json').write_text(json.dumps(ck,indent=2))
    rows=[]
    for chain in ['C','N']:
      vals=[];meta=None
      for seed in [78001,78002,78003]:
        v,meta=reaction_test(x,elements,chain,seed,pow=16);vals.append(v)
      accepted=all(v['parent_adv_1']>0 and v['parent_adv_0.5']>0 and v['parent_adv_0']>0 and v['promoted_add_0.5']>0 and v['enhance_0.5']>0 and v['promoted_add_0']>0 for v in vals)
      rows.append({'chain':f'{chain}-O* + Na','accepted':accepted,'vals':vals,'meta':meta,'means':{k:float(np.mean([v[k] for v in vals])) for k in ['parent_adv_1','parent_adv_0.5','parent_adv_0','promoted_add_0.5','enhance_0.5','promoted_add_0']}})
    out={'run_id':'R78_COMPARTMENT_ASSISTED_PROMOTED_CHAIN','contract':'reconstructed R63-like 1.75 M, epsilon=.5 transient configuration; local complete field within 7 native units retained identically across comparators; 3 independent Sobol x 2^16','checkpoint_layer':layer,'rows':rows,'accepted_count':sum(r['accepted'] for r in rows)}
    (ROOT/'SEAM_COMPARTMENT_PROMOTED_CHAIN_R78B.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'layer':layer,'last':last,'accepted_count':out['accepted_count'],'rows':[{'chain':r['chain'],'accepted':r['accepted'],'means':r['means'],'env_nodes':r['meta']['local_env_nodes']} for r in rows]},indent=2))
if __name__=='__main__':main()
