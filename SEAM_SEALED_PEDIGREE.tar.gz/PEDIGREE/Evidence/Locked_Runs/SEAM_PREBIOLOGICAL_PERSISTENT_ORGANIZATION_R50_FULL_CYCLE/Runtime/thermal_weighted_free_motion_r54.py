#!/usr/bin/env python3
import json, math, sys
from pathlib import Path
import numpy as np, pandas as pd
from scipy.spatial import ConvexHull
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pair_relational_closure_r28 as r28

MATRIX='/mnt/data/continuum_run/Evidence/Data/Z001_Z128_Blind_Matrix/Z001_Z128_ATOMIC_SHELL_MATRIX.csv'
ZMAP={'H':1,'C':6,'N':7,'O':8,'Na':11,'Mg':12,'P':15,'S':16,'Cl':17,'K':19,'Ca':20}
POOLS={
 'A_core': {'C':30,'H':51,'O':12,'N':7,'P':1,'S':1},
 'B_ionic': {'C':30,'H':51,'O':12,'N':7,'P':1,'S':1,'K':2,'Na':1,'Mg':1,'Ca':1,'Cl':1},
}
MEDIA={
 'fresh': {'H':60,'O':30},
 'brine': {'H':60,'O':30,'Na':6,'Cl':6,'Mg':2,'Ca':1,'K':2,'S':1},
}

def load_states():
    df=pd.read_csv(MATRIX).set_index('Z')
    states={}; radii={}
    for e,z in ZMAP.items():
        row=df.loc[z]
        occ=[int(row[f'N{i}']) for i in range(1,8)]
        while occ and occ[-1]==0: occ.pop()
        states[e]=occ; radii[e]=int(row['boundary_shell'])
    return states,radii
STATES,RADIUS=load_states()

def expand(counts):
    out=[]
    for e,n in counts.items(): out += [e]*n
    return out

def build_pair_weights(elements):
    uniq=sorted(set(elements), key=lambda e:ZMAP[e])
    raw={}; rows=[]
    for i,a in enumerate(uniq):
        for b in uniq[i:]:
            contact=RADIUS[a]+RADIUS[b]
            d1=0.80*contact; d2=0.92*contact
            ra=r28.evaluate_pair(f'{a}-{b}-d1',STATES[a],STATES[b],d=d1)
            rb=r28.evaluate_pair(f'{a}-{b}-d2',STATES[a],STATES[b],d=d2)
            if ra['status']!='RESOLVED' or rb['status']!='RESOLVED':
                w=0.0; status='INDETERMINATE'
            else:
                s1=ra['selected']['S_total_over_kB']; s2=rb['selected']['S_total_over_kB']
                # At fixed positive T, F_th direction/magnitude is proportional to dS/dN_r.
                slope=max(0.0,(s2-s1)/(d2-d1))
                w=slope; status='RESOLVED'
            raw[(a,b)]=raw[(b,a)]=w
            rows.append({'pair':f'{a}-{b}','contact':contact,'N_r1':d1,'N_r2':d2,
                         'S1':ra['selected']['S_total_over_kB'],'S2':rb['selected']['S_total_over_kB'],
                         'thermal_force_weight_raw':w,'status':status})
    positives=[v for v in raw.values() if v>0]
    med=float(np.median(positives)) if positives else 1.0
    norm={k:(v/med if med>0 else 1.0) for k,v in raw.items()}
    for row in rows:
        a,b=row['pair'].split('-'); row['thermal_force_weight_norm']=norm[(a,b)]
    return norm,rows

def random_ball(n,R,rng):
    v=rng.normal(size=(n,3)); v/=np.linalg.norm(v,axis=1)[:,None]
    rr=R*rng.random(n)**(1/3); return v*rr[:,None]

def relax(elements,weights,seed,steps=900,dt0=0.025,init_R=20):
    rng=np.random.default_rng(seed); n=len(elements); x=random_ball(n,init_R,rng)
    rad=np.array([RADIUS[e] for e in elements],float)
    r0=rad[:,None]+rad[None,:]; np.fill_diagonal(r0,1.0)
    W=np.ones((n,n),float)
    for i in range(n):
        for j in range(i+1,n):
            W[i,j]=W[j,i]=weights[(elements[i],elements[j])]
    # clip only for numerical stability; preserve ordering
    W=np.clip(W,0.05,5.0)
    history=[]
    for t in range(steps):
        dv=x[None,:,:]-x[:,None,:]; d=np.linalg.norm(dv,axis=2); np.fill_diagonal(d,np.inf)
        u=dv/np.where(np.isfinite(d),d,1.0)[:,:,None]
        far=d>r0; near=d<r0
        # Far field remains direction-only because numeric K_ab is not serialized by active runtime.
        mag_far=np.where(far,np.minimum(1.0,(r0/np.where(np.isfinite(d),d,1.0))**2),0.0)
        # Near field carries executable pair-specific thermal Hamiltonian slope weight.
        mag_near=np.where(near,np.clip((r0-d)/r0,0,1)*W,0.0)
        pair=(mag_far-mag_near)[:,:,None]*u
        f=pair.sum(axis=1)/max(1,n-1); f-=f.mean(axis=0)
        dt=dt0*(0.25+0.75*(1-t/steps)); dx=dt*f; x+=dx
        if t%150==0 or t==steps-1:
            overlap=int(np.triu(d<r0,1).sum())
            history.append({'step':t,'rms_move':float(np.sqrt(np.mean(dx*dx))),'overlap_pairs':overlap})
    x-=x.mean(axis=0); return x,rad,history

def metrics(x,elements):
    rr=np.linalg.norm(x,axis=1); hull=ConvexHull(x); hidx=np.unique(hull.simplices.ravel())
    hist,edges=np.histogram(rr,bins=20,range=(0,max(rr.max(),1e-9)))
    layered=False; layer=None
    for k in range(2,len(hist)-1):
        if hist[k]>=hist[k-1] and hist[k]>=hist[k+1] and hist[k]>=max(4,int(.08*len(x))):
            inner=hist[:k-1].sum(); valley=hist[k-1]
            if inner>=max(5,int(.15*len(x))) and valley<=0.5*hist[k]:
                layered=True; layer={'bin':k,'peak_count':int(hist[k]),'valley_count':int(valley),'inner_count':int(inner),'r_lo':float(edges[k]),'r_hi':float(edges[k+1])}
    return {'hull_fraction':float(len(hidx)/len(x)),'hull_nodes':int(len(hidx)),'hull_volume':float(hull.volume),
            'rmax':float(rr.max()),'rmedian':float(np.median(rr)),'central_count':int(np.sum(rr<.35*rr.max())),
            'layered_boundary_candidate':bool(layered),'layer':layer,
            'hull_elements':{e:int(sum(elements[i]==e for i in hidx)) for e in sorted(set(elements))}}

def main():
    # Build one pair table covering all ionic elements; core is subset.
    all_elems=expand(POOLS['B_ionic'])+expand(MEDIA['brine'])
    weights,pair_rows=build_pair_weights(all_elems)
    branches=[]
    for pool in POOLS:
        for medium in MEDIA:
            els=expand(POOLS[pool])+expand(MEDIA[medium])
            seedrows=[]
            for seed in [5401,5402,5403]:
                x,rad,hist=relax(els,weights,seed)
                m=metrics(x,els); m['seed']=seed; m['history']=hist; seedrows.append(m)
            branches.append({'pool':pool,'medium':medium,'nodes':len(els),'seeds':seedrows,
                             'layered_count':sum(r['layered_boundary_candidate'] for r in seedrows)})
    out={'run_id':'SEAM-THERMAL-WEIGHTED-FREE-MOTION-R54',
         'scope':'pair-specific near-field weighting from executable constant-T thermal Hamiltonian derivative; far-field K_ab amplitude remains symbolic/unserialized',
         'pair_weight_definition':'w_ab proportional to dS*_ab/dN_r on [0.80 R_contact,0.92 R_contact]; common positive T/L factor omitted for topology ordering',
         'far_field':'native inward 1/N_R^2 direction, equal numerical relaxation amplitude because active R28 does not serialize numeric K_ab',
         'pair_weights':pair_rows,'branches':branches,
         'disposition':'PAIR_WEIGHTED_NEAR_FIELD_TOPOLOGY_SCREEN'}
    p=Path('/mnt/data/continuum_run/SEAM_THERMAL_WEIGHTED_FREE_MOTION_R54.json'); p.write_text(json.dumps(out,indent=2))
    print(json.dumps({'pair_weight_range':[min(r['thermal_force_weight_norm'] for r in pair_rows),max(r['thermal_force_weight_norm'] for r in pair_rows)],
                      'summary':[{'pool':b['pool'],'medium':b['medium'],'layered':b['layered_count'],'of':3,
                                  'hull_fracs':[round(s['hull_fraction'],3) for s in b['seeds']]} for b in branches]},indent=2))
    print(p)
if __name__=='__main__': main()
