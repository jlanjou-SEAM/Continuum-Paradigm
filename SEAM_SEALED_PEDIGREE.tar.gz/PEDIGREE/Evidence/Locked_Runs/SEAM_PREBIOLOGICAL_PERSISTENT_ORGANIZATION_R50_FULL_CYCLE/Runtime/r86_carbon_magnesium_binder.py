#!/usr/bin/env python3
import json, importlib.util, sys
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path('/mnt/data/continuum_run')
sp=importlib.util.spec_from_file_location('r78', ROOT/'Evidence/Runtime/r78_compartment_promoted_chain.py')
r78=importlib.util.module_from_spec(sp); sp.loader.exec_module(r78)
ck=json.load(open(ROOT/'SEAM_R63_COMPARTMENT_CHECKPOINT_R78A.json'))
x=np.array(ck['coordinates'],float); elements=ck['elements']

# choose same compartment-local origin protocol: nearest O to center
rr=np.linalg.norm(x,axis=1); Oidx=[i for i,e in enumerate(elements) if e=='O']; oi=min(Oidx,key=lambda i:rr[i]); origin=x[oi].copy()
locidx=np.where(np.linalg.norm(x-origin,axis=1)<=7.0)[0]
# remove nearest instances of elements introduced explicitly

def local_env(remove_types):
    remove={oi}
    for typ in remove_types:
        cand=[i for i,e in enumerate(elements) if e==typ and i not in remove]
        if cand: remove.add(min(cand,key=lambda i:np.linalg.norm(x[i]-origin)))
    keep=[i for i in locidx if i not in remove]
    env_elements=[elements[i] for i in keep]; env_cent=x[keep]-origin
    shenv=np.vstack([r78.AT[e] for e in env_elements]) if env_elements else np.empty((0,7),int)
    return env_elements,env_cent,shenv

def pair_capture(a,b,eps,seed,pow=17,dirvec=(1,0,0)):
    env_elements,env_cent,shenv=local_env([a,b])
    ra=r78.outer(r78.AT[a]); rb=r78.outer(r78.AT[b]); d=.88*(ra+rb); v=np.array(dirvec,float);v=v/np.linalg.norm(v)
    pc=np.array([-v*d/2, v*d/2])
    far=np.array([-v*d/2, v*12.0])
    sh=np.vstack([shenv,r78.AT[a],r78.AT[b]])
    cnear=np.vstack([env_cent,pc]); cfar=np.vstack([env_cent,far])
    lo=np.array([-14.,-14.,-14.]);hi=-lo;pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
    return r78.eval_fixed(sh,cnear,eps,pts,lo,hi)-r78.eval_fixed(sh,cfar,eps,pts,lo,hi),len(env_elements)

def promoted_chain_mg(chain='C',eps=.5,seed=1,pow=17,dirvec=(0,1,0)):
    # parent chain a-O* plus Mg as candidate binder. Compare Mg capture with promoted parent vs ground parent.
    a=chain; env_elements,env_cent,shenv=local_env([a,'O','Mg'])
    base=np.vstack([r78.AT[a],r78.AT['O']]); prom=base.copy(); prom[1]=r78.promoted(r78.AT['O'])
    d=.88*(r78.outer(r78.AT[a])+r78.outer(r78.AT['O'])); pc=np.array([[-d/2,0,0],[d/2,0,0]],float)
    dm=.88*((r78.outer(r78.AT[a])+r78.outer(r78.AT['O']))/2+r78.outer(r78.AT['Mg']))
    v=np.array(dirvec,float);v=v/np.linalg.norm(v); near=np.array([v*dm]);far=np.array([v*12.0])
    lo=np.array([-14.,-14.,-14.]);hi=-lo;pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
    def st(parent,mg): return np.vstack([shenv,parent,r78.AT['Mg']]),np.vstack([env_cent,pc,mg])
    shpn,cpn=st(prom,near); shpf,cpf=st(prom,far); shgn,cgn=st(base,near); shgf,cgf=st(base,far)
    pcap=r78.eval_fixed(shpn,cpn,eps,pts,lo,hi)-r78.eval_fixed(shpf,cpf,eps,pts,lo,hi)
    gcap=r78.eval_fixed(shgn,cgn,eps,pts,lo,hi)-r78.eval_fixed(shgf,cgf,eps,pts,lo,hi)
    return pcap,gcap,pcap-gcap,len(env_elements)

rows=[]
seeds=[86001,86002,86003]
dirs=[(1,0,0),(0,1,0),(0,0,1)]
for eps in [1.0,.5,0.0]:
    vals=[]
    for seed in seeds:
        d,nenv=pair_capture('C','Mg',eps,seed,17,(1,0,0)); vals.append(d)
    dvals=[]
    for i,vec in enumerate(dirs):
        d,_=pair_capture('C','Mg',eps,86100+i,16,vec); dvals.append(d)
    rows.append({'test':'C-Mg','epsilon':eps,'seed_values':vals,'dir_values':dvals,'mean':float(np.mean(vals)),'all_seed_positive':all(v>0 for v in vals),'all_dir_positive':all(v>0 for v in dvals),'local_env_nodes':nenv})

chain_rows=[]
for chain in ['C','N']:
  for eps in [.5,0.0]:
    vals=[]
    for seed in seeds:
      p,g,e,nenv=promoted_chain_mg(chain,eps,seed,17,(0,1,0));vals.append((p,g,e))
    chain_rows.append({'chain':f'{chain}-O* + Mg','epsilon':eps,'promoted_capture':[v[0] for v in vals],'ground_capture':[v[1] for v in vals],'enhancement':[v[2] for v in vals], 'means':{'promoted':float(np.mean([v[0] for v in vals])),'ground':float(np.mean([v[1] for v in vals])),'enhancement':float(np.mean([v[2] for v in vals]))}, 'all_promoted_positive':all(v[0]>0 for v in vals),'all_enhancement_positive':all(v[2]>0 for v in vals),'local_env_nodes':nenv})
out={'run_id':'R86_CARBON_MAGNESIUM_BINDER','checkpoint':'R78A actual R63 compartment checkpoint','pair_rows':rows,'chain_rows':chain_rows}
(ROOT/'SEAM_CARBON_MAGNESIUM_BINDER_R86.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
