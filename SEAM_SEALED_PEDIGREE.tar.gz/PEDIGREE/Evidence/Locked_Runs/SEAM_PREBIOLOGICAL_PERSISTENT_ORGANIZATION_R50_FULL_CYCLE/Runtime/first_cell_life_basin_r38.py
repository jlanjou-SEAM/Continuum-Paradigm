#!/usr/bin/env python3
import json, pathlib, hashlib
ROOT=pathlib.Path('/mnt/data/continuum_run')
R=ROOT/'Evidence/Runtime/B01_LIGHT_PHASE'
files=['r4f_dark.json','r4f_500THz.json','r4tsf_control.json','r4tsf_excited.json']
rows=[]
for fn in files:
    d=json.load(open(R/fn))
    detail=d.get('native_result',{}).get('selected',{}).get('detail',{})
    rows.append({
      'file':fn,
      'S_total_over_kB':detail.get('S_total_over_kB'),
      'coupling_status':d.get('coupling_status') or d.get('event_coupling_status')
    })
vals=[r['S_total_over_kB'] for r in rows]
frequency_discrimination=(max(vals)-min(vals)) if all(v is not None for v in vals) else None
out={
 'run_id':'R38-SEAM-FIRST-CELL-LIFE-BASIN-PREEXECUTION-01',
 'restriction':'SEAM/archive-native information only',
 'requested_axes':{
   'temperature':'downstream projection T=Phi_T(E_exc,B_conf)',
   'pressure':'downstream projection P=Phi_P(E_exc,B_conf)',
   'solar_output':'requires an excitation/transfer amplitude coupling into the complete state; archive contains frequency coordinates but no amplitude/output law'
 },
 'native_axes':{'excitation':'E_exc','confinement':'B_conf','radiative_periodicity':'f=N_T/T'},
 'archive_executable_probe':rows,
 'frequency_entropy_discrimination':frequency_discrimination,
 'projection_binding_audit':{
   'Phi_T_numeric_map_present':False,
   'Phi_P_numeric_map_present':False,
   'solar_output_to_E_exc_numeric_map_present':False,
   'heterogeneous_excited_N_gt_2_successor_bound':False
 },
 'can_compute_native_confinement_control':True,
 'can_compute_excited_life_basin':False,
 'can_report_kelvin_bounds':False,
 'can_report_pressure_bounds':False,
 'can_report_solar_output_bounds':False,
 'terminal':'SOURCE_BINDING_REQUIRED',
 'missing_bindings':[
   'numerical perturbation operator mapping radiative/thermal input to post-perturbation complete state Y_post',
   'heterogeneous N>2 excited complete-state field/entropy successor',
   'Phi_T(E_exc,B_conf)',
   'Phi_P(E_exc,B_conf)',
   'solar-output/amplitude -> native excitation-state mapping'
 ],
 'scientific_disposition':'No life-forming basin can be numerically inferred without inventing upstream laws. Static confinement remains a negative control; radiative discrimination is identically zero in the currently bound R4 frequency interface.'
}
blob=json.dumps(out,sort_keys=True,separators=(',',':')).encode(); out['sha256_pre_hash']=hashlib.sha256(blob).hexdigest()
path=ROOT/'SEAM_FIRST_CELL_LIFE_BASIN_R38.json'
json.dump(out,open(path,'w'),indent=2)
print(json.dumps(out,indent=2))
