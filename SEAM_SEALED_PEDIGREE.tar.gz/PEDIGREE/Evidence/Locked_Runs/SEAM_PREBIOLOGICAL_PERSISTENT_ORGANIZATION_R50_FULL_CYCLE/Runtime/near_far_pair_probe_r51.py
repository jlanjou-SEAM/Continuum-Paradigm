#!/usr/bin/env python3
import json, importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r28', HERE/'pair_relational_closure_r28.py')
r28=importlib.util.module_from_spec(spec); spec.loader.exec_module(r28)
AT={
'H':[1], 'C':[2,4], 'N':[2,5], 'O':[2,6], 'P':[2,8,5], 'S':[2,8,6],
'Na':[2,8,1], 'Mg':[2,8,2], 'Cl':[2,8,7], 'K':[2,8,8,1], 'Ca':[2,8,8,2]
}
pairs=[('H','H'),('C','C'),('C','O'),('N','O')]
grids=[1.0,1.5,2.0,2.5,3.0,3.5,4.0,5.0,6.0,7.0]
rows=[]
for a,b in pairs:
    vals=[]
    for d in grids:
        x=r28.evaluate_pair(f'{a}-{b}',AT[a],AT[b],d=d)
        vals.append({'N_r':d,'status':x['status'],'S':x['selected']['S_total_over_kB'],'Sc':x['selected']['S_coupling_over_kB'],'overlaps':len(x['nonzero_overlaps'])})
    valid=[v for v in vals if v['status']=='RESOLVED']
    best=max(valid,key=lambda v:v['S']) if valid else None
    # interior local maximum against adjacent grid points
    loc=[]
    for i in range(1,len(valid)-1):
        if valid[i]['S']>valid[i-1]['S'] and valid[i]['S']>valid[i+1]['S']:
            loc.append(valid[i])
    rows.append({'pair':f'{a}-{b}','best':best,'interior_local_maxima':loc,'curve':vals})
out={'runtime_id':'R51-NEAR-FAR-PAIR-PROBE','near_field':'R_SEAM(N_r)=S*(N_r)','far_field':'H_attr exterior attraction supplies inward response outside overlap','rows':rows}
Path('/mnt/data/continuum_run/SEAM_NEAR_FAR_PAIR_PROBE_R51.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'pairs':[{'pair':r['pair'],'best':r['best'],'local_maxima':r['interior_local_maxima']} for r in rows]},indent=2))
