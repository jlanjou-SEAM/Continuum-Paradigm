#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
import importlib.util
HERE=Path('/mnt/data/continuum_run/Evidence/Runtime')
spec=importlib.util.spec_from_file_location('r39',HERE/'excited_nnode_basin_r39.py'); r39=importlib.util.module_from_spec(spec); spec.loader.exec_module(r39)
AT=r39.ATOMIC; CAP=r39.CAP
ELS=['H','C','N','O','Mg']

def sconfig(sh): return r39.sconfig(sh)
def norm2(n,eps,kind='linear'): return r39.norm2(n,eps,kind)
def profile(x,eps,kind='linear'): return r39.profile(x,eps,kind)

def eval_fixed(sh,centers,eps,pts,lo,hi,kind='linear'):
    vol=float(np.prod(hi-lo)); samples=len(pts); maxshell=max(np.nonzero(sh)[1])+1
    F=np.zeros(samples); G=np.zeros(samples); G2=np.zeros(samples)
    norms={(n,eps,kind):math.sqrt(norm2(n,eps,kind)) for n in range(1,maxshell+1)}
    for i,row in enumerate(sh):
        d=np.linalg.norm(pts-centers[i],axis=1); gi=np.zeros(samples)
        for n,N in enumerate(row,1):
            if N<=0: continue
            m=(d>=n-1)&(d<n)
            if not m.any(): continue
            x=d[m]-(n-1); u=profile(x,eps,kind)/norms[(n,eps,kind)]
            F[m]+=math.sqrt(float(N))*u; gi[m]+=(float(N)/CAP[n-1])*u
        G+=gi; G2+=gi*gi
    f2=F*F; D=vol*float(f2.mean()); pos=f2>0
    ilog=vol*float(np.mean(np.where(pos,f2*np.log(np.where(pos,f2,1.0)),0.0)))
    sf=math.log(D)-ilog/D if D>0 else -math.inf
    cp=.5*vol*float(np.mean(G*G-G2))
    return sconfig(sh)+sf+.1*cp

def maxrad(el): return max(i+1 for i,n in enumerate(AT[el]) if n)

def main():
    lo=np.array([-12.,-12.,-12.]); hi=-lo
    sob=qmc.Sobol(3,scramble=True,seed=69001); pts=lo+sob.random_base2(16)*(hi-lo)
    pairs=[(ELS[i],ELS[j]) for i in range(len(ELS)) for j in range(i,len(ELS))]
    rows=[]; candidates=[]
    for a,b in pairs:
        sh=np.asarray([AT[a],AT[b]],int); contact=maxrad(a)+maxrad(b); sep=contact+2.0
        csep=np.array([[-sep/2,0,0],[sep/2,0,0]],float)
        base={eps:eval_fixed(sh,csep,eps,pts,lo,hi) for eps in [1.0,.5,0.0]}
        ds=np.linspace(max(.4,.45*contact), .98*contact, 15)
        vals=[]
        for d in ds:
            c=np.array([[-d/2,0,0],[d/2,0,0]],float)
            rec={'d':float(d)}
            for eps in [1.0,.5,0.0]: rec[f'dS_{eps:g}']=eval_fixed(sh,c,eps,pts,lo,hi)-base[eps]
            vals.append(rec)
        # candidate must form at light eps=1 and retain at moderate or dark at same geometry
        best=max(vals,key=lambda z:z['dS_1'])
        rec={'pair':f'{a}-{b}','contact':contact,'best':best,'forms_light':best['dS_1']>0,
             'retains_moderate':best['dS_0.5']>0,'retains_dark':best['dS_0']>0,'curve':vals}
        rows.append(rec)
        if rec['forms_light'] and (rec['retains_moderate'] or rec['retains_dark']): candidates.append(rec)
    out={'run_id':'R69_RETAINED_PHOTO_PAIR_SEARCH','contract':'fixed-domain Sobol 2^16; R39 linear excitation profile; pair must form at eps=1 and remain entropy-supported at same geometry after eps->0.5 or 0','rows':rows,'candidates':candidates,'candidate_count':len(candidates)}
    p=Path('/mnt/data/continuum_run/SEAM_RETAINED_PHOTO_PAIR_SEARCH_R69.json'); p.write_text(json.dumps(out,indent=2))
    print(json.dumps({'candidate_count':len(candidates),'candidates':[{'pair':r['pair'],**r['best'],'ret_mod':r['retains_moderate'],'ret_dark':r['retains_dark']} for r in candidates]},indent=2)); print(p)
if __name__=='__main__':main()
