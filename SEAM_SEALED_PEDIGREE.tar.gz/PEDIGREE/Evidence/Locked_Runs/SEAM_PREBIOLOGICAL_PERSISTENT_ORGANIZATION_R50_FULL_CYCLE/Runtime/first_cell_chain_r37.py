#!/usr/bin/env python3
"""SEAM-only primordial 173-node chain derivative.
Uses only archive-resident atomic shell states and the canonical N-node entropy evaluator.
No molecular graph, bond table, biochemical pathway, empirical Earth parameter, or inherited blueprint is supplied.
"""
import json, math, sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import nnode_complete_state_r36 as nn

ATOMIC={
'H':[1,0,0,0,0,0,0],
'C':[2,4,0,0,0,0,0],
'N':[2,5,0,0,0,0,0],
'O':[2,6,0,0,0,0,0],
'Mg':[2,8,2,0,0,0,0],
}
# Archive-resident 173-atom B01 inventory, stripped of every molecular partnership/apparatus role.
COUNTS={'C':61,'H':84,'N':4,'O':23,'Mg':1}


def make_shells():
    labels=[]; shells=[]
    for el in ['H','C','N','O','Mg']:
        for _ in range(COUNTS[el]): labels.append(el); shells.append(ATOMIC[el])
    return labels,np.array(shells,dtype=int)


def lattice_positions(n,spacing=7.0):
    side=math.ceil(n**(1/3))
    pts=[]
    for x in range(side):
      for y in range(side):
       for z in range(side):
        pts.append((x*spacing,y*spacing,z*spacing))
        if len(pts)==n: return np.array(pts,float)
    return np.array(pts,float)


def radius_of_gyration(c):
    x=c-c.mean(axis=0); return float(np.sqrt(np.mean(np.sum(x*x,axis=1))))


def structural_signature(labels,centers,threshold=6.0):
    # purely relational signature: connected components under shell-support contact opportunity.
    n=len(labels); parent=list(range(n))
    def find(a):
      while parent[a]!=a: parent[a]=parent[parent[a]]; a=parent[a]
      return a
    def union(a,b):
      a,b=find(a),find(b)
      if a!=b: parent[b]=a
    edges=0
    for i in range(n-1):
      ds=np.linalg.norm(centers[i+1:]-centers[i],axis=1)
      for k,d in enumerate(ds,i+1):
        if d<threshold: union(i,k); edges+=1
    comps={}
    for i in range(n): comps.setdefault(find(i),[]).append(i)
    sizes=sorted((len(v) for v in comps.values()),reverse=True)
    return {'component_count':len(sizes),'largest_component':sizes[0],'component_sizes_top10':sizes[:10],'proximity_edges':edges}


def main():
    labels,shells=make_shells(); base=lattice_positions(len(labels),7.0)
    center=base.mean(axis=0); x=base-center
    # Same constituent state; only relational compression coordinate changes.
    scales=[1.00,0.85,0.70,0.55,0.45,0.35,0.28,0.22]
    rows=[]
    for idx,s in enumerate(scales):
        c=x*s
        ev=nn.evaluate(shells,c,lambda_field=1.0,lambda_coupling=0.1,samples=90000,seed=3700+idx)
        sig=structural_signature(labels,c)
        rows.append({'scale':s,'radius_of_gyration_native':radius_of_gyration(c),**sig,**ev})
    best=max(rows,key=lambda r:r['S_total_over_kB'])
    baseS=rows[0]['S_total_over_kB']
    # terminal gates derived in prior chain: bounded + persistent + self-reconstructing + retained reconstruction structure.
    # This run can directly test only bounded relational aggregation; persistence/reconstruction require a successor map that reproduces a state after perturbation.
    terminal={
      'bounded_aggregate_found': best['largest_component']>1 and best['S_total_over_kB']>baseS,
      'persistence_test':'NOT_EXECUTED_NO_NATIVE_SUCCESSOR_DYNAMICS_BOUND',
      'self_reconstruction_test':'NOT_EXECUTED_NO_NATIVE_RECONSTRUCTION_OPERATOR_BOUND',
      'retained_reconstruction_structure':'NOT_EXECUTED',
    }
    terminal['single_cell_reproduced']=all(v is True for v in terminal.values())
    out={
      'run_id':'SEAM-FIRST-CELL-CHAIN-R37',
      'runtime':nn.RUNTIME_ID,
      'restriction':'SEAM/archive first principles only; no external early-Earth chemistry or biology',
      'inventory_origin':'archive B01 173-atom count only; all pre-existing molecular partnerships and chlorophyll apparatus roles removed',
      'inventory_counts':COUNTS,'node_count':len(labels),
      'manifold_perturbation':'uniform relational compression of one frozen 173-node lattice; no added force or chemistry operator',
      'coefficients':{'lambda_field':1.0,'lambda_coupling':0.1},
      'rows':rows,
      'selected_by_entropy':{'scale':best['scale'],'S_total_over_kB':best['S_total_over_kB'],'delta_vs_uncompressed_over_kB':best['S_total_over_kB']-baseS,'largest_component':best['largest_component'],'overlapping_node_pairs':best['overlapping_node_pairs']},
      'terminal_tests':terminal,
      'disposition':'ASSEMBLY_PRECURSOR_PRESENT' if terminal['bounded_aggregate_found'] else 'NO_ENTROPY_SUPPORTED_BOUNDED_ASSEMBLY_IN_TESTED_MANIFOLD_FAMILY'
    }
    outpath=Path('/mnt/data/continuum_run/SEAM_FIRST_CELL_CHAIN_R37.json')
    outpath.write_text(json.dumps(out,indent=2,default=float))
    print(json.dumps({k:out[k] for k in ['run_id','node_count','selected_by_entropy','terminal_tests','disposition']},indent=2,default=float))
    print('wrote',outpath)

if __name__=='__main__': main()
