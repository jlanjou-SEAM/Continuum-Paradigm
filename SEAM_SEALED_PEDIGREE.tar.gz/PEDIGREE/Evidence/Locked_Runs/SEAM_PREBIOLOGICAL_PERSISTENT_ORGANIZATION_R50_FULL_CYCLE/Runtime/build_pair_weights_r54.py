#!/usr/bin/env python3
import sys,json
from pathlib import Path
import pandas as pd, numpy as np
from concurrent.futures import ProcessPoolExecutor, as_completed
RTP=Path('/mnt/data/continuum_run/Evidence/Runtime'); sys.path.insert(0,str(RTP))
import pair_relational_closure_r28 as r28
MATRIX='/mnt/data/continuum_run/Evidence/Data/Z001_Z128_Blind_Matrix/Z001_Z128_ATOMIC_SHELL_MATRIX.csv'
ZMAP={'H':1,'C':6,'N':7,'O':8,'Na':11,'Mg':12,'P':15,'S':16,'Cl':17,'K':19,'Ca':20}
df=pd.read_csv(MATRIX).set_index('Z')
STATES={}; R={}
for e,z in ZMAP.items():
 row=df.loc[z]; x=[int(row[f'N{i}']) for i in range(1,8)]
 while x and x[-1]==0:x.pop()
 STATES[e]=x;R[e]=int(row['boundary_shell'])

def calc(pair):
 a,b=pair; c=R[a]+R[b]; d1=.80*c; d2=.92*c
 x=r28.evaluate_pair(f'{a}-{b}-1',STATES[a],STATES[b],d=d1)
 y=r28.evaluate_pair(f'{a}-{b}-2',STATES[a],STATES[b],d=d2)
 s1=x['selected']['S_total_over_kB']; s2=y['selected']['S_total_over_kB']
 w=max(0.0,(s2-s1)/(d2-d1)) if x['status']=='RESOLVED' and y['status']=='RESOLVED' else 0.0
 return {'pair':f'{a}-{b}','a':a,'b':b,'contact':c,'N_r1':d1,'N_r2':d2,'S1':s1,'S2':s2,'raw':w,'status1':x['status'],'status2':y['status']}

els=list(ZMAP)
pairs=[(a,b) for i,a in enumerate(els) for b in els[i:]]
rows=[]
with ProcessPoolExecutor(max_workers=8) as ex:
 futs={ex.submit(calc,p):p for p in pairs}
 for fut in as_completed(futs): rows.append(fut.result())
rows=sorted(rows,key=lambda z:(ZMAP[z['a']],ZMAP[z['b']]))
pos=[r['raw'] for r in rows if r['raw']>0]; med=float(np.median(pos)) if pos else 1
for r in rows:r['norm']=r['raw']/med if med else 1
out={'run_id':'R54_PAIR_WEIGHT_CACHE','definition':'w proportional to dS*/dN_r; constant positive T/L common factors omitted','median_positive_raw':med,'rows':rows}
p=Path('/mnt/data/continuum_run/R54_PAIR_WEIGHTS.json');p.write_text(json.dumps(out,indent=2))
print(json.dumps({'pairs':len(rows),'resolved':sum(r['status1']=='RESOLVED' and r['status2']=='RESOLVED' for r in rows),'norm_min':min(r['norm'] for r in rows),'norm_max':max(r['norm'] for r in rows),'path':str(p)},indent=2))
