#!/usr/bin/env python3
import json, importlib.util, math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path('/mnt/data/continuum_run'); HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r80',HERE/'r80_retained_chain_fourth_successor.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
r=m.r
DIRS=np.array([[1.,0,0],[0,1.,0],[0,0,1.]])

# Build validated R81 parent: A-O*-Na-O, using best O direction from R81.
r81=json.load(open(ROOT/'SEAM_FINAL_FOURTH_SUCCESSOR_AUDIT_R81.json'))
best={row['chain'][0]:row['best_dir'] for row in r81['rows']}

def parent_geom(a):
    shenv, envcent, nenv=m.local_env(a)
    psh,pc,na_near,na_far=m.chain_geom(a)
    odir=DIRS[best[a]]
    opos=m.t_near_pos(a,'O',odir)
    if np.min(np.linalg.norm(np.vstack([pc,na_near])-opos,axis=1))<0.25: opos=opos+np.array([.31,.17,.23])
    psh4=np.vstack([psh,r.AT['Na'],r.AT['O']])
    pc4=np.vstack([pc,na_near,opos])
    return shenv,envcent,nenv,psh4,pc4

def co2_geom(center, axis):
    axis=np.asarray(axis,float); axis=axis/np.linalg.norm(axis)
    d=.88*(r.outer(r.AT['C'])+r.outer(r.AT['O']))
    return np.vstack([center, center+d*axis, center-d*axis]) # C,O,O

def eval_capture(a, direction, seed, pow=14, second=False):
    shenv,envcent,nenv,psh,pc=parent_geom(a)
    # place intact CO2 entity near parent COM vs far; preserve O-C-O partnerships geometrically
    meanr=np.mean([r.outer(r.AT[e]) for e in [a,'O','Na','O']])
    dnear=.88*(meanr+r.outer(r.AT['C'])+r.outer(r.AT['O']))
    center_near=direction*dnear
    center_far=np.array([0.,0.,16.])
    axis=np.roll(direction,1)
    if abs(np.dot(axis,direction))>.9: axis=np.array([0.,1.,0.])
    co2n=co2_geom(center_near,axis); co2f=co2_geom(center_far,axis)
    shco2=np.vstack([r.AT['C'],r.AT['O'],r.AT['O']])
    lo=np.array([-18.,-18.,-18.]); hi=-lo
    pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
    def state(co2cent, withNa=True):
        # parent with Na near; no-Na comparator moves Na far but preserves all identities
        pcc=pc.copy()
        if not withNa: pcc[2]=np.array([0.,-15.,0.])
        sh=np.vstack([shenv,psh,shco2]); ce=np.vstack([envcent,pcc,co2cent])
        return sh,ce
    out={'seed':seed,'env_nodes':nenv}
    for eps in [.5,0.]:
        sh,cn=state(co2n,True); _,cf=state(co2f,True)
        _,cn0=state(co2n,False); _,cf0=state(co2f,False)
        sn=r.eval_fixed(sh,cn,eps,pts,lo,hi); sf=r.eval_fixed(sh,cf,eps,pts,lo,hi)
        sn0=r.eval_fixed(sh,cn0,eps,pts,lo,hi); sf0=r.eval_fixed(sh,cf0,eps,pts,lo,hi)
        add=sn-sf; base=sn0-sf0
        out[f'CO2_capture_with_chain_{eps:g}']=add
        out[f'CO2_capture_without_Na_{eps:g}']=base
        out[f'chain_enhancement_{eps:g}']=add-base
    return out

rows=[]
for a in ['C','N']:
    coarse=[]
    for di,dv in enumerate(DIRS):
        v=eval_capture(a,dv,82100+di,pow=12)
        coarse.append({'dir':di,**v})
    bestrow=max(coarse,key=lambda z:z['CO2_capture_with_chain_0.5'])
    vals=[eval_capture(a,DIRS[bestrow['dir']],s,pow=15) for s in [82201,82202,82203]]
    accepted=all(v['CO2_capture_with_chain_0.5']>0 and v['CO2_capture_with_chain_0']>0 for v in vals)
    enhanced=all(v['chain_enhancement_0.5']>0 for v in vals)
    rows.append({'parent':f'{a}-O*-Na-O','coarse':coarse,'best_dir':bestrow['dir'],'dense':vals,'retained_CO2_capture':accepted,'chain_enhanced_capture':enhanced,
                 'means':{k:float(np.mean([v[k] for v in vals])) for k in ['CO2_capture_with_chain_0.5','CO2_capture_without_Na_0.5','chain_enhancement_0.5','CO2_capture_with_chain_0','chain_enhancement_0']}})

# Couple only if carbon capture survives. R49 recurrence exact event accounting + transport recurrence.
# Reproduce closed block transport map for 1000 cycles, using a conservative unlabeled carbon sink of 0.02 only as a comparator;
# actual R82 capture is qualitative unless a per-cycle capture magnitude is derived.
def transport(cycles,sink):
    co2=0.0; o2=0.0; ext_co2=1.0; total_in=0.; total_out=0.; retained=0.
    # calibrated from R49 closed block: CO2 equilibration fraction 1-exp(-1), O2 fraction 1-exp(-160)
    fco2=1-math.exp(-1.0); fo2=1-math.exp(-160.0)
    hist=[]
    for c in range(1,cycles+1):
        imp=(ext_co2-co2)*fco2; co2+=imp; total_in+=imp
        take=min(sink,co2); co2-=take; retained+=take
        o2+=0.1; exp=o2*fo2; o2-=exp; total_out+=exp
        if c in (1,2,5,10,40,100,500,1000): hist.append({'cycle':c,'CO2_internal':co2,'CO2_import':imp,'O2_internal':o2,'O2_export':exp,'retained_carbon':retained})
    return {'cycles':cycles,'sink_per_cycle':sink,'final_CO2_internal':co2,'total_CO2_import':total_in,'final_O2_internal':o2,'total_O2_export':total_out,'total_unlabeled_carbon_retained':retained,'checkpoints':hist}

allcap=any(x['retained_CO2_capture'] for x in rows)
out={'run_id':'R82_PHOTOSYNTHESIS_CONTINUATION','archive_photosynthesis_contract':'B01 Appendix S + R49 OEC closed block','prototype_parent':'R79/R81 retained compartment chain','CO2_capture_rows':rows,'any_retained_CO2_capture':allcap,
     'oec_life_stream_test':{'retained_OEC_recurrence':'CLOSED_BY_R49','event_vector_per_cycle':{'electron_state_transfers':4,'proton_state_transfers':4,'O2_exports':1,'delta_retained_OEC':0},'cycles_tested':1000,
       'transport_no_carbon_sink':transport(1000,0.0),'transport_generic_sink_control':transport(1000,0.02)},
     'adjudication':None}
if allcap:
    out['adjudication']='STRUCTURAL_CO2_RETENTION_CANDIDATE_PASS; OEC CONTINUATION STREAMS RECUR; PER-CYCLE CARBON-CAPTURE RATE UNBOUND, SO FULL PHOTOSYNTHESIS LONGEVITY REMAINS CONDITIONAL'
else:
    out['adjudication']='OEC CONTINUATION STREAMS RECUR; PROTOTYPE DOES NOT YET PROVIDE A DENSE-VALIDATED RETAINED CO2 SINK; FULL PHOTOSYNTHESIS LONGEVITY NOT CLOSED'
(ROOT/'SEAM_PHOTOSYNTHESIS_CONTINUATION_R82.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'any_retained_CO2_capture':allcap,'rows':[{'parent':x['parent'],'retained':x['retained_CO2_capture'],'enhanced':x['chain_enhanced_capture'],'means':x['means']} for x in rows], 'adjudication':out['adjudication'], 'oec_1000_no_sink':out['oec_life_stream_test']['transport_no_carbon_sink']['checkpoints'][-1], 'oec_1000_sink_control':out['oec_life_stream_test']['transport_generic_sink_control']['checkpoints'][-1]},indent=2))
