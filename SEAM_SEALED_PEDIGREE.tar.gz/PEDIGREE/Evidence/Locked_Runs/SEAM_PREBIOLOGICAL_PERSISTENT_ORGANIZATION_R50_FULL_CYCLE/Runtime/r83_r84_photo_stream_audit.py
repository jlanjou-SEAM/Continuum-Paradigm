#!/usr/bin/env python3
import json, importlib.util
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path('/mnt/data/continuum_run'); HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r82',HERE/'r82_photosynthesis_continuation.py'); z=importlib.util.module_from_spec(spec); spec.loader.exec_module(z)
r=z.r; m=z.m; DIRS=z.DIRS

# R83 high-density orientation audit for first CO2 capture
r83=[]
for a in ['C','N']:
    # best dir from R82
    old=json.load(open(ROOT/'SEAM_PHOTOSYNTHESIS_CONTINUATION_R82.json'))
    row=next(x for x in old['CO2_capture_rows'] if x['parent'].startswith(a))
    bd=row['best_dir']
    vals=[z.eval_capture(a,DIRS[bd],s,pow=16) for s in [83101,83102,83103]]
    dirs=[{'dir':di,**z.eval_capture(a,dv,83200+di,pow=15)} for di,dv in enumerate(DIRS)]
    strict=all(v['CO2_capture_with_chain_0.5']>0 and v['CO2_capture_with_chain_0']>0 and v['chain_enhancement_0.5']>0 for v in vals)
    dirpass=sum(v['CO2_capture_with_chain_0.5']>0 and v['CO2_capture_with_chain_0']>0 for v in dirs)
    r83.append({'parent':f'{a}-O*-Na-O','best_dir':bd,'strict':strict,'direction_pass':dirpass,'vals':vals,'dirs':dirs,
                'means':{k:float(np.mean([v[k] for v in vals])) for k in ['CO2_capture_with_chain_0.5','CO2_capture_without_Na_0.5','chain_enhancement_0.5','CO2_capture_with_chain_0','chain_enhancement_0']}})
out83={'run_id':'R83_CO2_CAPTURE_FINAL_AUDIT','contract':'Actual R63 checkpoint + R81 retained parent; intact B01 CO2 entity; 3 independent x2^16 plus 3-direction x2^15; must capture at epsilon=.5 and 0, with positive chain enhancement at .5.','rows':r83,'accepted_count':sum(x['strict'] and x['direction_pass']>=2 for x in r83)}
(ROOT/'SEAM_CO2_CAPTURE_FINAL_AUDIT_R83.json').write_text(json.dumps(out83,indent=2))

# R84: second intact CO2 capture after first retained CO2 is present.
def eval_second(a, direction, seed, pow=14):
    shenv,envcent,nenv,psh,pc=z.parent_geom(a)
    # first CO2 fixed in validated best direction at near distance
    old83=next(x for x in r83 if x['parent'].startswith(a)); d1=DIRS[old83['best_dir']]
    meanr=np.mean([r.outer(r.AT[e]) for e in [a,'O','Na','O']]); dnear=.88*(meanr+r.outer(r.AT['C'])+r.outer(r.AT['O']))
    axis1=np.roll(d1,1); axis1=axis1 if abs(np.dot(axis1,d1))<.9 else np.array([0.,1.,0.])
    co21=z.co2_geom(d1*dnear,axis1)
    # second CO2 in selected direction, slightly farther radius to avoid identical center
    d2=direction; axis2=np.roll(d2,1); axis2=axis2 if abs(np.dot(axis2,d2))<.9 else np.array([1.,0.,0.])
    c2near=d2*(dnear*1.12); c2far=np.array([0.,0.,-17.])
    co22n=z.co2_geom(c2near,axis2); co22f=z.co2_geom(c2far,axis2)
    shco2=np.vstack([r.AT['C'],r.AT['O'],r.AT['O']])
    lo=np.array([-19.,-19.,-19.]);hi=-lo
    pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
    co21_far=z.co2_geom(np.array([0.,17.,0.]),axis1)
    def state(second, first_near=True):
        blocks=[shenv,psh,shco2,shco2]
        cents=[envcent,pc,co21 if first_near else co21_far,second]
        return np.vstack(blocks),np.vstack(cents)
    out={'seed':seed,'env_nodes':nenv}
    for eps in [.5,0.]:
        sh,cn=state(co22n,True);_,cf=state(co22f,True)
        _,cn0=state(co22n,False);_,cf0=state(co22f,False)
        add=r.eval_fixed(sh,cn,eps,pts,lo,hi)-r.eval_fixed(sh,cf,eps,pts,lo,hi)
        base=r.eval_fixed(sh,cn0,eps,pts,lo,hi)-r.eval_fixed(sh,cf0,eps,pts,lo,hi)
        out[f'second_capture_{eps:g}']=add; out[f'first_CO2_enhancement_{eps:g}']=add-base; out[f'without_first_{eps:g}']=base
    return out

r84=[]
for a in ['C','N']:
    coarse=[]
    for di,dv in enumerate(DIRS): coarse.append({'dir':di,**eval_second(a,dv,84000+di,pow=12)})
    bd=max(coarse,key=lambda v:v['second_capture_0.5'])['dir']
    vals=[eval_second(a,DIRS[bd],s,pow=15) for s in [84101,84102,84103]]
    strict=all(v['second_capture_0.5']>0 and v['second_capture_0']>0 for v in vals)
    enhanced=all(v['first_CO2_enhancement_0.5']>0 for v in vals)
    r84.append({'parent':f'{a}-O*-Na-O + CO2','best_dir':bd,'coarse':coarse,'vals':vals,'strict_second_capture':strict,'first_CO2_enhances_second':enhanced,
                'means':{k:float(np.mean([v[k] for v in vals])) for k in ['second_capture_0.5','without_first_0.5','first_CO2_enhancement_0.5','second_capture_0','first_CO2_enhancement_0']}})
out84={'run_id':'R84_SECOND_CO2_CONTINUATION','contract':'Start from R83 retained first CO2 state; ask whether a second intact B01 CO2 entity is also retained at epsilon=.5 and darkness, and whether first retained CO2 increases second-capture support.','rows':r84,'accepted_count':sum(x['strict_second_capture'] for x in r84)}
(ROOT/'SEAM_SECOND_CO2_CONTINUATION_R84.json').write_text(json.dumps(out84,indent=2))
print(json.dumps({'R83':{'accepted_count':out83['accepted_count'],'rows':[{'parent':x['parent'],'strict':x['strict'],'direction_pass':x['direction_pass'],'means':x['means']} for x in r83]},'R84':{'accepted_count':out84['accepted_count'],'rows':[{'parent':x['parent'],'strict':x['strict_second_capture'],'enhanced':x['first_CO2_enhances_second'],'means':x['means']} for x in r84]}},indent=2))
