#!/usr/bin/env python3
import json, importlib.util
from pathlib import Path
import numpy as np
from scipy.stats import qmc
ROOT=Path('/mnt/data/continuum_run'); HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r82',HERE/'r82_photosynthesis_continuation.py'); z=importlib.util.module_from_spec(spec); spec.loader.exec_module(z)
r=z.r; DIRS=z.DIRS
r83=json.load(open(ROOT/'SEAM_CO2_CAPTURE_FINAL_AUDIT_R83.json'))
a='N'; row=next(x for x in r83['rows'] if x['parent'].startswith(a)); d1=DIRS[row['best_dir']]

def eval2(d2,seed,pow=13):
 shenv,envcent,nenv,psh,pc=z.parent_geom(a)
 meanr=np.mean([r.outer(r.AT[e]) for e in [a,'O','Na','O']]); dn=.88*(meanr+r.outer(r.AT['C'])+r.outer(r.AT['O']))
 ax1=np.roll(d1,1); ax1=ax1 if abs(np.dot(ax1,d1))<.9 else np.array([0.,1.,0.])
 c1n=z.co2_geom(d1*dn,ax1); c1f=z.co2_geom(np.array([0.,17.,0.]),ax1)
 ax2=np.roll(d2,1); ax2=ax2 if abs(np.dot(ax2,d2))<.9 else np.array([1.,0.,0.])
 c2n=z.co2_geom(d2*dn*1.12,ax2); c2f=z.co2_geom(np.array([0.,0.,-17.]),ax2)
 shc=np.vstack([r.AT['C'],r.AT['O'],r.AT['O']]); lo=np.array([-19.,-19.,-19.]); hi=-lo
 pts=lo+qmc.Sobol(3,scramble=True,seed=seed).random_base2(pow)*(hi-lo)
 def state(first,second): return np.vstack([shenv,psh,shc,shc]),np.vstack([envcent,pc,first,second])
 out={'seed':seed}
 for eps in [.5,0.]:
  sh,n11=state(c1n,c2n);_,n10=state(c1n,c2f);_,n01=state(c1f,c2n);_,n00=state(c1f,c2f)
  add=r.eval_fixed(sh,n11,eps,pts,lo,hi)-r.eval_fixed(sh,n10,eps,pts,lo,hi)
  base=r.eval_fixed(sh,n01,eps,pts,lo,hi)-r.eval_fixed(sh,n00,eps,pts,lo,hi)
  out[f'second_capture_{eps:g}']=add; out[f'without_first_{eps:g}']=base; out[f'first_enhancement_{eps:g}']=add-base
 return out
coarse=[]
for i,d in enumerate(DIRS): coarse.append({'dir':i,**eval2(d,84200+i,pow=11)})
bd=max(coarse,key=lambda x:x['second_capture_0.5'])['dir']
vals=[eval2(DIRS[bd],s,pow=13) for s in [84301,84302,84303]]
strict=all(v['second_capture_0.5']>0 and v['second_capture_0']>0 for v in vals)
enh=all(v['first_enhancement_0.5']>0 for v in vals)
out={'run_id':'R84_SECOND_CO2_N_BRANCH','parent':'N-O*-Na-O + retained CO2','coarse':coarse,'best_dir':bd,'vals':vals,'strict_second_capture':strict,'first_CO2_enhances_second':enh,'means':{k:float(np.mean([v[k] for v in vals])) for k in ['second_capture_0.5','without_first_0.5','first_enhancement_0.5','second_capture_0','first_enhancement_0']}}
(ROOT/'SEAM_SECOND_CO2_CONTINUATION_R84.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
