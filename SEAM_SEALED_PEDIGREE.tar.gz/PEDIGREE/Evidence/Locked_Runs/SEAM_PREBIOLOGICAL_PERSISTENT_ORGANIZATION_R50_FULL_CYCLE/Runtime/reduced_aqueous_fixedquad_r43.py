#!/usr/bin/env python3
import sys,json,math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import reduced_aqueous_basin_r41 as r41
CASES=[('A_core','fresh',0.5),('A_core','brine',0.5),('A_core','brine',1.0),('B_ionic','brine',0.0),('C_trace','brine',0.0),('C_trace','brine',0.5)]
SP=[1.0,0.8,0.7,0.6,0.5,0.4,0.25]

def eval_fixed(sh,centers,eps,pts,vol):
    maxshell=max(np.nonzero(sh)[1])+1
    F=np.zeros(len(pts)); G=np.zeros(len(pts)); G2=np.zeros(len(pts))
    norms={n:math.sqrt(r41.norm2(n,eps)) for n in range(1,maxshell+1)}
    for i,row in enumerate(sh):
      d=np.linalg.norm(pts-centers[i],axis=1); gi=np.zeros(len(pts))
      for n,N in enumerate(row,1):
        if N<=0: continue
        mask=(d>=n-1)&(d<n)
        if not mask.any(): continue
        x=d[mask]-(n-1); u=((1-eps)+eps*(1-x))/norms[n]
        F[mask]+=math.sqrt(float(N))*u; gi[mask]+=(float(N)/r41.CAP[n-1])*u
      G+=gi; G2+=gi*gi
    f2=F*F; D=vol*float(f2.mean()); pos=f2>0
    ilog=vol*float(np.mean(np.where(pos,f2*np.log(np.where(pos,f2,1.0)),0.0)))
    sf=math.log(D)-ilog/D if D>0 else -math.inf
    cp=0.5*vol*float(np.mean(G*G-G2))
    return sf,cp

def run_case(pn,mn,eps):
    pels=r41.expand(r41.POOLS[pn]); mels=r41.expand(r41.MEDIA[mn]); els=pels+mels
    sh=np.asarray([r41.AT[e] for e in els],int); sc=r41.sconfig(sh)
    med=r41.medium_positions(len(mels), seed=41500+len(pels)+(0 if mn=='fresh' else 77))
    all_centers=[]
    for sp in SP: all_centers.append(np.vstack([r41.candidate_positions(len(pels),sp),med]))
    maxshell=max(np.nonzero(sh)[1])+1
    lo=np.min([c.min(0) for c in all_centers],axis=0)-maxshell
    hi=np.max([c.max(0) for c in all_centers],axis=0)+maxshell
    vol=float(np.prod(hi-lo))
    sob=qmc.Sobol(d=3,scramble=True,seed=43123+len(pels)+(0 if mn=='fresh' else 500))
    u=sob.random_base2(m=14); pts=lo+u*(hi-lo)
    rows=[]
    for sp,c in zip(SP,all_centers):
      sf,cp=eval_fixed(sh,c,eps,pts,vol); rows.append({'spacing':sp,'S_total_over_kB':sc+sf+r41.LAM_C*cp,'S_field_over_kB':sf,'S_coupling_over_kB':cp})
    best=max(rows,key=lambda x:x['S_total_over_kB']); idx=rows.index(best)
    strict=0<idx<len(rows)-1 and best['S_total_over_kB']>rows[idx-1]['S_total_over_kB'] and best['S_total_over_kB']>rows[idx+1]['S_total_over_kB']
    return {'pool':pn,'medium':mn,'epsilon':eps,'rows':rows,'best_spacing':best['spacing'],'strict_fixed_quadrature_interior_max':strict}

def main():
  rs=[run_case(*c) for c in CASES]
  finite=[{'pool':x['pool'],'medium':x['medium'],'epsilon':x['epsilon'],'best_spacing':x['best_spacing']} for x in rs if x['strict_fixed_quadrature_interior_max']]
  out={'run_id':'SEAM-REDUCED-AQUEOUS-FIXEDQUAD-R43','quadrature':'fixed-domain common scrambled Sobol 2^14 points across all confinement states per branch','cases':rs,'finite_cases':finite,'disposition':'FINITE_BASINS_CONFIRMED_FIXED_QUADRATURE' if finite else 'NO_FINITE_BASINS_CONFIRMED_FIXED_QUADRATURE'}
  p=Path('/mnt/data/continuum_run/SEAM_REDUCED_AQUEOUS_FIXEDQUAD_R43.json'); p.write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2)); print(p)
if __name__=='__main__':main()
