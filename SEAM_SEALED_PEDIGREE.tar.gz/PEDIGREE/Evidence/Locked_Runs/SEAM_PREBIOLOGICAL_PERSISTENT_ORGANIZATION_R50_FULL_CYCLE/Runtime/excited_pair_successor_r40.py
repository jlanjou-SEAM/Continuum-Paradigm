#!/usr/bin/env python3
import sys, json, math
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import excited_nnode_basin_r39 as r39
AT=r39.ATOMIC
ELS=['H','C','N','O','Mg']

def evpair(a,b,d,eps,kind,samples=16000,seed=4020):
    sh=np.asarray([AT[a],AT[b]],int); c=np.array([[0.,0.,0.],[d,0.,0.]])
    sf,cp,D,sup=r39.evaluate(sh,c,eps,kind,samples=samples,seed=seed)
    return r39.sconfig(sh)+sf+0.1*cp,sf,cp

def maxrad(el): return max(i+1 for i,n in enumerate(AT[el]) if n)

def main():
  pairs=[(ELS[i],ELS[j]) for i in range(len(ELS)) for j in range(i,len(ELS))]
  kinds=['linear','quadratic','edge']; epsvals=[0.25,0.5,0.75,1.0]
  rows=[]
  for a,b in pairs:
    sep=maxrad(a)+maxrad(b)+0.5
    for kind in kinds:
      for eps in epsvals:
        # separated comparator, common deterministic seed
        ssep,_,_=evpair(a,b,sep,eps,kind,seed=4001)
        ds=np.linspace(0.05,maxrad(a)+maxrad(b)-0.05,27)
        vals=[]
        for k,d in enumerate(ds):
          st,sf,cp=evpair(a,b,float(d),eps,kind,seed=4100+k)
          vals.append((float(d),st,sf,cp))
        best=max(vals,key=lambda x:x[1]); idx=vals.index(best)
        strict=0<idx<len(vals)-1 and best[1]>vals[idx-1][1] and best[1]>vals[idx+1][1]
        supported=strict and best[1]>ssep
        rows.append({'pair':f'{a}-{b}','kind':kind,'epsilon':eps,'separated_S':ssep,'best_d':best[0],'best_S':best[1],'delta_S_vs_separated':best[1]-ssep,'strict_coarse_interior':strict,'entropy_supported_relation':supported})
  supp=[r for r in rows if r['entropy_supported_relation']]
  out={'run_id':'SEAM-EXCITED-PAIR-SUCCESSOR-R40','contract':'PREEXEC-NONCANONICAL-SHELL-REDISTRIBUTION-R39','rows':rows,'supported':supp,'supported_count':len(supp),'disposition':'EXCITATION_SUPPORTS_FINITE_LOCAL_RELATIONS' if supp else 'NO_EXCITATION_SUPPORTED_LOCAL_RELATIONS'}
  p=Path('/mnt/data/continuum_run/SEAM_EXCITED_PAIR_SUCCESSOR_R40.json'); p.write_text(json.dumps(out,indent=2));
  print(json.dumps({'disposition':out['disposition'],'supported_count':len(supp),'supported':supp[:50]},indent=2)); print(p)
if __name__=='__main__':main()
