#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.spatial import ConvexHull

MATRIX='/mnt/data/continuum_run/Evidence/Data/Z001_Z128_Blind_Matrix/Z001_Z128_ATOMIC_SHELL_MATRIX.csv'
ZMAP={'H':1,'C':6,'N':7,'O':8,'Na':11,'Mg':12,'P':15,'S':16,'Cl':17,'K':19,'Ca':20,'Mn':25,'Fe':26,'Co':27,'Ni':28,'Cu':29,'Zn':30,'Mo':42}
POOLS={
 'A_core': {'C':30,'H':51,'O':12,'N':7,'P':1,'S':1},
 'B_ionic': {'C':30,'H':51,'O':12,'N':7,'P':1,'S':1,'K':2,'Na':1,'Mg':1,'Ca':1,'Cl':1},
 'C_trace': {'C':30,'H':51,'O':12,'N':7,'P':1,'S':1,'K':2,'Na':1,'Mg':1,'Ca':1,'Cl':1,'Fe':1,'Mn':1,'Zn':1,'Cu':1,'Co':1,'Ni':1,'Mo':1},
}
MEDIA={
 'fresh': {'H':60,'O':30},
 'brine': {'H':60,'O':30,'Na':6,'Cl':6,'Mg':2,'Ca':1,'K':2,'S':1},
}

def expand(counts):
    a=[]
    for e,n in counts.items(): a += [e]*n
    return a

def atomic_shell_radius():
    df=pd.read_csv(MATRIX).set_index('Z')
    out={}
    for e,z in ZMAP.items():
        row=df.loc[z]
        out[e]=int(row['boundary_shell'])
    return out
RADIUS=atomic_shell_radius()

def random_ball(n, R, rng):
    v=rng.normal(size=(n,3)); v/=np.linalg.norm(v,axis=1)[:,None]
    rr=R*rng.random(n)**(1/3)
    return v*rr[:,None]

def relax(elements, seed, steps=520, dt0=0.035, init_R=20.0):
    rng=np.random.default_rng(seed)
    n=len(elements)
    x=random_ball(n,init_R,rng)
    rad=np.array([RADIUS[e] for e in elements],float)
    r0=rad[:,None]+rad[None,:]
    np.fill_diagonal(r0,1.0)
    history=[]
    for t in range(steps):
        dvec=x[None,:,:]-x[:,None,:]  # vector i->j
        d=np.linalg.norm(dvec,axis=2)
        np.fill_diagonal(d,np.inf)
        u=dvec/np.where(np.isfinite(d),d,1.0)[:,:,None]
        far=d>r0
        near=d<r0
        # Regime-consistent direction only. Magnitudes are numerical relaxation weights.
        # Far-field: inward, inverse-square-shaped weight normalized at contact.
        mag_far=np.where(far, np.minimum(1.0,(r0/np.where(np.isfinite(d),d,1.0))**2),0.0)
        # Near-field: outward toward first non-overlap spacing; zero at contact.
        mag_near=np.where(near, np.clip((r0-d)/r0,0.0,1.0),0.0)
        pair=(mag_far-mag_near)[:,:,None]*u
        f=pair.sum(axis=1)/max(1,n-1)
        # remove pure translation
        f-=f.mean(axis=0)
        dt=dt0*(0.25+0.75*(1-t/steps))
        dx=dt*f
        x+=dx
        if t%100==0 or t==steps-1:
            finite=d[np.isfinite(d)]
            overlap=np.triu((d<r0),1).sum()
            contact_err=np.mean(np.abs(finite-r0[np.isfinite(d)])/r0[np.isfinite(d)])
            history.append({'step':t,'rms_move':float(np.sqrt(np.mean(dx*dx))), 'overlap_pairs':int(overlap),'mean_contact_error':float(contact_err)})
    x-=x.mean(axis=0)
    return x,rad,history

def boundary_metrics(x, rad, elements):
    n=len(x); rr=np.linalg.norm(x,axis=1)
    # hull-based outer boundary
    hull=ConvexHull(x)
    hidx=np.unique(hull.simplices.ravel())
    interior=np.setdiff1d(np.arange(n),hidx)
    # radial layering: identify outer narrow band and a valley below it
    qs=np.quantile(rr,[.1,.25,.5,.7,.8,.9,.95])
    hist,edges=np.histogram(rr,bins=18,range=(0,max(rr.max(),1e-9)))
    # Search for outer local peak preceded by a lower-density bin, with nonzero interior population.
    layered=False; layer=None
    for k in range(2,len(hist)-1):
        if hist[k]>=hist[k-1] and hist[k]>=hist[k+1] and hist[k]>=max(3,int(.08*n)):
            inner=hist[:k-1].sum()
            valley=hist[k-1]
            if inner>=max(5,int(.15*n)) and valley <= 0.5*hist[k]:
                layered=True; layer={'bin':k,'peak_count':int(hist[k]),'valley_count':int(valley),'inner_count':int(inner),'r_lo':float(edges[k]),'r_hi':float(edges[k+1])}
    # central occupancy and cavity scale
    central_count=int(np.sum(rr < 0.35*rr.max()))
    # hull surface composition vs bulk
    hull_frac=len(hidx)/n
    return {
      'n':n,'hull_nodes':int(len(hidx)),'hull_fraction':float(hull_frac),'interior_nodes':int(len(interior)),
      'hull_volume':float(hull.volume),'hull_area':float(hull.area),'radial_quantiles':qs.tolist(),
      'central_count_r_lt_0p35_rmax':central_count,'radial_hist':hist.tolist(),'radial_edges':edges.tolist(),
      'layered_boundary_candidate':bool(layered),'layer':layer,
      'hull_elements':{e:int(sum(elements[i]==e for i in hidx)) for e in sorted(set(elements))},
      'interior_elements':{e:int(sum(elements[i]==e for i in interior)) for e in sorted(set(elements))},
    }

def q_proxy_contrast(x, rad):
    # Native field-support proxy: sum occupied support weights by atomic shell radius.
    # Used only to ask whether the relaxed geometry creates an inside/outside field difference.
    rr=np.linalg.norm(x,axis=1); R=max(rr.max(),1e-9)
    probe_in=np.array([0.0,0.0,0.0])
    probe_out=np.array([1.35*R,0.0,0.0])
    def q(p):
        d=np.linalg.norm(x-p,axis=1)
        # support proxy: each retained atomic field is zero outside boundary shell
        vals=np.where(d<rad, 1.0/(rad**1.5), 0.0)
        F=vals.sum(); return F*F
    qi=q(probe_in); qo=q(probe_out)
    return {'q_inside_proxy':float(qi),'q_outside_proxy':float(qo),'contrast_proxy':float((qi-qo)/(qi+qo+1e-15))}

def run_branch(pool,medium,seeds):
    els=expand(POOLS[pool])+expand(MEDIA[medium])
    rows=[]
    for s in seeds:
        x,rad,hist=relax(els,s)
        m=boundary_metrics(x,rad,els); m.update(q_proxy_contrast(x,rad)); m['seed']=s; m['history']=hist
        rows.append(m)
    return {'pool':pool,'medium':medium,'nodes':len(els),'seeds':rows,'layered_count':sum(r['layered_boundary_candidate'] for r in rows)}

def main():
    seeds=[5201,5202]
    branches=[]
    for p in POOLS:
        for m in MEDIA:
            branches.append(run_branch(p,m,seeds))
    out={
      'run_id':'SEAM-NEAR-FAR-FREE-MOTION-R52',
      'scope':'SEAM archive-native two-regime configuration relaxation; no SI time/force projection',
      'law':{
       'far':'outside retained-field overlap: inward H_attr exterior response; numerical relax weight shaped as (R_contact/R)^2',
       'near':'inside retained-field overlap: variational S*(N_r) rises outward toward first non-overlap; numerical relax weight drives outward to contact',
       'contact':'R_contact = boundary_shell_i + boundary_shell_j from canonical Z1..128 matrix',
       'warning':'relaxation weights and steps are not physical force magnitudes or time; only regime direction and selected contact geometry are tested'
      },
      'branches':branches,
      'summary':[{'pool':b['pool'],'medium':b['medium'],'nodes':b['nodes'],'layered_boundary_candidates':b['layered_count'],'of':len(b['seeds']), 'mean_hull_fraction':float(np.mean([r['hull_fraction'] for r in b['seeds']])), 'mean_center_count':float(np.mean([r['central_count_r_lt_0p35_rmax'] for r in b['seeds']]))} for b in branches]
    }
    out['disposition']='BOUNDARY_CANDIDATE_FOUND' if any(b['layered_count'] for b in branches) else 'COMPACT_ATTRACTOR_ONLY_NO_LAYERED_BOUNDARY'
    p=Path('/mnt/data/continuum_run/SEAM_NEAR_FAR_FREE_MOTION_R52.json'); p.write_text(json.dumps(out,indent=2))
    print(json.dumps({'disposition':out['disposition'],'summary':out['summary']},indent=2)); print(p)
if __name__=='__main__': main()
