import json,sys,math
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import r56_parallel_ionic as r
from r60_brine_confinement_sweep import media, relax, coverage
D=json.load(open('/mnt/data/continuum_run/SEAM_IONIC_PAIR_WEIGHTED_R56.json'));W={}
for q in D['weights']:W[q['a'],q['b']]=W[q['b'],q['a']]=q['norm']
els=r.expand(r.POOLS['B_ionic'])+r.expand(media(2.0))
rows=[]
for seed in [6216,6316]:
    x,last=relax(els,W,seed,steps=1800,init_R=16.0)
    me=r.metrics(x,els); cov,ln,lr=coverage(x,els,me,nprobe=6000)
    rows.append({'seed':seed,'layered':me['layered'],'layer':me['layer'],'coverage':cov,'layer_nodes':ln,'layer_radius':lr,'rmax':me['rmax'],'central_count':me['central_count'],'last':last})
out={'run_id':'R61_BRINE_2X_CONFINEMENT_REFINE','brine_scale':2.0,'init_R':16.0,'steps':1800,'rows':rows,'persistent_layer_count':sum(x['layered'] for x in rows)}
Path('/mnt/data/continuum_run/SEAM_BRINE_2X_CONFINEMENT_REFINE_R61.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
