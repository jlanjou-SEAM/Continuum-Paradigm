import json,sys
sys.path.insert(0,'/mnt/data/continuum_run/Evidence/Runtime')
import r67_shallow_daynight_ratchet_tiny as r67

def run_static(seed,eps=0.5,cycles=4):
    elements=r67.expand(r67.r.POOLS['B_ionic'])+r67.expand(r67.medium(1.75))
    x=r67.shallow_init(len(elements),seed)
    hist=[];prev=None
    for c in range(cycles):
        x,rms=r67.phase_relax(x,elements,r67.WE[eps],125,h=5.0)
        A,st=r67.snap(x,elements,prev);prev=A.copy();st.update({'cycle':c+1,'epsilon':eps,'rms':rms});hist.append(st)
    first,last=hist[0],hist[-1]
    return {'seed':seed,'epsilon':eps,'history':hist,'delta':{'edges':last['edges']-first['edges'],'cycle_rank':last['cycle_rank']-first['cycle_rank'],'enclosure':last['enclosed_fraction']-first['enclosed_fraction']}}
rows=[]
for e in [0.0,0.5,1.0]: rows.append(run_static(6701,e))
out={'run_id':'R68_STATIC_EXCITATION_CONTROL','rows':rows}
open('/mnt/data/continuum_run/SEAM_SHALLOW_STATIC_CONTROL_R68.json','w').write(json.dumps(out,indent=2))
print(json.dumps([{'epsilon':q['epsilon'],'cycle_rank':[h['cycle_rank'] for h in q['history']],'edges':[h['edges'] for h in q['history']],'enclosure':[round(h['enclosed_fraction'],3) for h in q['history']],'delta':q['delta']} for q in rows],indent=2))
