#!/usr/bin/env python3
import json, importlib.util
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/continuum_run'); HERE=ROOT/'Evidence/Runtime'
spec=importlib.util.spec_from_file_location('r80',HERE/'r80_retained_chain_fourth_successor.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# Pull best dirs from R80 output
r80=json.load(open(ROOT/'SEAM_RETAINED_CHAIN_FOURTH_SUCCESSOR_R80.json'))
targets=[]
for v in r80['validated']:
    if v['fourth']=='O' and v['chain'] in ('N-O*-Na','C-O*-Na'):
        targets.append((v['chain'][0],v['best_dir']))
rows=[]
for a,di in targets:
    vals=[]
    for seed in [81101,81102,81103]:
        vals.append(m.eval_case(a,'O',m.DIRS[di],seed,pow=16))
    dirs=[]
    for j in range(len(m.DIRS)):
        vv=m.eval_case(a,'O',m.DIRS[j],81200+j,pow=15);dirs.append({'dir':j,**vv})
    strict=all(v['add_with_chain_0.5']>0 and v['chain_enhancement_0.5']>0 and v['add_with_chain_0']>0 for v in vals)
    dirpass=sum(v['add_with_chain_0.5']>0 and v['chain_enhancement_0.5']>0 and v['add_with_chain_0']>0 for v in dirs)
    rows.append({'chain':f'{a}-O*-Na + O','best_dir':di,'strict_3seed':strict,'direction_pass':dirpass,'vals':vals,'dirs':dirs,
                 'means':{k:float(np.mean([v[k] for v in vals])) for k in ['add_with_chain_0.5','add_without_Na_0.5','chain_enhancement_0.5','add_with_chain_0','chain_enhancement_0']}})
out={'run_id':'R81_FINAL_FOURTH_SUCCESSOR_AUDIT','contract':'Actual R63 compartment checkpoint, retained promoted-O+Na parent. Final oxygen-addition audit: 3 independent Sobol x2^16 on best direction plus 3 orthogonal direction checks x2^15. Acceptance requires positive fourth addition at epsilon=.5, positive enhancement caused by retained Na-containing chain, and positive fourth addition in darkness.','rows':rows,'accepted_count':sum(r['strict_3seed'] and r['direction_pass']>=2 for r in rows)}
(ROOT/'SEAM_FINAL_FOURTH_SUCCESSOR_AUDIT_R81.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'accepted_count':out['accepted_count'],'rows':[{'chain':r['chain'],'strict':r['strict_3seed'],'direction_pass':r['direction_pass'],'means':r['means']} for r in rows]},indent=2))
