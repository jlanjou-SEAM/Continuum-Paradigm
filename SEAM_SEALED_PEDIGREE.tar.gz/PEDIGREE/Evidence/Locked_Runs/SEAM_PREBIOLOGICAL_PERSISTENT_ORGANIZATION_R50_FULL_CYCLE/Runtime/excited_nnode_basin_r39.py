#!/usr/bin/env python3
import math, json
from pathlib import Path
import numpy as np

CAP=np.array([2,8,18,32,18,32,18],float)
ATOMIC={'H':[1,0,0,0,0,0,0],'C':[2,4,0,0,0,0,0],'N':[2,5,0,0,0,0,0],'O':[2,6,0,0,0,0,0],'Mg':[2,8,2,0,0,0,0]}
COUNTS={'C':61,'H':84,'N':4,'O':23,'Mg':1}
LAM_F=1.0; LAM_C=0.1

def shells():
    a=[]
    for el in ['H','C','N','O','Mg']:
        a += [ATOMIC[el]]*COUNTS[el]
    return np.asarray(a,int)

def lattice(n,spacing=7.0):
    side=math.ceil(n**(1/3)); pts=[]
    for i in range(side):
      for j in range(side):
       for k in range(side):
        pts.append((i*spacing,j*spacing,k*spacing))
        if len(pts)==n:
            q=np.asarray(pts,float); return q-q.mean(0)

def sconfig(sh):
    s=0.0
    for row in sh:
      for j,N in enumerate(row):
        if N: s+=math.log(math.comb(int(CAP[j]),int(N)))
    return s

def norm2(n,eps,kind):
    # raw shell profile g=(1-eps)+eps*h(x), x=r-(n-1), 0<=x<1
    # numerical Gauss integration; normalization is part of declared perturbation contract.
    xs,ws=np.polynomial.legendre.leggauss(48); x=(xs+1)/2; w=ws/2
    if kind=='linear': h=1-x
    elif kind=='quadratic': h=1-x*x
    elif kind=='edge': h=x
    else: h=np.ones_like(x)
    g=(1-eps)+eps*h
    r=(n-1)+x
    return float(4*math.pi*np.sum(w*r*r*g*g))

def profile(x,eps,kind):
    if kind=='linear': h=1-x
    elif kind=='quadratic': h=1-x*x
    elif kind=='edge': h=x
    else: h=np.ones_like(x)
    return (1-eps)+eps*h

def evaluate(sh,centers,eps,kind,samples=18000,seed=3900):
    maxshell=max(np.nonzero(sh)[1])+1
    lo=centers.min(0)-maxshell; hi=centers.max(0)+maxshell; vol=float(np.prod(hi-lo))
    rng=np.random.default_rng(seed); pts=lo+rng.random((samples,3))*(hi-lo)
    F=np.zeros(samples); G=np.zeros(samples); G2nodes=np.zeros(samples)
    norms={(n,eps,kind):math.sqrt(norm2(n,eps,kind)) for n in range(1,maxshell+1)}
    for i,row in enumerate(sh):
        d=np.linalg.norm(pts-centers[i],axis=1)
        gi=np.zeros(samples)
        for n,N in enumerate(row,1):
            if N<=0: continue
            mask=(d>=n-1)&(d<n)
            if not mask.any(): continue
            x=d[mask]-(n-1)
            u=profile(x,eps,kind)/norms[(n,eps,kind)]
            F[mask]+=math.sqrt(float(N))*u
            gi[mask]+= (float(N)/CAP[n-1])*u
        G+=gi; G2nodes+=gi*gi
    f2=F*F; D=vol*float(f2.mean())
    pos=f2>0
    ilog=vol*float(np.mean(np.where(pos,f2*np.log(np.where(pos,f2,1.0)),0.0)))
    sf=math.log(D)-ilog/D if D>0 else -math.inf
    cp=0.5*vol*float(np.mean(G*G-G2nodes))
    return sf,cp,D,float(pos.mean())

def main():
    sh=shells(); base=lattice(len(sh)); sc=sconfig(sh)
    scales=[1.00,0.70,0.50,0.35,0.25,0.18,0.12,0.08,0.04,0.00]
    epsvals=[0.0,0.25,0.50,0.75,1.0]
    kinds=['linear','quadratic','edge']
    rows=[]
    for kind in kinds:
      for eps in epsvals:
        # eps=0 duplicates kinds; keep only first
        if eps==0 and kind!='linear': continue
        for si,s in enumerate(scales):
            sf,cp,D,sup=evaluate(sh,base*s,eps,kind,seed=3900+si)
            st=sc+LAM_F*sf+LAM_C*cp
            rows.append(dict(kind=kind,epsilon=eps,scale=s,S_total_over_kB=st,S_config_over_kB=sc,S_field_over_kB=sf,S_coupling_over_kB=cp,D_mc=D,support_fraction=sup))
    groups={}
    for r in rows: groups.setdefault((r['kind'],r['epsilon']),[]).append(r)
    summaries=[]
    for key,rs in groups.items():
        rs=sorted(rs,key=lambda z:z['scale'], reverse=True)
        best=max(rs,key=lambda z:z['S_total_over_kB'])
        idx=rs.index(best)
        interior=0<best['scale']<1 and idx not in (0,len(rs)-1)
        strict=False
        if interior:
            strict=best['S_total_over_kB']>rs[idx-1]['S_total_over_kB'] and best['S_total_over_kB']>rs[idx+1]['S_total_over_kB']
        summaries.append(dict(kind=key[0],epsilon=key[1],best_scale=best['scale'],best_S_total_over_kB=best['S_total_over_kB'],strict_coarse_interior_maximum=bool(strict),delta_vs_scale1=best['S_total_over_kB']-rs[0]['S_total_over_kB']))
    basin=[x for x in summaries if x['strict_coarse_interior_maximum']]
    out={'run_id':'SEAM-FIRST-CELL-EXCITED-BASIN-R39','contract':'PREEXEC-NONCANONICAL-SHELL-REDISTRIBUTION-R39','restriction':'archive-native shapes only; no external chemistry/biology/temperature-pressure-solar calibration','inventory':COUNTS,'node_count':len(sh),'lambda_field':LAM_F,'lambda_coupling':LAM_C,'perturbation':{'epsilon':'0=canonical uniform shell; 1=full archive-resident profile shape','support':'canonical shell supports unchanged','shapes':['linear center-weighted','quadratic center-weighted','edge-weighted'],'pressure_proxy':'global native confinement scale; no SI pressure mapping'},'rows':rows,'summaries':summaries,'native_finite_basin_cases':basin,'disposition':'FINITE_ATTRACTOR_CASES_FOUND' if basin else 'NO_FINITE_ATTRACTOR_CASES_FOUND'}
    p=Path('/mnt/data/continuum_run/SEAM_FIRST_CELL_EXCITED_BASIN_R39.json'); p.write_text(json.dumps(out,indent=2))
    print(json.dumps({'disposition':out['disposition'],'basin':basin,'summaries':summaries},indent=2))
    print(p)
if __name__=='__main__': main()
