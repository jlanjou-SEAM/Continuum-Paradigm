#!/usr/bin/env python3
import json, math, hashlib
from pathlib import Path
ROOT=Path('/mnt/data/continuum_run')
NEW=Path('/mnt/data/continuum_new')

def load(p): return json.load(open(p))
r79=load(ROOT/'SEAM_FINAL_COMPARTMENT_PROMOTED_CHAIN_R79.json')
r81=load(ROOT/'SEAM_FINAL_FOURTH_SUCCESSOR_AUDIT_R81.json')
r83=load(ROOT/'SEAM_CO2_CAPTURE_FINAL_AUDIT_R83.json')
r84=load(ROOT/'SEAM_SECOND_CO2_CONTINUATION_R84.json')
oec=load(NEW/'Evidence/B01/OEC_CLOSED_BLOCK_R49/B01_OEC_CLOSED_BLOCK_RUN_01/CLOSED_BLOCK.json')
cont=load(NEW/'Evidence/B01/OEC_CLOSED_BLOCK_R49/B01_CONTINUOUS_BOUNDARY_CIRCUIT_TEST_01/RESULT.json')
photo=load(NEW/'Evidence/Records/B01_LIGHT_PHASE/B01_SEAM_PHOTOSYNTHESIS_STATE_EVOLUTION_01.json')

# exact R49 transport recurrence extended to 10k cycles, no invented carbon sink.
def oec_stream(cycles):
    co2=0.; o2=0.; total_o2=0.; total_co2=0.
    fco2=1-math.exp(-1.0); fo2=1-math.exp(-160.0)
    checkpoints=[]
    for c in range(1,cycles+1):
        imp=(1.0-co2)*fco2; co2+=imp; total_co2+=imp
        o2+=0.1; exp=o2*fo2; o2-=exp; total_o2+=exp
        if c in (1,10,40,100,1000,10000): checkpoints.append({'cycle':c,'CO2_internal':co2,'CO2_import_this_cycle':imp,'O2_export_this_cycle':exp,'O2_internal':o2})
    return {'cycles':cycles,'total_O2_export':total_o2,'total_CO2_import_without_sink':total_co2,'checkpoints':checkpoints}

rows83=[]
for x in r83['rows']:
    rows83.append({'parent':x['parent'],'strict_first_CO2_capture':x['strict'],'direction_pass':x['direction_pass'],'means':x['means']})

out={
 'run_id':'R85_PHOTOSYNTHESIS_LONGEVITY_ADJUDICATION',
 'updated_runner_basis':{
   'photosynthesis_state_evolution_contract':photo['contract_id'],
   'OEC_closed_block':oec['block_id'],
   'prototype_chain_sources':['R79_FINAL_COMPARTMENT_PROMOTED_CHAIN_AUDIT','R81_FINAL_FOURTH_SUCCESSOR_AUDIT'],
   'first_CO2_capture':'R83_CO2_CAPTURE_FINAL_AUDIT',
   'repeat_CO2_capture':'R84_SECOND_CO2_N_BRANCH'
 },
 'continuation_streams':{
   'retained_prototype_chain':{'status':'PASS','R79_accepted':r79['accepted_count'],'R81_accepted':r81['accepted_count']},
   'light_to_retained_state':{'status':'PASS_CANDIDATE','basis':'promoted O state remains retained and biases successors inside actual compartment field'},
   'first_CO2_retention':{'status':'PASS','accepted_branches':r83['accepted_count'],'rows':rows83},
   'repeat_CO2_retention':{'status':'FAIL_STRICT','strict':r84['strict_second_capture'],'first_retained_CO2_enhances_second':r84['first_CO2_enhances_second'],'means':r84['means']},
   'OEC_retained_state_recurrence':{'status':'CLOSED_IN_ARCHIVE','sequence':oec['closed_findings']['retained_cycle']['sequence'],'event_vector':oec['closed_findings']['event_vector_per_cycle']},
   'O2_export':{'status':'CONTINUES','test':oec_stream(10000)},
   'H2O_replenishment':{'status':'CONDITIONALLY_CONTINUES','basis':oec['closed_findings']['water_delivery']},
   'CO2_transport':{'status':'ONE_RETAINED_CAPTURE_PASS_REPEAT_STREAM_NOT_CLOSED','reason':'R83 removes one intact CO2 from free local pool reproducibly; R84 second intact CO2 capture is not sign-stable across all dense seeds.'},
   'electron_proton_event_streams':{'status':'CONTINUE_WITH_OEC_CYCLE','events_per_cycle':{'electron_state_transfers':4,'proton_release_events':4}}
 },
 'material_instantiation_caveat':{
   'status':'OPEN',
   'detail':'R49 OEC retained block requires the CaMn4O5/CaMn4O6 apparatus. The R63 prototype inventory includes Ca but does not itself demonstrate spontaneous Mn acquisition and OEC assembly. R85 therefore tests continuation compatibility, not endogenous construction of the mature OEC.'
 },
 'longevity_adjudication':{
   'prototype_internal_chain_persists':'PASS',
   'photosynthetic_OEC_cycle_can_recur_if_apparatus_present':'PASS_CLOSED_BLOCK',
   'first_CO2_retention_inside_prototype':'PASS',
   'continuous_CO2_retention_stream':'NOT_YET_PASS',
   'full_photosynthetic_longevity':'NOT_CLOSED',
   'current_terminal':'CONTINUATION_STREAMS_PARTIAL_PASS__OEC_ELECTRON_PROTON_O2_WATER_STREAMS_GO__CARBON_STREAM_IGNITES_ONCE_BUT_REPEAT_CAPTURE_NOT_SIGN_STABLE'
 }
}
(ROOT/'SEAM_PHOTOSYNTHESIS_LONGEVITY_R85.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out['longevity_adjudication'],indent=2)); print(json.dumps({'first_CO2':rows83,'repeat_CO2':out['continuation_streams']['repeat_CO2_retention'],'OEC_10k_last':out['continuation_streams']['O2_export']['test']['checkpoints'][-1]},indent=2))
