#!/usr/bin/env python3
import json, math
from pathlib import Path

ROOT=Path('/mnt/data/continuum_run')
OUT=ROOT/'SEAM_ATOMIC_FIELD_FREE_MOTION_R50.json'

# Archive-native facts audited from Technical Foundations O.4.8 and v18.6 molecular branch.
# We deliberately do not assign numerical K_ab, eta_ab(N_R), or Delta tau pair values.

# Exterior scaling proof. For any finite configuration with pair terms K_ij>0,
# H_ext = -sum K_ij/r_ij. Uniform contraction r -> lambda r gives H(lambda)=H(1)/lambda.
# Therefore for 0<lambda<1, H becomes strictly lower (more negative), so the exterior law
# alone cannot possess a finite free-space minimum or select a hollow boundary.
lam=[1.0,0.8,0.6,0.4,0.2]
# normalized symbolic H0=-1 only to show the exact scale ratio, not a physical amplitude.
scale_demo=[{'lambda':x,'H_over_abs_H0':-1/x,'force_scale_vs_lambda1':1/(x*x)} for x in lam]

result={
 'run_id':'SEAM-ATOMIC-FIELD-FREE-MOTION-R50',
 'scope':'SEAM archive only; no external chemistry or force constants',
 'requested_operation':'free atomic motion under SEAM atomic field binding force, then enclosure test',
 'archive_force_branches':{
   'long_range_attraction':{
      'Hamiltonian':'H_attr = -sum_ab K_ab * eta_ab(N_R)/N_R',
      'exterior_limit':'eta -> 1; f_ab_ext = -K_ab/N_R^2 * Rhat_ab',
      'numerical_short_range_eta_available':False,
      'numerical_K_ab_emitted_by_active_R28_runtime':False,
      'free_motion_status':'NOT_NUMERICALLY_EXECUTABLE_AT_BINDING_RANGE'
   },
   'v18_6_molecular':{
      'selector':'N_r* = argmax S*(N_r)',
      'thermal_H':'Delta H_th = integral T dS; constant-T form T[S*(N_r)-S_inf]',
      'total_force':'F_XY = -(1/L_XY) d DeltaH_total / dN_r',
      'pair_tau_mapping_bound':False,
      'archive_terminal':'SYMBOLIC_ONLY: TAU_PAIR_MAPPING_UNBOUND',
      'free_motion_status':'TOTAL_NUMERICAL_FORCE_NOT_EMITTED'
   }
 },
 'exact_exterior_scaling_test':{
   'assumption':'exterior attraction scope only; positive attraction pair amplitudes',
   'uniform_contraction':'r_ij -> lambda r_ij',
   'identity':'H_ext(lambda)=H_ext(1)/lambda',
   'consequence':'for 0<lambda<1, exterior H decreases monotonically under contraction; no finite free-space minimum follows from exterior law alone',
   'normalized_scale_demo':scale_demo,
   'boundary_consequence':'EXTERIOR_ATTRACTION_ALONE_CANNOT_SELECT_A_FINITE_HOLLOW_COMPARTMENT'
 },
 'required_native_completion_for_requested_simulation':[
   'numerical short-range eta_ab(N_R), OR an explicitly bound total molecular DeltaH_ab(N_R) curve',
   'numerical pair amplitude K_ab for each retained pair state if H_attr is the chosen branch',
   'count-time/inertial update rule for positions if literal trajectory rather than equilibrium selection is required'
 ],
 'can_still_be_solved_without_literal_time_evolution':{
   'method':'solve the SEAM variational equilibrium directly over unconstrained atomic coordinates using the complete field state, then test enclosure',
   'caveat':'this is configuration selection by entropy, not a force-trajectory simulation'
 },
 'terminal':'FIELD_BINDING_MECHANISM_CONFIRMED__FREE_MOTION_NUMERICAL_SHORT_RANGE_OPERATOR_NOT_EXPOSED'
}
OUT.write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
print(OUT)
