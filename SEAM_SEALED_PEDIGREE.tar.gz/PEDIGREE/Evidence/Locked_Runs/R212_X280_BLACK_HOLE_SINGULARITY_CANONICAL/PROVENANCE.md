# Provenance

Canonical source: `02_CONTINUUM_TECHNICAL_FOUNDATIONS.md`.

Relevant authority excerpts:
- FP-02 continuity first.
- FP-05 entropy selection.
- FP-07 native structure before conventional projection.
- FP-10 silence is prohibition, not permission.
- §4.7.7 undeclared required object -> `INDETERMINATE: UNDECLARED_INPUT`.
- §4.7.8 external material cannot repair missing canonical mathematics.
- O.4.8 attraction Hamiltonian.
- O.4.8.1 only the exterior limit of `eta` is explicitly fixed.

No external comparator was consumed in native execution.
