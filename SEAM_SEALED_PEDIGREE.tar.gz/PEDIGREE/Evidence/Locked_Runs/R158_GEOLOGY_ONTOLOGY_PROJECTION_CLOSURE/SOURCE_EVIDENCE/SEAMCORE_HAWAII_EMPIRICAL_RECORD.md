# SEAMCORE R9.8.2 — Hawaii Volcanic Chain Empirical Geology Record

## Primary source
The complete original repository is retained intact at:

`Evidence/SEAMCORE/Original_Repository_R9_8_2/SEAM_CORE_FULL_REPOSITORY_R9_8_2.zip`

SHA-256:

`20573a304dd4e459fc870351e2a126bac0fd6cacbc50fa8265c91e73dbce6b95`

## Frozen runtime evidence
The repository's `inference_prompt.json` is timestamped:

`2026-05-08T15:12:20.522628Z`

It contains a `TARGET` hypothesis for:

`Hawaii Volcanic Chain`

with hypothesis:

`persistent shallow seismic activation`

The frozen target reports:
- realization probability: `0.6818`
- persistence: `0.6214`
- coherence: `0.6625`
- observation count: `67`
- source set: `EMSC_GLOBAL, HAWAII_QUERY, USGS_25_DAY, USGS_ALL_DAY, USGS_ALL_HOUR`

The retained candidate ring contains `166` Hawaii Volcanic Chain rows across `11` candidate IDs, with probability range `0.6547`–`0.6818` and persistence range `0.6185`–`0.6214`.

The Hawaii-focused observation extract retains `248` Hawaii-related seismic observations from the original observation ring.

## Empirical timing
This SEAMCORE snapshot was generated on May 8, 2026, during the continuing Kīlauea summit-eruption sequence. Episode 46 had occurred on May 5, 2026 and lasted nine hours. USGS's May 8 update recorded the eruption as paused following episode 46, while the May 8 mapping product documented lava-flow and tephra accumulation from episodes 45 and 46.

## Standing
This is primary empirical evidence that SEAMCORE was operating on real seismic observations and persistently modeling the Hawaii volcanic/seismic structure contemporaneously with the Kīlauea eruption sequence.

It materially supports the SEAM geology branch.

It does not by itself constitute the stronger S-061 test of quantitative tectonic plate-motion prediction from native material structure.
