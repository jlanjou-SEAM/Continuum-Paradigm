# R158 Scientific Evidence / Post-freeze comparators

## Existing SEAM empirical geology evidence
`SEAMCORE_HAWAII_EMPIRICAL_RECORD.md` documents operation on real Hawaii seismic observations during the Kilauea eruption sequence and persistent Hawaii Volcanic Chain target resolution.

Its explicit boundary is preserved: it does not demonstrate blind quantitative plate-velocity prediction.

## Independent scientific comparators

### U.S. Geological Survey — What drives the plates?
USGS, *Some unanswered questions — This Dynamic Earth*:
https://pubs.usgs.gov/gip/dynamic/unanswered.html

USGS states that plate-driving forces are not precisely or fully understood, that several mechanisms have been proposed, and that no proposed mechanism explains all facets of plate movement. This directly supports the C-059 inference boundary and contradicts treating one complete driver story as uniquely proven by the observation of plate motion itself.

### EarthScope / UNAVCO — Plate Motion Calculator
https://www.unavco.org/software/geodetic-utilities/plate-motion-calculator/plate-motion-calculator.html

The calculator determines plate motion from selected plate-motion models and permits angular velocity to be specified as an Euler pole plus rotation rate. This demonstrates the status of Euler-pole quantities as kinematic model parameters for plate motion.

### USGS — Understanding plate motions
https://pubs.usgs.gov/gip/dynamic/understanding.html

USGS describes observed relative plate motions and plate-boundary types. These observations establish plate kinematics and deformation without making the geometric description itself a unique causal explanation.

## Scientific closure boundary
R158 does not reject established geodynamic models. It retains their measured and predictive relations as downstream scientific models while separating those successful representations from a claim of unique primitive causation.
