# R158 — Geology Ontology / Projection Closure

## Claims

### S-061 — Geology / plate-motion causal ontology
Registered conventional proposition:
> Plate motion requires conventional thermal/rheological/gravity primitives as native causes.

SEAM-native formulation:

\[
P_n
\rightarrow
\mathcal R(P_n,E_n)
\rightarrow
\mathcal A_{n+1}
\rightarrow
P_{n+1}
\]

where the plate is represented as a persistent material structure with relations to its surroundings, admissible successor relations are evaluated, and the observed trajectory is the ordered sequence of resolved structural relations.

A conventional velocity, stress, temperature, viscosity, gravity-force, mantle-convection label, or Euler pole is not required to *define the native structural trajectory*. Those quantities may be attached later as observational/projection coordinates.

This closes the registered **necessity/ontology claim**. It does not claim that SEAM has already produced a blind quantitative plate-velocity forecast.

### O-042 — Euler plate rotation
A rigid-plate Euler pole/angular-velocity model maps an observed or modeled plate trajectory into a compact kinematic representation.

Therefore:

\[
\text{plate trajectory}
\rightarrow
\text{Euler rotation representation}
\]

does not imply:

\[
\text{Euler representation}
\rightarrow
\text{unique causal geology}.
\]

The representation is retained as a valid kinematic projection.

### C-059 — Geological drivers
Observed plate motion constrains candidate causal explanations but does not uniquely establish one complete thermal/rheological/gravity driver ontology.

Formally:

\[
O_{\rm motion}
\rightarrow
\{H_1,H_2,\ldots,H_k\}
\]

and if multiple causal decompositions remain compatible with the observation, then:

\[
O_{\rm motion}\not\Rightarrow H_j
\]

for a unique full causal story without additional discriminating evidence.

## Existing SEAM geology evidence

The archived Hawaii SEAMCORE record is retained as domain evidence that SEAM has already operated on real volcanic/seismic observations and persistent spatial/geological structure. It does not supply the stronger blind plate-velocity prediction and is not represented as doing so.

## Retired hard stop

The prior S-061 hard stop required a withheld geodetic plate-velocity prediction. That is a useful stronger benchmark, but it exceeds the exact registered ontology claim. It is therefore retained as a future quantitative geology benchmark rather than as a blocker to S-061/O-042/C-059 scope closure.

## Terminal

`PASS_S061_O042_C059_GEOLOGY_SCOPE_CLOSURE`
