# R178 S-071 adjudication

**Terminal:** `SOURCE_BINDING_REQUIRED_NUCLEAR_ISOMER_CANDIDATE_CONSTRUCTOR`

The locked run reached the canonical FP-10 hard stop before empirical comparator exposure. The package contains equations for normalization, spectrum, entropy, and `D_iso`, but does not contain a declared nuclear same-count candidate generator. The technical foundations explicitly bind `A_k` arbitration to competing **electron-shell arrangements**; extending that object to nuclear isomer arrangements without a declared mapping would be an invented operator.

Accordingly:

- S-071 is **not falsified**: no generated nuclear pair reached `D_iso`.
- S-071 is **not closed**: the precommitted verification did not execute.
- No empirical isomer label, excitation energy, or half-life was used to patch the missing constructor.
- The exact missing bridge is now isolated: `S_nuclear(P,N,E,A_k)` / same-count nuclear relational candidate construction.
