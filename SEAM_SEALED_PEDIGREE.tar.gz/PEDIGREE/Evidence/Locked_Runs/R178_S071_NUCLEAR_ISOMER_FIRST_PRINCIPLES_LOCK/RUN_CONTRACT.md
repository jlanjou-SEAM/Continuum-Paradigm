# R178 — S-071 Nuclear Isomer First-Principles Locked Run Contract

## Claim
At fixed primitive nuclear counts, a real nuclear-isomer pair is natively distinguishable from the complete retained relational state before empirical isomer labels, excitation energies, or half-lives are exposed.

## Precommitted verification
Generate the complete same-`P,N,E` candidate family from declared SEAM first principles; compute `T`, `spec(T)`, `H*`, and `D_iso`; seal the native pair; then reveal empirical isomer data. PASS requires `D_iso > 0` and one-to-one post-seal mapping.

## Precommitted falsification
FAIL if a documented real same-count isomer pair is generated but remains natively indistinguishable, or if the sealed candidates fail one-to-one empirical mapping.

## Hard-stop rule
FP-10 applies: a required undeclared construction object terminates as `SOURCE_BINDING_REQUIRED`; no empirical isomer state may be inserted to manufacture the missing native candidate. A hard stop is not a falsification of S-071 because the discriminator has not executed on generated candidates.

## Native equations frozen before comparator exposure
`T = diag(x) S diag(x)` with row-sum closure; `H*(T)=-sum p_i ln p_i`; arrangement arbitration `k*=argmax H*_k`; `D_iso(a,b)=||ΔT||+||Δspec(T)||+|ΔH*|`.

## Comparator firewall
Empirical isomer identity, excitation energy, and half-life are prohibited generative inputs. Comparator reveal occurs only after a native pair is sealed.
