#!/usr/bin/env python3
import json, hashlib
from copy import deepcopy

CS_DEN=9_192_631_770

ATOMIC = {
'H':[1,0,0,0,0,0,0],
'C':[2,4,0,0,0,0,0],
'N':[2,5,0,0,0,0,0],
'O':[2,6,0,0,0,0,0],
'Mg':[2,8,2,0,0,0,0],
}

CHLA = {'formula':'C55H72MgN4O5','counts':{'C':55,'H':72,'Mg':1,'N':4,'O':5}}
CO2 = {'formula':'CO2','counts':{'C':1,'O':2}}
H2O = {'formula':'H2O','counts':{'H':2,'O':1}}

# Simultaneous multi-frequency coordinates. Labels are experimental grouping only;
# no regime-specific operator is selected and no amplitude/energy law is invented.
EXCITATION_SET = {
    'IR':  [30_000_000_000_000, 60_000_000_000_000, 100_000_000_000_000],
    'VIS': [400_000_000_000_000, 500_000_000_000_000, 600_000_000_000_000, 700_000_000_000_000],
    'UV':  [800_000_000_000_000, 900_000_000_000_000, 1_000_000_000_000_000],
}

TEMPS_F=[65,75,85,95,105,110]


def digest(obj):
    b=json.dumps(obj,sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(b).hexdigest()


def expand_formula(mol):
    return [{'element':el,'atomic_state':ATOMIC[el]} for el,n in mol['counts'].items() for _ in range(n)]

base_apparatus={
    'components':{
        'chlorophyll_a': {'identity':CHLA,'atoms':expand_formula(CHLA),'role':'retained_apparatus_component'},
        'carbon_dioxide': {'identity':CO2,'atoms':expand_formula(CO2),'role':'reactant'},
        'water': {'identity':H2O,'atoms':expand_formula(H2O),'role':'reactant'},
    },
    'atomic_states_fixed':True,
    'molecular_relations':'RETAIN_COMPLETE_RELATIONAL_STATE_REQUIRED',
    'no_reduction':True,
}

states=[]
for idx,temp in enumerate(TEMPS_F):
    n_cs=CS_DEN*(idx+1) # exact 1-second-count multiples as ordered physical intervals
    T_num=n_cs
    T_den=CS_DEN
    y={
      'step':idx,
      'apparatus':base_apparatus,
      'metrology':{'n_Cs':n_cs,'T_exact':f'{T_num}/{T_den}'},
      'thermal_condition':{'fahrenheit_ingress':temp,'role':'declared_experimental_state_coordinate'},
      'external_em_excitation':{
          'simultaneous_sources':EXCITATION_SET,
          'frequency_role':'N_T_over_Cs_resolved_T_coordinate',
          'source_combination':'single_complete_event_state',
          'independent_scalar_response_sum':False,
      },
      'history':{'predecessor_hash': states[-1]['state_hash'] if states else None},
    }
    y['state_hash']=digest(y)
    states.append(y)

# Exact native transfer can be represented as an ordered structured state change.
transfers=[]
for a,b in zip(states,states[1:]):
    transfers.append({
      'from':a['state_hash'],'to':b['state_hash'],
      'declared_changes':{
          'thermal_condition':[a['thermal_condition'],b['thermal_condition']],
          'excitation_present_continuously':True,
          'apparatus_identity_changed':False,
          'atomic_states_changed':False,
      },
      'T_native':'STRUCTURED_TRANSFORMATION_INSTANTIATED'
    })

# Audit executable bindings available in current R33 runtime.
# R4TSF is pair-only and not invoked. No current heterogeneous complete-apparatus
# Xi/entropy successor evaluator is available in Evidence/Runtime.
runtime_audit={
  'R4_invoked':False,
  'R4_reason':'not the reaction engine; pair variational subproblem only',
  'complete_event_chain_instantiated':True,
  'history_preserved':all(states[i]['history']['predecessor_hash']==states[i-1]['state_hash'] for i in range(1,len(states))),
  'simultaneous_multifrequency_state_instantiated':True,
  'thermal_range_instantiated':TEMPS_F,
  'atomic_states_fixed':True,
  'chlorophyll_isolated_as_target':False,
  'next_state_entropy_reresolution_executed':False,
  'chemistry_terminal_reached':False,
  'terminal':'SYMBOLIC_ONLY_COMPLETE_EVENT_CHAIN_NO_BOUND_FULL_APPARATUS_XI_ENTROPY_EXECUTOR'
}

out={
  'test_id':'B01-FULL-CHAIN-RETEST-02',
  'question':'Can current SEAM execution carry chlorophyll-a + CO2 + H2O through a hysteretic simultaneous IR/VIS/UV + thermal complete-state chain and numerically re-resolve the next molecular state?',
  'initial_apparatus_hash':digest(base_apparatus),
  'state_count':len(states),
  'transfer_count':len(transfers),
  'states':states,
  'transfers':transfers,
  'runtime_audit':runtime_audit,
  'empirical_chlorophyll_spectrum_used_for_native_selection':False,
  'disposition':'CHAIN_CONSTRUCTION_PASS; NATIVE_TRANSFER_ACCOUNTING_PASS; NUMERIC ENTROPY-DIRECTED REACTION EVOLUTION NOT EXECUTED'
}

with open('/mnt/data/seam_r33/B01_FULL_CHAIN_RETEST.json','w') as f: json.dump(out,f,indent=2)
print(json.dumps({k:out[k] for k in ['test_id','state_count','transfer_count','runtime_audit','disposition']},indent=2))
