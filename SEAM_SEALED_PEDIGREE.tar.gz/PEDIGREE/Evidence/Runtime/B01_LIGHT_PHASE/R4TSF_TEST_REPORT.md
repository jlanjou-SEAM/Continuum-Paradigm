# R4TSF-01 — SEAM-native time-space-frequency interface test

## Frozen base
Runtime: VF-REGION-LBFGSB-R4
SHA-256: 1923156b93e320c85de162e1af06dff0e8f195ace588fc9d2f96e9a2ec0af28d

## Native input law
T = n_Cs / 9,192,631,770
N_D = native structural separation count
f = N_T / T

No speed of light, wavelength, photon energy/hf, sinusoidal phase, or Hamiltonian excitation is admitted upstream.

## Executed comparison at N_D=6.2
Control: n_Cs=9,192,631,770; N_T=0; f=0.
Excited event: same n_Cs and N_D; N_T=500,000,000,000,000; f derived internally; external_em state present.

Control S*/k_B = 12.502276251235417
Excited S*/k_B = 12.502276251235417
Delta S* = 0.0
Control gradient norm = 5.024295863460037e-07
Excited gradient norm = 5.024295863460037e-07
Selected native detail identical = True

## Gate test
A photon_energy excitation key is rejected with FORBIDDEN_NON_SEAM_EXCITATION_KEYS.

## Disposition
SEAM-centric metrology is now enforced by the successor interface. The null result persists because the unchanged R4 evaluator is called only with (N, c, N_D, lambda_field, lambda_coupling). T, N_T, derived f, and excitation-state content do not enter the R4 entropy objective. Therefore, at fixed N_D, the same R4 problem is solved exactly. The remaining missing executable relation is not time, space, or frequency metrology; it is the SEAM-native coupling from complete excitation-state change into the admissible molecular field/entropy state.
