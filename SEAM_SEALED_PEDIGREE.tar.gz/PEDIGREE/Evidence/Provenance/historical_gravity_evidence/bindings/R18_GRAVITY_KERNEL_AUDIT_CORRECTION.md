# R18 Gravity Kernel Audit Correction

R18 supersedes the R17 terminal `SEAM_NATIVE_GRAVITY_SCALE_CONTINUATION_CLOSED`. Inspection of the archived R16 runtime shows that the numerical body-aggregation test supplied a unit-amplitude inverse-square pair kernel as `dx/(r2*r)`. Therefore the runtime verifies preservation of an assumed inverse-square kernel under aggregation, not derivation of the kernel from SEAM atomic structure.

Current terminal: `SEAM_GRAVITY_MACRO_CONTINUATION_CONDITIONAL__MICRO_PAIR_KERNEL_REQUIRED`.

The exact active proof target is `(C_X,C_Y,N_R) -> mathfrak f_XY(N_R)`, with both radial form and native amplitude generated upstream before body aggregation. Newtonian `G`, SI fitting, and target calibration remain prohibited as defining inputs.
