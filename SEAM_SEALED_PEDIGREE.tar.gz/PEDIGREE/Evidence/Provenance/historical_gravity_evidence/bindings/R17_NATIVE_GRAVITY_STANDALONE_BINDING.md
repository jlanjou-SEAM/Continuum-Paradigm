# R17 Native Gravity Stand-Alone Binding

Revision: `CP-MASTER-2026.09.05-R17`

R17 supersedes the R16 artificial terminal `NATIVE_RESIDUAL_FIELD_AMPLITUDE_BINDING_REQUIRED`. The current authority treats the already-resolved net constituent field/pair response as the repeated aggregation unit established by the atomic→molecular equivalence. Macroscopic scale therefore does not require a new force amplitude, Newtonian `G`, empirical calibration, or SI regression. Native space/time scaling uses the existing count ratios. Evidence 25 remains provenance for the superseded intermediate R16 framing; Evidence 26 is the current stand-alone proof.
