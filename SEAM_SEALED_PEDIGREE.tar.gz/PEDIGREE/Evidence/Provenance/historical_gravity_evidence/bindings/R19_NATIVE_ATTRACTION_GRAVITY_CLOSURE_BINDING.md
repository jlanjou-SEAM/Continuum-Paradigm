# R19 Native Attraction / Gravity Closure Binding

Revision: `CP-MASTER-2026.09.06-R19`

Current authority: Appendix O.4.8 and Evidence 28.

Source lineage is retained in `provenance/HISTORICAL_FIELD_HAMILTONIAN_FORMULATION_SOURCE_BINDING.md`, which identifies the recovered attraction/torsion source artifacts containing the attraction Hamiltonian, radial `eta(N_R)/N_R` factor, state-derived pair energy, complete force derivative, body aggregation, and torsion projection.

R19 scope ruling:

- v18.6 variational molecular selected-state branch: retained; `TAU_PAIR_MAPPING_UNBOUND` remains molecular-scope where applicable.
- long-range attraction/gravity branch: governed by separately declared `H_attr`; not terminated by the molecular pair-time boundary.
- R16/R17 unit-amplitude inverse-square runtime: retained as an aggregation implementation check only.
- R18 line-level audit: retained as correct audit of that runtime; its framework-level `MICRO_PAIR_KERNEL_REQUIRED` terminal is superseded by recovery of the declared `H_attr` branch.
