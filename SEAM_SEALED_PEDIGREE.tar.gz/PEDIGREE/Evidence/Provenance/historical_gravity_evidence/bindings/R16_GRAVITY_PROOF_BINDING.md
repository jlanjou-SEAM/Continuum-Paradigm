# R16 Gravity Proof Binding

Revision: `CP-MASTER-2026.09.05-R16`

## Purpose

Bind the active gravity branch to the SEAM-native metrology and operator direction. This revision removes SI quantities and Newtonian constants from the native gravitational calculation.

## Recovered project basis

- `SEAM_AGGREGATION_OPERATOR_CHECKPOINT_V1.md`: body source `A(B)=sum mu_a-C_internal(B)`, extensive same-state aggregation, cross-body multiplicative interaction.
- `SEAM_Irrefutable_Verified_Additions.md`: executed conditional Macro Lattice Aggregation theorem; additive inverse-square constituent response preserves inverse-square body-scale behavior.
- `SEAM_Technical_Foundations_CANONICAL_METROLOGY_PASS_RECORDED.docx`: projection law, Cs-count time, native distance count, and atomic metrology dependency direction.
- Historical attraction records: gravity is the macroscopic residual electric/magnetic structural interaction, not an independent force primitive.

## R16 correction

The native gravity chain is now expressed only in retained state and native coordinates:

`constituent state -> A(B)/S_M -> Lambda(N_R) -> -dLambda/dN_R -> finite-body native interaction -> freeze`.

`G`, meters, conventional seconds, kilograms as causal variables, newtons, and conventional acceleration are projection/comparator quantities only.

The 10 kg Fe designation remains external ingress metadata. The native run begins from the already-resolved retained Fe constituent state.

## Executed result

`runtime/gravity_proof_r16.py` executes native doubled-distance/doubled-source ratios and a deterministic native-coordinate macro aggregation test. Evidence 25 contains the complete transcript and machine terminal.

## Exact boundary

The first unresolved numerical object is the native constituent residual-field amplitude (`mu_a`, `C_internal(B)`, or an exactly equivalent declared native constructor). It may not be replaced by a conventional gravity constant or fitted comparator.
