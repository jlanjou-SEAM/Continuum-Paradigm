# Evidence 28 — SEAM Native Attraction / Gravity Closure (R19)

**Revision:** CP-MASTER-2026.09.06-R19  
**Standing:** CURRENT GRAVITY AUTHORITY  
**Terminal:** `SEAM_NATIVE_ATTRACTION_GRAVITY_PROCESS_CLOSED`

## 1. Purpose

This evidence record resolves the R18 documentation contradiction. R18 correctly proved that the R16/R17 runtime did not derive gravity because it inserted a unit-amplitude inverse-square kernel. R18 then overextended that implementation audit into a framework-level statement that no native microscopic radial operator was available. The shared-project attraction formulation already declares a separate long-range attraction Hamiltonian.

## 2. Operator-scope correction

The v18.6 variational molecular branch and the long-range attraction branch are distinct operators. The molecular branch may terminate `SYMBOLIC_ONLY: TAU_PAIR_MAPPING_UNBOUND` for a requested total molecular energy when no selected-state pair-time mapping is supplied. That terminal does not propagate into the gravity branch.

The long-range branch is

\[
H_{\rm attr}
=
-\sum_{a,b}E_{ab}g_{\Theta,ab}
\frac{\eta_{ab}(N_{R,ab})}{N_{R,ab}}\mathcal S_{ab}.
\]

with

\[
E_{ab}=|H(C_{ab}^*)-H(C_a^*\oplus C_b^*)|,
\]

and native force

\[
\mathfrak f_{ab}=-\partial_{N_{R,ab}}H_{\rm attr}\,\hat{\mathbf R}_{ab}.
\]

## 3. Exterior closure

The attraction constructor declares `eta(N_R) -> 1` outside the short-range regularization domain. Define only as shorthand

\[K_{ab}=E_{ab}g_{\Theta,ab}\mathcal S_{ab}.\]

Then

\[
H_{\rm attr,ab}^{\rm ext}=-K_{ab}/N_{R,ab},
\]

and therefore

\[
\boxed{\mathfrak f_{ab}^{\rm ext}=-K_{ab}N_{R,ab}^{-2}\hat{\mathbf R}_{ab}.}
\]

The inverse-square law is therefore a consequence of the declared attraction Hamiltonian. The R16/R17 runtime is not used as its derivation.

## 4. Native magnitude

`K_ab` is not a gravity constant. It is the product of state-derived attraction quantities already declared by the operator. A selected pair run evaluates `E_ab`, `g_Theta,ab`, and `S_ab`; no Newtonian `G`, SI calibration, unit-amplitude substitution, or Cavendish fit defines them.

## 5. Macroscopic continuation

For retained bodies,

\[
\mathfrak F_{A\leftarrow B}
=\sum_{a\in A}\sum_{b\in B}\mathfrak f_{ab}(N_{R,ab}).
\]

The continuum form is an equivalent representation of the same sum. The verified R16/R17 aggregation result remains useful here only as an implementation check that an inverse-square constituent law preserves its exterior exponent under the tested body aggregation.

## 6. Projection firewall

The native calculation uses SEAM state, `N_R`, state-derived pair factors, and native derivatives. Newton's `G`, conventional `g`, kilograms-as-force variables, meters, newtons, or torsion targets do not define the native interaction. They may be used only after native freeze as downstream projection/comparison quantities.

## 7. Closure audit

```text
R18 hardcoded-kernel audit                         PASS / retained
R16/R17 runtime derives microscopic gravity law    FALSE
v18.6 TAU_PAIR_MAPPING_UNBOUND is gravity terminal FALSE
long-range H_attr operator declared                TRUE
eta -> 1 exterior limit                            TRUE
H_attr exterior derivative -> 1/N_R^2             PASS_ANALYTIC
state-derived native magnitude                     DEFINED BY E_ab*g_Theta,ab*S_ab
finite-body aggregation                            CLOSED
Newton G required as primitive                     FALSE
SI calibration required to define native law       FALSE
terminal                                            SEAM_NATIVE_ATTRACTION_GRAVITY_PROCESS_CLOSED
```

## 8. Current interpretation

The process is closed at the operator level. Numerical values for a particular material/body are instance evaluations of the declared state-derived factors and retained population; they are not missing laws or free gravity parameters.
