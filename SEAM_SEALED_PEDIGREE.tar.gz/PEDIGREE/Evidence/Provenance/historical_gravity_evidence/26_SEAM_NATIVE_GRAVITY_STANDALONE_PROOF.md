# Evidence 26 — Conditional Native Gravity Aggregation Result

**Standing:** retained as R17 provenance; interpretation corrected by R18 / Evidence 27.

## 1. Scope correction

The R17 artifact correctly demonstrated population aggregation and native time-space continuation, but it overstated microscopic closure.

The archived numerical kernel was supplied explicitly as

```text
dx/(r2*r)
```

which is the x-component of a unit-amplitude `1/r^2` radial interaction. Consequently the numerical calculation tests whether an already-supplied inverse-square pair law retains its exponent after finite-body aggregation.

It does not derive the inverse-square exponent from a SEAM atomic/pair state and does not derive the native pair amplitude.

## 2. Valid retained results

- finite-body pair summation is executable;
- aggregation of the supplied inverse-square kernel reproduces the inverse-square exterior scaling to the reported numerical tolerance;
- count-resolved distance/time ratios can carry the frozen native result across scale without SI regression;
- no new macroscopic gravitational constant is introduced by aggregation itself.

## 3. Withdrawn R17 interpretation

The following former interpretation is superseded:

```text
CONSTITUENT FIELD RESPONSE                RESOLVED UPSTREAM
EXTERIOR 1/N_R^2 RESPONSE                 CLOSED FROM FIRST PRINCIPLES
SEAM_NATIVE_GRAVITY_SCALE_CONTINUATION_CLOSED
```

No constructor/value in this proof demonstrated the native pair amplitude, and the radial exponent was inserted into the runtime.

## 4. Current terminal

```text
SEAM_GRAVITY_MACRO_CONTINUATION_CONDITIONAL__MICRO_PAIR_KERNEL_REQUIRED
```

The controlling next proof object is

\[
(C_X,C_Y,N_R)\rightarrow\mathfrak f_{XY}(N_R),
\]

with radial form and amplitude both emitted by native SEAM structure.
