# Evidence 25 — Full SEAM-Native Gravitational Proof Transcript

**Contract:** `RUN-SEAM-GRAVITY-PROOF-R16-NATIVE-01`  
**Revision:** `CP-MASTER-2026.09.05-R16`

## 1. Objective

Execute the gravitational branch from SEAM first principles without treating SI or a conventional gravity constant as a primitive.

The proof target is the native chain:

```text
retained atomic/constituent state
-> native residual-field contribution
-> body aggregation A(B)
-> native body source S_M
-> native spatial potential Lambda(N_R)
-> native derivative / interaction response
-> finite-body aggregation
-> native dynamical consequence
-> seal
-> conventional projection/comparison only afterward
```

The external phrase **10 kg Fe sphere** identifies the requested physical specimen. It is not a native gravitational variable. Earlier work already translated that external specimen into a retained Fe constituent/isotope population. This proof starts from the retained state after that ingress translation.

## 2. Projection firewall

Native-run prohibited inputs:

- Newton's `G`;
- meters or any independently assumed SI length;
- seconds as an independent primitive;
- kilograms as a causal gravity variable;
- newtons;
- conventional `g`;
- target Cavendish force, acceleration, or orbital value;
- any coefficient fitted to such a target.

Native spatial variable:

\[
N_R=\|\Delta X\|_{SEAM}.
\]

Native evolution is count-resolved; the canonical time reference is transition count. Conventional time units are downstream reporting.

**Result:** `PASS — PROJECTION_FIREWALL`.

## 3. Native body source

The recovered aggregation operator is

\[
\boxed{
\mathfrak A(B)=\sum_{a\in B}\mu_a-\mathcal C_{\rm internal}(B),
\qquad S_M(B)=\mathfrak A(B).
}
\]

A native spatial source density is defined only by the reconstruction identity

\[
\boxed{S_M(B)=\int_{\Omega_B^{(S)}}\sigma_B^{(S)}(\xi)\,d^3\xi.}
\]

No mass density is needed to define this native source. The earlier `rho_m Xi` form is a downstream continuum projection and is not used as a primitive here.

For repeated homogeneous body state, the recovered aggregation rule gives

\[
S_M(cB)=cS_M(B).
\]

**Result:** source constructor `PASS_SYMBOLIC / EXECUTABLE_INTERFACE`; extensivity `PASS`.

## 4. Native exterior field

For a spherical exterior source, the active native radial potential is

\[
\Lambda_B(N_R)=-\mathcal K_B\frac{S_M(B)}{N_R}.
\]

Differentiate with respect to native distance only:

\[
\boxed{
\mathfrak g_B(N_R)
=-\frac{d\Lambda_B}{dN_R}
=-\mathcal K_B\frac{S_M(B)}{N_R^2}.
}
\]

For two retained body sources,

\[
\boxed{
\mathfrak F_{A\leftarrow B}(N_R)
=-\mathcal K_{AB}\frac{S_AS_B}{N_R^2}.
}
\]

`mathfrak F` is a native interaction response, not a newton-valued force. `mathcal K_AB` is a native residual-field amplitude label and has no permission to be replaced by `G`.

**Result:** `PASS_ANALYTIC — NATIVE_INVERSE_SQUARE_DERIVATIVE`.

## 5. Finite-body aggregation

Native discrete form:

\[
\mathfrak F_{A\leftarrow B}=\sum_i\sum_j\mathfrak f_{ij}.
\]

Native continuum equivalent:

\[
\mathfrak F_{A\leftarrow B}
=\int\!\!\int
\sigma_A^{(S)}(\xi)\sigma_B^{(S)}(\eta)
\mathbf k_S(\xi,\eta)
\,d^3\eta\,d^3\xi.
\]

The R16 deterministic numerical check used 400 native-coordinate sites per body, fixed seed `160905`, native cloud width `1`, and native center separations `N_R = 50, 100, 200, 400`. The unit pair amplitude is a normalization used only to test the exponent/aggregation theorem.

| N_R | native summed response | response × N_R² |
|---:|---:|---:|
| 50 | 64.0264924897573 | 160066.231224393 |
| 100 | 16.00317865641 | 160031.7865641 |
| 200 | 4.00039085490704 | 160015.634196282 |
| 400 | 1.00004851355419 | 160007.76216867 |

Coefficient of variation of `response × N_R²`:

```text
0.00014029566058558
```

**Result:** `PASS_NUMERIC — MACRO_LATTICE_INVERSE_SQUARE_AGGREGATION`.

## 6. Parameter-free native predictions

At fixed body source states,

\[
\frac{\mathfrak F(N_R)}{\mathfrak F(2N_R)}=4.
\]

Under source extensivity, doubling both same-state body sources gives

\[
\frac{\mathfrak F(2S_A,2S_B)}{\mathfrak F(S_A,S_B)}=4.
\]

Runtime output:

```text
response(N_R) / response(2 N_R) = 4.0
response(2S,2S) / response(S,S) = 4.0
```

Neither result contains `G`, SI length, SI time, mass in kilograms, or a conventional force unit.

**Result:** `PASS_NUMERIC — PARAMETER_FREE_NATIVE_SCALING`.

## 7. Orbital consequence

The native central field has radial derivative proportional to `-N_R^-2`. A conforming native motion/update operator acting on the canonical count-resolved evolution coordinate therefore receives a central inverse-square interaction. The geometrical consequence is the familiar conic central-field family and constant areal sweep.

No conventional reduced mass, SI time coordinate, or `GM` term is introduced to establish this field geometry. A numerical conventional orbital period remains a downstream projection requiring the native inertial/evolution mapping to be numerically populated.

**Result:** `PASS_GEOMETRIC — CENTRAL_INVERSE_SQUARE_ORBIT_FAMILY`; numerical conventional orbit remains a projection task.

## 8. 10 kg Fe target

The phrase `10 kg Fe` remains an external specimen identifier only. Earlier evidence translated it to a retained Fe body population. The native gravity branch consumes only that retained population:

```text
B_Fe = retained Fe isotope/constituent state
S_Fe = A(B_Fe)
N_R  = native separation count
```

and evaluates

\[
\mathfrak F_{Fe\leftarrow B}(N_R)
=-\mathcal K_{Fe,B}\frac{S_{Fe}S_B}{N_R^2}.
\]

No SI quantity enters this evaluation.

## 9. Exact native terminal

The source interface is declared, the inverse-square native derivative is analytic, finite-body scaling is numerically reproduced, and same-state ratio predictions execute.

The current archive does **not** yet numerically populate the constituent residual-field contribution `mu_a` and `C_internal(B)` (or an exactly equivalent native amplitude constructor) sufficiently to emit an absolute native interaction magnitude for the Fe target.

Therefore:

```text
NATIVE GRAVITY ARCHITECTURE                    PASS
PROJECTION FIREWALL                           PASS
1/N_R -> 1/N_R^2 DERIVATIVE                  PASS_ANALYTIC
FINITE-BODY AGGREGATION                       PASS_NUMERIC
SOURCE EXTENSIVITY                            PASS
PARAMETER-FREE RATIOS                         PASS_NUMERIC
G REQUIRED                                    FALSE
SI PRIMITIVE USED                             FALSE
ABSOLUTE NATIVE INTERACTION MAGNITUDE         NATIVE_RESIDUAL_FIELD_AMPLITUDE_BINDING_REQUIRED
```

This is the first exact unresolved native quantity. It may not be filled with `G`, a Cavendish fit, an SI force target, or any other downstream comparator.

## 10. Current gravitational standing

The proof establishes the causal structure:

\[
\boxed{
\text{atomic/constituent residual field}
\rightarrow
\text{body source}
\rightarrow
1/N_R\text{ native potential}
\rightarrow
1/N_R^2\text{ native interaction}
\rightarrow
\text{macroscopic gravity observations downstream}.
}
\]

Thus gravity is not a SEAM primitive. The remaining numerical work is the native constituent residual-field amplitude itself, not a gravitational constant and not an SI calibration.
