# Evidence 29 — SEAM Gravity Current-Standing Reconciliation (R20)

## Purpose

This record reconciles the active gravity documentation with the already-executed closed attraction/gravity process. It is a documentation correction, not a new physical derivation.

## Current closed chain

```text
resolved retained atomic/body state
-> state-derived E_ab, g_Theta,ab, mathcal S_ab
-> H_attr(N_R)
-> native radial derivative f_ab(N_R)
-> finite-body aggregation / continuum equivalent
-> native exterior field and orbital continuation
-> freeze
-> optional downstream conventional projection/comparator
```

The governing operator is

\[
H_{\rm attr}
=-\sum_{a,b}E_{ab}g_{\Theta,ab}\frac{\eta_{ab}(N_{R,ab})}{N_{R,ab}}\mathcal S_{ab}.
\]

The state factors are execution outputs of the closed constructor. They are not gravity-specific free parameters, calibration constants, or open mappings.

For the exterior branch, `eta -> 1`, and direct native differentiation yields the inverse-square pair response. Finite-body summation carries the resolved response to arbitrary retained populations.

## Historical audit scope

R16–R18 artifacts record intermediate proof development and surrogate-kernel audits. They remain useful provenance but do not define current standing and do not reopen the closed attraction branch.

## Current terminal

`SEAM_NATIVE_ATTRACTION_GRAVITY_PROCESS_CLOSED`

## Current status

- Native attraction Hamiltonian: CLOSED / EXECUTABLE
- State-factor population: CLOSED / EXECUTABLE
- Exterior radial derivative: CLOSED / EXECUTABLE
- Finite-body aggregation: CLOSED / EXECUTABLE
- Native time-space continuation: CLOSED / EXECUTABLE
- Macroscopic/orbital continuation: CLOSED / EXECUTABLE
- Gravity current standing: FULLY CLOSED
