# Evidence 27 — SEAM Gravity Kernel Audit and R18 Correction

**Revision:** CP-MASTER-2026.09.05-R18  
**Purpose:** preserve the complete audit that narrowed the R16/R17 gravity claim to what the executed artifacts actually establish.

## A. Trigger

The R17 proof claimed native gravitational scale continuation was closed. Independent rerun reproduced the numerical output exactly but inspected the runtime itself.

## B. Line-level finding

The aggregation runtime contains the kernel component:

```python
total += dx/(r2*r)
```

Since `r2 = r^2` and `r = sqrt(r2)`, this is

\[
\frac{dx}{r^3}
=\hat r_x\frac{1}{r^2}.
\]

The script therefore assumes a unit-amplitude inverse-square pair interaction before aggregation.

## C. Consequence

The reported low-CV exterior result is valid evidence that finite-body aggregation preserves the supplied inverse-square exponent. It cannot serve as evidence that SEAM atomic structure generated that exponent.

The same distinction applies analytically:

\[
\Lambda\propto-1/N_R
\quad\Rightarrow\quad
-d\Lambda/dN_R\propto1/N_R^2
\]

is correct calculus, but it does not derive the input `1/N_R` potential.

## D. Parameter-free checks

The R17 checks

```python
ratio_sep = (2.0/1.0)**2
ratio_source = (2.0*2.0)/(1.0*1.0)
```

encode the expected `4.0` consequences directly. They verify arithmetic consistency with the assumed exponent/extensivity; they are not independent outputs from a SEAM atomic state.

## E. Amplitude finding

The runtime comment identifies a **unit native pair amplitude**. Setting the amplitude to `1` normalizes the geometry test; it does not derive the native interaction magnitude.

Accordingly, `G_required = FALSE` remains valid only as the statement that Newton's `G` is not a required SEAM primitive. It does not establish that the SEAM pair amplitude has already been populated.

## F. Corrected standing

**Closed:**

1. retained body composition/state;
2. native time-space ratio continuation;
3. finite-body pair aggregation;
4. preservation of a supplied inverse-square kernel under aggregation;
5. analytic differentiation of a supplied `1/N_R` potential.

**Current proof boundary:**

\[
\boxed{(C_X,C_Y,N_R)\rightarrow\mathfrak f_{XY}(N_R)}
\]

The constructor must emit both:

- the radial dependence, with `p=2` emerging if inverse-square is the native result; and
- the native pair amplitude.

Neither may be inserted by a hardcoded kernel, unit normalization, Newtonian `G`, torsion calibration, or SI comparator.

## G. Corrected terminal

```text
SEAM_GRAVITY_MACRO_CONTINUATION_CONDITIONAL__MICRO_PAIR_KERNEL_REQUIRED
```

This correction does not reopen the valid aggregation mathematics. It removes only the unsupported claim that the aggregation proof derived the microscopic gravitational kernel.
