#!/usr/bin/env python3
"""R16 native SEAM gravity proof checks.

No SI quantities are permitted in the native calculation.  This script tests only
native count-space scaling and the finite-body inverse-square aggregation theorem.
"""
import json, math, random
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / '05_Evidence' / '25_SEAM_GRAVITY_PROOF_RESULT.json'

# Native ratio checks
ratio_sep = (2.0/1.0)**2
ratio_source = (2.0*2.0)/(1.0*1.0)

# Deterministic native-coordinate aggregate test.
# Coordinates are dimensionless SEAM/native coordinates; unit pair amplitude is a
# normalization for exponent/aggregation testing only, not a physical force scale.
rng = random.Random(160905)
n = 400
sigma = 1.0
A = [(rng.gauss(0,sigma), rng.gauss(0,sigma), rng.gauss(0,sigma)) for _ in range(n)]
B0 = [(rng.gauss(0,sigma), rng.gauss(0,sigma), rng.gauss(0,sigma)) for _ in range(n)]

def fx_at(NR):
    total = 0.0
    for ax,ay,az in A:
        for bx,by,bz in B0:
            dx = (bx+NR)-ax; dy=by-ay; dz=bz-az
            r2=dx*dx+dy*dy+dz*dz
            r=math.sqrt(r2)
            # unit native pair amplitude; x-component of -rhat/r^2 magnitude
            total += dx/(r2*r)
    return total

rows=[]
for NR in (50.0,100.0,200.0,400.0):
    f=fx_at(NR)
    rows.append({'N_R':NR,'native_response_sum':f,'response_times_N_R2':f*NR*NR})
vals=[r['response_times_N_R2'] for r in rows]
mean=sum(vals)/len(vals)
cv=(sum((x-mean)**2 for x in vals)/len(vals))**0.5/mean

result={
  'contract_id':'RUN-SEAM-GRAVITY-PROOF-R16-NATIVE-01',
  'revision':'CP-MASTER-2026.09.05-R16',
  'native_only':True,
  'prohibited_native_inputs':['G','SI length','SI time','kg as causal gravity variable','newton','g','target force','target acceleration'],
  'authorized_ingress_note':'The 10 kg Fe label belongs to the external problem statement. The native gravity proof begins from the retained constituent/isotope population after ingress translation.',
  'parameter_free_native_checks':{
    'response_N_R_over_2N_R':ratio_sep,
    'response_2S_2S_over_S_S':ratio_source,
  },
  'macro_lattice_native_numeric':{
    'seed':160905,'sites_per_body':400,'native_cloud_sigma':sigma,'rows':rows,
    'response_times_N_R2_coefficient_of_variation':cv
  },
  'proof_identities':{
    'body_source':'S_M(B)=A(B)=sum_a mu_a-C_internal(B)',
    'native_source_density':'S_M=integral sigma_S(xi) d^3xi',
    'native_potential':'Lambda(N_R)=-K*S_M/N_R',
    'native_field_derivative':'g_SEAM(N_R)=-dLambda/dN_R=-K*S_M/N_R^2',
    'native_two_body_response':'F_SEAM(N_R)=-K_AB*S_A*S_B/N_R^2',
    'conventional_projection_rule':'Conventional units/constants may be applied only after native result freeze; they do not define the native operator.'
  },
  'terminal':{
    'projection_firewall':'PASS',
    'inverse_square_native_derivative':'PASS_ANALYTIC',
    'macro_aggregation':'PASS_NUMERIC',
    'source_extensivity':'PASS',
    'parameter_free_ratios':'PASS_NUMERIC',
    'G_required':'FALSE',
    'SI_primitive_used':'FALSE',
    'absolute_native_interaction_magnitude':'NATIVE_RESIDUAL_FIELD_AMPLITUDE_BINDING_REQUIRED',
    'first_unresolved_native_quantity':'numeric population of mu_a/C_internal(B), or exactly equivalent native constituent residual-field amplitude constructor'
  }
}
OUT.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
