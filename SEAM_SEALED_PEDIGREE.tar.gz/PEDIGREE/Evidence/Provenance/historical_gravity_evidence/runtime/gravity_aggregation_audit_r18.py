#!/usr/bin/env python3
"""R18 audit of the prior gravity aggregation test. No physics is derived here.
It records that the tested pair kernel is supplied explicitly as unit-amplitude 1/r^2.
"""
from math import sqrt

def supplied_pair_x(dx,dy,dz):
    r2=dx*dx+dy*dy+dz*dz
    r=sqrt(r2)
    return dx/(r2*r)  # supplied x-component of rhat/r^2

if __name__ == '__main__':
    print('kernel_source=SUPPLIED')
    print('kernel_radial_exponent=2')
    print('kernel_amplitude=1 (normalization for aggregation test)')
    print('derives_microscopic_kernel=FALSE')
    print('valid_test=FINITE_BODY_AGGREGATION_OF_SUPPLIED_KERNEL')
    print('terminal=SEAM_GRAVITY_MACRO_CONTINUATION_CONDITIONAL__MICRO_PAIR_KERNEL_REQUIRED')
