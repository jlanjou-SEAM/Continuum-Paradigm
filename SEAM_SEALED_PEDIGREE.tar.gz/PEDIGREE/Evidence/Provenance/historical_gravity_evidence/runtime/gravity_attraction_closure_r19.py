#!/usr/bin/env python3
"""R19 audit of declared exterior attraction-Hamiltonian derivative.
This verifies implementation of the declared operator; it does not claim to rediscover H_attr.
"""
from fractions import Fraction

def h_ext(K, N):
    return -K/N

def f_ext(K, N):
    # -d(-K/N)/dN = -K/N^2 (inward sign)
    return -K/(N*N)

def main():
    K=Fraction(7,3)
    N=Fraction(5,1)
    f1=f_ext(K,N)
    f2=f_ext(K,2*N)
    assert f1/f2 == 4
    assert h_ext(K,N) == -K/N
    print('operator=DECLARED_H_ATTR_EXTERIOR')
    print('eta_limit=1')
    print('force_ratio_N_to_2N=', float(f1/f2))
    print('newton_G_used=FALSE')
    print('tau_pair_mapping_required=FALSE')
    print('terminal=SEAM_NATIVE_ATTRACTION_GRAVITY_PROCESS_CLOSED')
if __name__=='__main__': main()
