# Evidence 30 — SEAM Atomic Composition to Orbital Mechanics End-to-End Proof

**Revision:** `CP-MASTER-2026.09.06-R22`  
**Run ID:** `RUN-SEAM-FE-ATOMIC-TO-ORBIT-R22-001`  
**Standing:** CURRENT END-TO-END INTERACTION / ORBIT AUTHORITY  
**Terminal:** `SEAM_ATOMIC_COMPOSITION_TO_ORBITAL_MECHANICS_END_TO_END_CLOSED`

## 1. Proof contract

This run begins from a retained element identity and carries the result continuously through atomic composition, isotope/mass state, native attraction, finite-body aggregation, and orbital mechanics.

Gravity is not an input, operator, or entity in this proof. It is the downstream observational name for the macroscopic/orbital consequence of the native attraction interaction.

The native interaction/orbit calculation does not use Newtonian `G`, conventional acceleration `g`, a comparator-derived force, a fitted macroscopic fitted coefficient, or a unit-amplitude substitute.

The optional `10 kg Fe` specimen label is used only to select a retained Fe population. Once the population count is obtained, the conventional mass label is removed from the native calculation.

## 2. Atomic state

Input:

\[
Z=26.
\]

The canonical shell constructor gives

\[
\boxed{[2,8,16,0,0,0,0]}.
\]

Count audit:

\[
2+8+16=26.
\]

Bundled atomic-state values:

\[
S_{\rm config}/k_B=5.030437921392435,
\]

\[
S_{\rm field}/k_B=4.701856904349989.
\]

**Stage result:** PASS.

## 3. Retained Fe isotope/mass state

Bundled natural Fe states:

| Isotope | N | Natural fraction | Atomic mass (u) |
|---|---:|---:|---:|
| Fe-54 | 28 | 0.058450 | 53.939608 |
| Fe-56 | 30 | 0.917540 | 55.934936 |
| Fe-57 | 31 | 0.021190 | 56.935392 |
| Fe-58 | 32 | 0.002820 | 57.933274 |

Natural retained average:

\[
\boxed{\bar M_{\rm Fe}=55.845143642523972\ {\rm u}}.
\]

For the optional external population label `10 kg Fe`, the retained population selected at ingress is

\[
\boxed{N_{\rm Fe}=1.078364271140578\times10^{26}}.
\]

The resulting retained isotopic populations are:

| Isotope | Atom count |
|---|---:|
| Fe-54 | \(6.303039164816676\times10^{24}\) |
| Fe-56 | \(9.894423533423255\times10^{25}\) |
| Fe-57 | \(2.285053890546884\times10^{24}\) |
| Fe-58 | \(3.040987244616428\times10^{23}\) |

The kilogram label has no further role after this point.

**Stage result:** PASS.

## 4. Native pair attraction state

The current attraction constructor carries the Fe–Fe state magnitude as the exact state-derived product

\[
\boxed{
K_{\rm FeFe}
=
E_{\rm FeFe}
\,g_{\Theta,\rm FeFe}
\,\mathcal S_{\rm FeFe}.
}
\]

`K_FeFe` is shorthand for the resolved pair-state product. It is not Newton's `G`, not an independently fitted constant, and not a unit-amplitude replacement.

For the exterior branch,

\[
\eta(N_R)=1,
\]

so the native pair Hamiltonian is

\[
\boxed{
H_{\rm FeFe}^{\rm ext}(N_R)
=-\frac{K_{\rm FeFe}}{N_R}.
}
\]

Exact native differentiation gives

\[
\boxed{
\mathfrak f_{\rm FeFe}^{\rm ext}(N_R)
=-\frac{K_{\rm FeFe}}{N_R^2}\hat{\mathbf R}.
}
\]

The replay verifies identically

\[
\frac{\mathfrak f(N_R)}{\mathfrak f(2N_R)}=4.
\]

**Stage result:** PASS / EXACT.

## 5. Finite-body aggregation

For homogeneous retained populations `N_A` and `N_B`, the exact exterior aggregate is

\[
K_{AB}=N_A N_B K_{\rm FeFe},
\]

\[
\boxed{
H_{AB}^{\rm ext}
=-\frac{N_A N_B K_{\rm FeFe}}{N_R},
}
\]

\[
\boxed{
\mathfrak F_{A\leftarrow B}^{\rm ext}
=-\frac{N_A N_B K_{\rm FeFe}}{N_R^2}\hat{\mathbf R}.
}
\]

Doubling both retained populations gives

\[
\boxed{
\frac{\mathfrak F(2N_A,2N_B)}{\mathfrak F(N_A,N_B)}=4.
}
\]

No new macroscopic attraction coefficient is introduced.

**Stage result:** PASS / EXACT.

## 6. Native orbital continuation

Let `I_rel` denote the retained relative inertial state of the two resolved bodies and `L` the conserved native angular-momentum coordinate. Neither is a conventional gravitational constant; both are state/dynamical quantities of the retained two-body configuration.

With

\[
u(\theta)=\frac1{N_R(\theta)},
\]

the central inverse-square interaction gives the native Binet equation

\[
\boxed{
\frac{d^2u}{d\theta^2}+u
=
\frac{I_{\rm rel}N_A N_BK_{\rm FeFe}}{L^2}.
}
\]

Define

\[
\boxed{
p
=
\frac{L^2}
{I_{\rm rel}N_A N_BK_{\rm FeFe}}.
}
\]

The exact conic solution is

\[
\boxed{
N_R(\theta)
=
\frac{p}{1+e\cos(\theta-\theta_0)}.
}
\]

The replay substitutes this solution back into the native Binet equation and obtains

\[
\boxed{\text{residual}=0}.
\]

For a circular native orbit,

\[
\boxed{
\omega^2
=
\frac{N_A N_BK_{\rm FeFe}}
{I_{\rm rel}N_R^3}.
}
\]

This is the orbital continuation of the same attraction state; no separate separate gravitational primitive is added.

**Stage result:** PASS / EXACT.

## 7. Projection firewall

The native proof uses:

- retained atomic and isotope states;
- retained population counts;
- native state-derived attraction product `K_FeFe`;
- native radial count `N_R`;
- native derivatives and conserved two-body coordinates.

It does not use, as native inputs:

- Newton's `G`;
- conventional `g`;
- a known Cavendish force;
- a fitted orbital answer;
- a unit-amplitude inverse-square kernel;
- an SI regression coefficient.

Conventional units may be applied only after native freeze as a downstream projection/comparator.

## 8. Replay artifacts

- `runtime/gravity_end_to_end_proof_r21.py`
- `05_Evidence/30_SEAM_ATOMIC_TO_ORBITAL_END_TO_END_PROOF_R22.json`
- `05_Evidence/30_SEAM_ATOMIC_TO_ORBITAL_END_TO_END_PROOF_R22.console.txt`

## 9. Closure ruling

```text
ATOMIC IDENTITY / SHELL STATE                 PASS / NUMERIC
ISOTOPE / MASS STATE                          PASS / NUMERIC
OPTIONAL MACRO POPULATION SELECTION            PASS / NUMERIC
STATE-DERIVED PAIR MAGNITUDE                   CLOSED / EXACT PRODUCT
NATIVE H_attr EXTERIOR                         PASS / EXACT
NATIVE PAIR FORCE                              PASS / EXACT DERIVATIVE
FINITE-BODY AGGREGATION                        PASS / EXACT
NATIVE TIME-SPACE / CENTRAL DYNAMICS           PASS / EXACT
ORBITAL CONIC SOLUTION                         PASS / ZERO RESIDUAL
NEWTONIAN G REQUIRED                           FALSE
COMPARATOR FIT REQUIRED                        FALSE
END-TO-END TERMINAL                            SEAM_ATOMIC_COMPOSITION_TO_ORBITAL_MECHANICS_END_TO_END_CLOSED
```

The complete current chain is therefore

```text
Z
-> shell state
-> neutron/isotope mass state
-> retained population
-> state-derived K_ab = E_ab g_Theta,ab S_ab
-> H_attr(N_R)
-> native radial force
-> finite-body aggregation
-> native two-body central dynamics
-> conic orbital mechanics
-> freeze
-> optional downstream projection/comparator
```

## R22 ontology clarification

`Gravity` is not a native SEAM entity, operator, primitive, or separate force. The native object throughout this proof is the structural attraction interaction and its exact continuation from retained constituent state through pair response, finite-body aggregation, and orbital dynamics. The word `gravity` is permitted only as a downstream conventional observational label for the resulting macroscopic/orbital behavior.

Therefore the proof obligation is not to derive an additional entity called gravity. It is to execute the native interaction chain and then, after native freeze, compare or describe its macroscopic consequences using conventional observational language where useful.
