# R132 — Calcite SEAM structural orientation test

No refractive index, Snell law, wavelength relation, dispersion formula, or optical attenuation coefficient is used.

Calcite is represented only as its atomic matrix. The unit cell contains 6 Ca + 6 C + 18 O nodes. Distances are locally normalized by the nearest periodic C-O separation. Atomic shell states use the archive's sequential SEAM shell construction.

The existing SEAM complete-state field definition is evaluated along a directed structural excitation path while only the crystal orientation is changed.

Maximum integrated structural support occurs at 90 degrees from the crystallographic c axis.
Minimum occurs at 0 degrees.

max/min support ratio = 1.254365545118
orientation contrast = 20.278423 %

This establishes a directional response from the atomic matrix alone. It does not yet convert that response into an optical exit angle or frequency shift.
