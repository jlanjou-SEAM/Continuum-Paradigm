# R135 — O-012 frequency/matrix ingress lock

R134 established that calcite and fused silica produce different directional structural-field landscapes when treated only as atomic/material matrices.

The next requested step was to add excitation-frequency coordinates to both matrices without importing refractive index, Snell law, wavelength, Sellmeier dispersion, or empirical optical coefficients.

The canonical archive already permits multi-frequency excitation coordinates to be instantiated. R45 explicitly records that these coordinates can be present on the complete event state.

However, the same canonical record states that the heterogeneous excitation-to-field mapping has not been executed and identifies the required missing object:

`G_exc: (Y_i, DeltaY_exc) -> (F_i_exc, R_i_exc, O_ij^nm, S_field, S_coupling)`

followed by the unchanged complete-state entropy selector.

Therefore this run instantiates the frequency coordinates on the calcite and fused-silica matrix test but returns no numerical frequency-conditioned directional response.

Terminal:

`STOP_G_EXC_UNBOUND`

This is a mathematical hard stop, not a negative physical result. R134 remains the valid matrix-orientation result; R135 identifies the exact operator required for the next step.
