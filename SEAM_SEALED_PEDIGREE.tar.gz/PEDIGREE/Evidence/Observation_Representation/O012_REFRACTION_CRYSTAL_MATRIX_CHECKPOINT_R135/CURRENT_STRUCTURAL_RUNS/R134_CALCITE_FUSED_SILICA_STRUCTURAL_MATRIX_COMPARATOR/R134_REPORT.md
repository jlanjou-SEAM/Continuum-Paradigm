# R134 — Calcite vs fused-silica structural-matrix comparator

No refractive index, Snell law, wavelength law, dispersion equation, or optical coefficient was used.

## Calcite
Ordered atomic matrix.
- strongest coarse-scan orientation: 30°
- weakest orientation: 50°
- structural support contrast: 19.027%

## Fused silica
Treated as a SiO2 structural matrix with tetrahedral short-range order but without an imposed long-range crystallographic axis.

Independent network realization 101:
- strongest orientation: 10°
- contrast: 61.744%

Independent network realization 202:
- strongest orientation: 80°
- contrast: 33.471%

The fused-silica preferred direction is not stable between random-network realizations, whereas calcite's ordered matrix produces a fixed directional feature in the same calculation.

This supports material-matrix dependence of directed excitation support. It does not yet derive a physical exit angle.
