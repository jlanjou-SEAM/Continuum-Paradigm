# SEAM Fe/Cu/Ag/Au Molecular Branch and Cavendish Boundary Evidence

> **No-reduction rule (see `00_README.md`).** Structure in this archive is retained faceted and is never collapsed to a scalar. A faceted or symbolic form is a complete description of a *resolved* structure, not a deferred value. It does not license reading an unevaluated row as resolved: see the three-state status vocabulary (`RESOLVED` / `EXCLUDED` / `NOT_EVALUABLE`) in `00_README.md`.

**Evidence ID:** 22  
**Revision binding:** `CP-MASTER-2026.09.05-R13`  
**Runtime:** `runtime/variational_field_evaluator.py` / `VF-REGION-LBFGSB-R4`  
**Machine record:** `provenance/FE_CU_AG_AU_VF_R13_POINTS.json`

## Purpose

Retain the Fe–Fe molecular evaluator result as a valid molecular result while explicitly preventing its use as an undeclared constructor or terminal condition for the macroscopic Cavendish branch.

## Fe–Fe retained execution

Fe native shell state and matched capacities:

```text
N = [2,8,16]
c = [2,8,18]
S_inf/k_B = 15.455879927694806
```

| N_r | S*/k_B | Delta s/k_B | grad norm | top-two delta | status |
|---:|---:|---:|---:|---:|---|
| 3.00 | 15.314305617534355 | -0.141574310160451 | 1.7674527453036166e-06 | 2.1871866096034864e-08 | RESOLVED |
| 5.00 | 15.441060037939100 | -0.014819889755706 | 0.0 | 5.329070518200751e-15 | RESOLVED |
| 5.80 | 15.455270778323483 | -0.000609149371323 | 0.0 | 7.833733661755105e-13 | RESOLVED |
| 6.00 | 15.455879927694806 | 0.000000000000000 | 0.0 | 0.0 | RESOLVED |

At the retained points the interacting Fe–Fe state approaches the separated value from below and has no positive interior entropy excess.

## Cross-state molecular comparison

The same packaged runtime reproduces:

| Case | N | c | retained interior point | S*/k_B | separated S_inf/k_B | Delta s/k_B |
|---|---|---|---:|---:|---:|---:|
| Cu | `[2,8,18,1]` | `[2,8,18,32]` | 6.20 | 12.502276251235417 | 12.497760650081300 | +0.004515601154117 |
| Au | `[2,8,18,32,18,1]` | `[2,8,18,32,18,32]` | 9.50 | 13.805284477169847 | 13.801724192057707 | +0.003560285112140 |
| Ag | `[2,8,18,19]` | `[2,8,18,32]` | 6.20 | 45.524661573474590 | 45.545439449109190 | -0.020777875634600 |

For Ag, an additional retained point at `N_r=7.00` gives `45.539798558047970`, still below the separated value at `N_r=8.00`.

The current comparison therefore records a molecular-evaluator association: Cu/Au have near-empty outer capacity and positive interior excess at their recorded points; Fe/Ag have substantially occupied outer capacity and do not show the same positive-interior behavior in the retained points. This is an empirical pattern inside the evaluator results, **not a universal occupancy law**.

## Withdrawn inference

The following cross-branch inference is rejected:

```text
Fe-Fe molecular Delta s <= 0
=> Fe macroscopic attraction must be E0 Delta tau
=> TAU_PAIR_MAPPING_UNBOUND
=> Cavendish SYMBOLIC_ONLY
```

No canonical equation in the active archive establishes the v18.6 molecular pair-state Hamiltonian as the constructor of `S_M` or `S_A,S_B`.

## Cavendish standing

The blind macroscopic calculation proceeds under its own branch:

```text
resolved body state
-> S_M / S_A,S_B
-> macroscopic attraction relation (including mathcal G_S binding/normalization)
-> finite-body geometry
-> torsion projection
-> result freeze
-> comparator reveal
```

`TAU_PAIR_MAPPING_UNBOUND` remains a valid molecular total-pair-energy terminal where that mapping is required. It is not a macroscopic Cavendish terminal without an explicit operator binding.
