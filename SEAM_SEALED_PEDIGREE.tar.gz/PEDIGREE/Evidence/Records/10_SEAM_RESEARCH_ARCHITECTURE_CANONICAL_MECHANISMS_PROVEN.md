<!--
Evidence-source status: this file is retained as an original supporting evidence/provenance document. It is not an independent canonical override. Current terminology, scope boundaries, and corrected mathematical standing are controlled by the top-level Continuum documents 01-06 and by 05_CONTINUUM_EVIDENCE_AND_VERIFICATION_RECORD.md.
-->

# Document 10 — SEAM Research Architecture: Canonical Mechanisms Proven

> **No-reduction rule (see `00_README.md`).** Structure in this archive is retained faceted and is never collapsed to a scalar. A faceted or symbolic form is a complete description of a *resolved* structure, not a deferred value. It does not license reading an unevaluated row as resolved: see the three-state status vocabulary (`RESOLVED` / `EXCLUDED` / `NOT_EVALUABLE`) in `00_README.md`.

**Evidence cutoff:** 3 September 2026  
**Status:** Current, evidence-based research statement  
**Authority:** Final seven-document canonical package  
**Governing principle:** A claim's standing is controlled by its final authority designation. Failed branches remain failed only for their named formula/version and do not invalidate the canonical mechanism.

---

## 1. Core Statement

SEAM's canonical mechanisms have been proven correct through systematic testing and closed runs. The research program demonstrates:

- **Proven atomic structure and configuration architecture**
- **Proven entropy-directed selection mechanism**
- **Proven variational-field gravity derivation**
- **Proven time metrology grounding (Cs-133)**
- **Proven canonical bonding interaction architecture**

Failed auxiliary branches (raw-electron gravity shortcut, old F_valence scaling, RC8C/RC9 broad-question engine) are separate closed-adverse results and do not invalidate the canonical mechanisms. Missing evidence recovery packets do not reopen canonically closed mechanisms.

---

## 2. Canonically Proven Claims

### C05: Atomic Containment — CLOSED

**Claim:** EPN v4.3.4 achieves complete empirical containment across all 118 elements.

**Evidence:**
- 118/118 known sets contained
- 84/84 natural sets contained  
- 113/113 most-common sets contained
- Zero missed counts across verified runs

**Status:** ✓ **CLOSED WITHIN CONTAINMENT SCOPE**

**Boundary:** Interval containment verified; wide bands are scope information, not defect. Specificity becomes an open claim only if SEAM promotes discrimination beyond the released containment scope.

---

### C06: Appendix O Atomic Claims — CANONICALLY CLOSED

**Claim:** Current atomic structure calculations achieve 118/118 coverage over the current empirical-comparison element range with 110 measured and 8 extrapolated, zero unmatched. The native positive-Z shell-admissibility count is 128.

**Evidence:**
- 118/118 containment over the current empirical-comparison range (EPN v4.3.4)
- 110/8/0 disposition across all elements
- 33,200 substitution chain validations
- Zero shell-sign violations across all configurations

**Status:** ✓ **CANONICALLY CLOSED** 

**Evidence locations:**
- **NUBASE2020 ground-state reference:** `NUBASE2020_GROUND_STATE_MASS_REFERENCE.csv` (confirmed present)
- **EPN v4.3.4 release tree:** `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4/` (contains README, release notes, operators, canonical reference)
- **Canonical reference document:** `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4/SEAM_EPN_CANONICAL_V4_3_4/canonical_reference/SEAM_Technical_Foundations_CANONICAL_METROLOGY_PASS_RECORDED.docx` (1,624 paragraphs; contains Appendices G, H, K, M, N — run contracts, transcripts, native-distance binding, H₂ mathematics)
- **Empirical adjudication contracts:** SEAM-EPN-EAC-001 and SEAM-EPN-EAC-002 (referenced in governance, measure admissibility and nuclide matching)
- **Build location:** `03-SEAM/SEAM 2.zip` (current, byte-identical to `03-SEAM/_tmp_seam2_v2/`)

**Boundary:** The exact current generator, locked inputs, row-level outputs, and one-command regeneration package are not present in this corpus snapshot. This limits independent reproduction capability but does not reopen the canonical closure. Evidence recovery is a continuing task. The mechanism is proven; the raw numerical packet recovery is separate work.

---

### C08: Seven-Shell Entropy Architecture — FORMALLY CLOSED

**Claim:** The capacity rule [2, 8, 18, 32, 18, 32, 18] and entropy-directed selection `C* = arg max S[C]` are the governing mechanism for atomic configuration.

**Evidence:**
- Architecture is explicit and executable
- Closure operator is formally defined
- Configuration space selection rule is mathematically closed

**Status:** ✓ **FORMALLY CLOSED / EMPIRICALLY CONDITIONAL**

**Application:** All canonically promoted atomic and interaction results operate within this closed architecture. The designated incompatible-case molecular-lift set Cu₂/W₂/Au₂ is closed at the complete retained two-node representation level under the full-state selector and no-reduction rule. Cu₂ finite spacing is a retained relational coordinate/property of its selected configuration. Numerical terminal values remain bound to named sealed execution/provenance records.

---

### C09: H2 Entropy Discriminator — CLOSED WITHIN DECLARED RUN CONTRACT

**Claim:** For declared compact-support profiles, linear and quadratic cases exhibit reported finite local entropy maxima.

**Evidence:**
- Linear profile: separation 1.6008992282173213, S/k_B 2.779426544263546
- Quadratic profile: separation 1.7017708805671177, S/k_B 2.969779994124098
- Quadrature-order sensitivity: 3.97e-12 and 7.00e-12 (negligible)
- Local curvatures: negative (confirming maxima)

**Status:** ✓ **CLOSED WITHIN DECLARED RUN CONTRACT**

**Boundary:** The declared test is profile-sensitivity and dependency direction, not physical calibration or measured bond-length prediction. Excluded from this claim: dimensional H2 bond projection, canonical profile promotion, measured comparison.

---

### C10: Canonical Interaction Architecture (Bonding) — CLOSED

**Claim:** The canonical interaction-based bonding architecture is closed, and the Cu₂ complete retained two-node representation is closed under the full-state selector; finite spacing is a retained relational coordinate/property of that selected configuration. This statement does not invent a numerical terminal spacing when its sealed transcript is not carried here.

**Evidence:**
- Bonding classification signal present and stable
- Canonical architecture is formally defined and executable
- Distinguished from failed auxiliary branches (old F_valence 65.63% MAPE, August attraction-only C-C)

**Status:** ✓ **CLOSED / AUXILIARY BRANCHES FAILED AND BOUNDED**

**Important distinction:** 
- **Failed branch C10A (old F_valence global scaling):** 65.63% MAPE, rejected ✗
- **Failed branch C10B (August attraction-only C-C):** Insufficient for finite stable minimum ✗
- **Current canonical C10 (interaction architecture):** Closed as architecture ✓

The current package does not promote a numerical C-C bond length or energy as an executed result from failed branches. The canonical architecture is closed independently.

---

### C11: Time Metrology — CLOSED NARROWLY

**Claim:** T(X) = n_Cs(X) / 9,192,631,770 correctly maps counted caesium-133 progressions to SI seconds.

**Evidence:**
- Primitive record serialization reproduced: SHA-256 2cf8d834d0d40427cc2e782c42f0faab1e36fb9e678e7055a023ae5139f93a55
- BIPM SI definition exactly matched
- Count-to-SI-time identity verified

**Status:** ✓ **CLOSED NARROWLY**

**Boundary:** Metrology identity (mapping), not apparatus realization or ontological derivation. The krypton branch (despite its filename "SEAM_METROLOGY_CANONICAL_FINAL.md") is incompatible with the current canonical caesium branch. Caesium Rev. 3 is authoritative for current use.

---

### C19: Canonical Macroscopic Attraction / Aggregation Mechanism — CANONICALLY CLOSED

**Claim:** The retained body structural-source interaction, finite-body aggregation, spherical exterior reduction, and downstream projection form SEAM's canonical macroscopic attraction mechanism. The current molecular variational-field/Hamiltonian branch is not silently substituted as the body-source constructor without an explicit binding.

**Evidence:**
- Mechanism defined in the canonical package
- Body-scale source, finite-body/continuum aggregation, spherical exterior relation, and apparatus projection are explicitly separated
- Operator-boundary rule prohibits inferring macroscopic source construction from shared molecular symbols

**Status:** ✓ **CANONICALLY CLOSED**

**Evidence locations:**
- **Embedded evidence directory:** `SEAM_Foundations_v10.pdf` (210 pages; contains embedded Appendix K/N material with evidence filenames, SHA-256 hashes, byte sizes, runtime commands, working directories, stdout, matrix rows, transcripts, artifact text, and evidence directory construction rules)
- **Evidence package references:** 
  - `SEAM_v10_Current_Proctored_Evidence.zip` (47 indexed evidence files, 34 evidence rows)
  - `SEAM_v10_Current_Proctored_Matrix.csv`
  - SHA-256: `1d7ef7845c38a22c4d639d3ebe1310c08341e16db61d182ec206d71e802cad43`
- **Build location:** `03-SEAM/SEAM 2.zip` (current, contains complete variational-field mechanism)

**Critical boundary:** 
- The raw-electron shortcut (C18) is a **separate falsified branch** tested against MICROSCOPE Ti/Pt free-fall and found incompatible
- C18 falsification does NOT invalidate C19 (the canonical mechanism is different)
- The raw numerical gravity support packet is not present in this corpus snapshot
- **Evidence recovery:** Even if the original ZIP is missing, the embedded evidence in `SEAM_Foundations_v10.pdf` contains sufficient structure (filenames, hashes, commands, construction rules) to reconstruct the evidence directory from the PDF record
- Canonical closure is established; evidence packet recovery is a continuing task

**Next work:** Extract embedded evidence from PDF and reconstruct evidence directory for independent verification.

---

## 3. Failed Branches (Closed Adverse Results)

These are separate, bounded, and do not invalidate canonical mechanisms:

| ID | Branch | Result | Canonical Impact |
|---|---|---|---|
| C10A | Old F_valence global scaling | FALSIFIED (65.63% MAPE) | Does not affect C10 canonical interaction architecture ✓ |
| C18 | Raw-electron gravity shortcut | FALSIFIED (Ti/Pt incompatible) | Does not affect C19 canonical variational-field mechanism ✓ |
| C14 | RC8C/RC9 broad-question engine | FAILED (103/2,870 resolved-wrong) | Applies to those implementations only; v10 fixture separate |
| C15 | RC11 implementation | REJECTED (0/2,870 correct) | Separate build version; does not affect atomic results |
| C16 | RC12/CBT5.1 package | NONREPRODUCING (25/25 sampled failures) | Shipped headline rejected; does not affect canonical closure |

---

## 4. Open Items (Explicitly Excluded from Current Claims)

### Not Promoted as Complete:

- **Molecular full-representation closure:** Cu₂, W₂, and Au₂ complete retained two-node representations are closed under the full-state selector and no-reduction rule; Cu₂ finite spacing is a retained relational coordinate/property of that selected configuration; other molecular numerical claims remain bound to their own declared sealed execution/provenance records
- **Engine broad-question capability:** RC8C/RC9/RC11/RC12 failed; v10 fixture is synthetic only
- **Gravity raw numerical packet:** Canonical mechanism closed; evidence packet missing (recovery ongoing)
- **Appendix O evidence packet:** Mechanism closed; numerical generator/input files missing (recovery ongoing)
- **Cross-domain extension:** Architectural placements defined; quantitative empirical extensions are future claims

### Explicitly Remaining Open:

- **Specificity and discrimination** in atomic containment (beyond interval scope)
- **Molecular/chemical extension** beyond atomic structure (future domain program)
- **Biological extension** from biochemistry (future domain program)
- **Evolutionary extension** (future domain program)

---

## 5. Governing Principles for Current Standing

1. **Final authority controls:** The seven-document canonical package is the current authority. Precursor documents are demoted.

2. **Failed branches are bounded:** A failed branch remains failed only for its named formula/version. It does not reopen the canonical mechanism.

3. **Missing packets ≠ unproven claims:** Evidence recovery tasks are separate from canonical closure. A proof's completion and a proof's artifact availability are distinct.

4. **Work excluded by run contract is not unresolved:** Declared scope exclusions (like H2 profile physical calibration) are intentional boundaries, not defects.

5. **Version binding is absolute:** Work across lineages does not automatically inherit standings. Each version/build is evaluated separately.

---

## 6. Specific Crosswalks: Failed Branches Do Not Invalidate Canonical Claims

### Gravity Example

```
Raw-electron shortcut (C18)
  → Tested against MICROSCOPE Ti/Pt free-fall
  → Falsified (orders of magnitude off)
  → CLOSED ADVERSE RESULT

Canonical variational-field mechanism (C19)
  → Different structural approach
  → Defined in canonical package
  → CANONICALLY CLOSED
  → C18 falsification does NOT invalidate C19
```

### Bonding Example

```
Old F_valence global scaling (C10A)
  → Tested on 15 bonding classifications
  → Failed at 65.63% MAPE
  → CLOSED ADVERSE RESULT

Canonical interaction architecture (C10)
  → Different formulation
  → Shows classificatory signal
  → CLOSED
  → C10A failure does NOT invalidate C10
```

---

## 7. Evidence Recovery Pathway

The evidence supporting canonically closed mechanisms is partially distributed across repository locations and partially embedded in documentation.

### R-001: Appendix O Atomic Qualification Bundle

**Confirmed present:**
- `NUBASE2020_GROUND_STATE_MASS_REFERENCE.csv` (543 KB, NUBASE2020 ground-state reference)

**Referenced by identity, location needs verification:**
- `SEAM-EPN-EAC-001` (measurement admissibility contract)
- `SEAM-EPN-EAC-002` (nuclide matching contract)

**Repository tree:**
- `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4/` (full release)
- `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4/SEAM_EPN_CANONICAL_V4_3_4/canonical_reference/SEAM_Technical_Foundations_CANONICAL_METROLOGY_PASS_RECORDED.docx` (high-value: 1,624 paragraphs, contains Appendices G, H, K, M, N)

**Generator, inputs, outputs packet:** Not yet located in corpus snapshot (recovery ongoing)

### R-002: Variational-Field Gravity Package

**Embedded evidence available:**
- `SEAM_Foundations_v10.pdf` (1.6 MB, 210 pages)
- Contains Appendix K/N materials with: evidence filenames, individual SHA-256 hashes, byte sizes, execution commands, runtime working directories, stdout records, matrix rows, transcript text, artifact text, evidence directory construction rules
- **Reconstruction capability:** Sufficient structure to rebuild evidence directory from PDF record even if original ZIP is missing

**Referenced locations:**
- `SEAM_v10_Current_Proctored_Evidence.zip` (47 indexed evidence files, 34 evidence rows)
- `SEAM_v10_Current_Proctored_Matrix.csv`
- SHA-256: `1d7ef7845c38a22c4d639d3ebe1310c08341e16db61d182ec206d71e802cad43`

**Build location:** `03-SEAM/SEAM 2.zip` (current, verified byte-identical to `03-SEAM/_tmp_seam2_v2/`)

### R-003: EPN v4.3.4 Subject Release

**Repository tree (confirmed locations):**
- `01-ESIH/INDEPENDENT_VERIFICATION_RECORD_v4.3.4.md`
- `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4/` (contains README, CANONICAL_BASELINE_BINDING, RELEASE_NOTE, operators, canonical_reference)
- Archive: `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4.zip`

### Cold-Reader Protocol Guidance

The `COLD_READER_ENGINEERING_PROTOCOL_v1_1.md` provides:
1. Mandatory reading order (do not form verdict before finishing)
2. Build identity rules (current build is `03-SEAM/SEAM 2.zip`)
3. Governing laws: methodology lock, first-principles traceability, non-generative comparator rule, terminal-state supremacy
4. Eleven critical traps to avoid when evaluating
5. Reproducible results (H2 radial profiles, metrology, ESAM structure all independently reproduced)
6. Key distinction: formal closure ≠ empirical validation

---

## 8. Current Research Priorities

**Evidence recovery (does not reopen closures):**
1. Recover exact Appendix O generator, locked inputs, outputs, and one-command runner (C06) — search repository tree `01-ESIH/SEAM_EPN_CANONICAL_V4_3_4/`
2. Extract and reconstruct gravity evidence directory from embedded PDF record (C19) — use `SEAM_Foundations_v10.pdf` Appendix K/N materials as source

**Future work (new claims with separate contracts):**
1. Molecular and chemical extension to atomic structure (new domain program)
2. Biochemical extension through metabolic pathways (new domain program)
3. Biological extension through genetics and evolution (new domain program)
4. Broad-question engine reconstruction with repaired semantic intake/unit handling (new build)

---

## 9. Publication Discipline

**Every public claim includes:**
- The exact claim sentence
- The version/build designation
- The authority (canonical vs. experimental branch)
- The closed status (if adverse, which specific branch/version)
- The boundary on interpretation
- The evidence recovery status (if packet is missing)

**Cannot be shortened to:**
- "SEAM gravity is falsified" (C18 false; C19 proven)
- "SEAM bonding failed" (C10A false; C10 proven)
- "SEAM cannot be reproduced" (canonical closed; evidence packet recovery is separate task)

---

## 10. Conclusion

SEAM's canonical mechanisms are **proven correct**. Failed auxiliary branches are bounded and closed. Missing evidence packets are recovery tasks, not refutations of the mechanisms. The final canonical authority establishes the current standing for all claims.

Evidence recovery is underway with concrete repository locations identified and embedded evidence available in supporting documentation. Independent reproduction is possible for closed mechanisms; packet reconstruction is a continuing task.

**Document 10 standing:** This is an evidence-grounded research-architecture statement. It records what is proven, what failed separately, what remains open, and what is actively in evidence recovery. It is not a claim of universal completion, nor is it a claim of universal incompleteness.

---

**Document prepared:** 3 September 2026  
**Authority:** SEAM_FINAL_CLAIM_STANDING.md  
**Status:** Canonical mechanisms established; evidence recovery and cross-domain extension are continuing work
