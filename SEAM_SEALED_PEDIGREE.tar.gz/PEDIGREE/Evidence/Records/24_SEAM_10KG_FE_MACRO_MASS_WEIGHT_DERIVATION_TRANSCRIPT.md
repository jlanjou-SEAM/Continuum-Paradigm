# Evidence 24 — 10 kg Fe Macroscopic Mass/Weight Derivation Transcript

> **No-reduction rule (see `00_README.md`).** Structure in this archive is retained faceted and is never collapsed to a scalar. A faceted or symbolic form is a complete description of a *resolved* structure, not a deferred value. It does not license reading an unevaluated row as resolved: see the three-state status vocabulary (`RESOLVED` / `EXCLUDED` / `NOT_EVALUABLE`) in `00_README.md`.

## Purpose

This evidence record preserves the derivation path that fixed the current SEAM execution target:

\[
\boxed{\text{10 kg Fe body state}\rightarrow\text{native macroscopic source}\rightarrow\text{field/acceleration}\rightarrow\text{force/torque/weight}.}
\]

It records both retained results and withdrawn inferences. The purpose is to prevent future executors from repeating the same operator substitutions or redefining the task as a molecular-binding or equivalence-principle coefficient problem.

This transcript is an execution/provenance record. Current canonical standing is controlled by `02_CONTINUUM_TECHNICAL_FOUNDATIONS.md`, especially Appendix O.4.

---

## 1. Initial 10 kg Fe body-state resolution

The body-state calculation resolved the following composition for a 10 kg iron sphere:

```text
10 kg Fe = 1.078364e+26 atoms, 179.0666 mol
electrons = 2.803747e+27

54Fe  6.303e+24 atoms   0.564556 kg
56Fe  9.894e+25 atoms   9.190153 kg
57Fe  2.285e+24 atoms   0.216037 kg
58Fe  3.041e+23 atoms   0.029254 kg

R = 6.718 cm at 7874 kg/m^3
```

The substantive result was that the retained isotope/mass state scales from atomic and molecular use to a body containing approximately `10^26` atoms without requiring loss of the isotope state.

At this stage, body composition was resolved. Field/force had not yet been produced.

---

## 2. Pair-count scaling concern and correction

An intermediate analysis treated the finite-body double sum as though direct enumeration of all atom pairs were required. For a macroscopic body pair this implied an infeasible pair count and was initially described as a missing structural requirement.

That conclusion was corrected.

The canonical distinction is:

\[
\boxed{\text{pairwise mathematical definition}\neq\text{pairwise brute-force enumeration}.}
\]

The finite-body sum may be represented by its continuum form when a number/source density exists:

\[
\mathbf F_{A\leftarrow B}
=
\int_{V_A}\int_{V_B}
\sigma_A(\mathbf x)\sigma_B(\mathbf y)
\mathbf k(\mathbf x,\mathbf y)
\,d^3y\,d^3x.
\]

The pair-count problem was therefore withdrawn as a fundamental blocker.

---

## 3. Recovery of the macroscopic attraction branch

The broader project record contained a macroscopic aggregation/spherical-field branch that had not been fully restored into the then-current consolidated master.

The recovered body-scale relations included the exterior structural-source form

\[
\Lambda(r)\propto-\frac{S_M}{r},
\]

and therefore

\[
-\nabla\Lambda(r)
\propto
-\frac{S_M}{r^2}\hat{\mathbf r}.
\]

For two bodies the retained large-scale relation was

\[
F_{\rm attr}^{(0)}(r)
=
-\frac{\mathcal G_S S_A S_B}{r^2}.
\]

This established that the macroscopic calculation has its own native body-source branch and should not be reconstructed ad hoc from an unrelated molecular operator merely because both describe interaction.

---

## 4. Incorrect molecular substitution

A blind Cavendish contract was temporarily written so that the body calculation entered the current v18.6 molecular selected-state/Hamiltonian path:

```text
C_XY* -> u* -> S* -> E_H -> DeltaH -> F
```

That splice was not canonically justified.

The resulting Fe–Fe molecular evaluation was real, but the inference from it to macroscopic attraction was not.

### 4.1 Retained Fe–Fe molecular result

Using the packaged deterministic evaluator `VF-REGION-LBFGSB-R4`, Fe used

```text
N = [2,8,16]
c = [2,8,18]
S_inf/k_B = 15.455879927694806
```

with the reproduced points:

| `N_r` | `S*(N_r)/k_B` | `Delta s` |
|---:|---:|---:|
| 3.00 | 15.314305617534355 | -0.141574310160451 |
| 5.00 | 15.441060037939100 | -0.014819889755706 |
| 5.80 | 15.455270778323483 | -0.000609149371323 |
| 6.00 | 15.455879927694806 | 0.000000000000000 |

The Fe molecular curve approaches the separated state from below at the retained points and does not show a positive interior entropy excess there.

The cross-state observation retained with it was:

```text
Cu: N=[2,8,18,1],       c=[2,8,18,32],       positive interior Delta s
Au: N=[2,8,18,32,18,1], c=[2,8,18,32,18,32], positive interior Delta s
Fe: N=[2,8,16],          c=[2,8,18],           non-positive retained branch
Ag: recorded branch rises toward separated value without the same retained positive-interior behavior
```

The association between outer-shell occupancy and the observed molecular curve shape is retained only as an evaluator pattern, not as a universal law.

### 4.2 Withdrawn inference

The following inference is explicitly withdrawn:

```text
Fe-Fe Delta s <= 0
-> Fe macroscopic attraction must arise from E0 Delta tau
-> TAU_PAIR_MAPPING_UNBOUND
-> Cavendish = SYMBOLIC_ONLY
```

No canonical equation had established that the molecular selected-state constructor is the macroscopic source constructor.

The general rule established from this correction is:

> Shared symbols, common interaction language, and continuity across scale do not establish operator identity. An executor may not substitute one declared constructor for another without an explicit canonical binding.

---

## 5. Native macroscopic execution and discovery of the constructor omission

The macroscopic branch was then executed on its own terms.

The body composition and geometry resolved, but `S_M`, `S_A/S_B`, `sigma(x)`, and `mathcal G_S` appeared only as consumed symbols in the consolidated archive available at that point. The run therefore stopped inside the macroscopic branch rather than in the molecular branch.

The reported terminal was:

```text
RUN-SEAM-CAVENDISH-FE-1KG-MACRO
step 1  COMPLETE
step 2  COMPLETE
step 3  INDETERMINATE: UNDECLARED_INPUT
        S_M / S_A,S_B — no constructor from resolved body state
        sigma_A(x)    — source-density operator undefined
        G_S           — not defined, no normalization rule
steps 4-7 not reachable
```

This was a materially different boundary from the withdrawn molecular terminal.

---

## 6. Recovery of the missing macroscopic source constructor

The shared SEAM project record was then reread and the missing constructor recovered.

The body aggregation operator is

\[
\boxed{
\mathfrak A(B)
=
\sum_{a\in B}\mu_a
-
\mathcal C_{\rm internal}(B)
}
\]

with active macro binding

\[
\boxed{S_M(B)\equiv\mathfrak A(B)},
\qquad
S_A=\mathfrak A(A),
\qquad
S_B=\mathfrak A(B).
\]

The spatial source representation is

\[
\boxed{
\sigma_B(\mathbf x)
=
\rho_{m,B}(\mathbf x)\Xi_B(\mathbf x)
}
\]

with

\[
\Xi=f(p,n,e,\text{shell},\text{period},\text{group}).
\]

A historical representative coordinate expansion was recovered:

\[
\Xi=
 a_1\frac{p}{p+n}
+a_2\frac{n-p}{n+p}
+a_3\frac{\sqrt e}{1+\mu(p+n)}
+a_4\frac{1}{\mathrm{period}}
+a_5\chi(\mathrm{group})
+a_6\sum_j\gamma_j\frac{N_j/C_j}{j}.
\]

Its coefficients were not promoted to new canonical constants because the recovered source did not bind them numerically.

This changed the standing from “no macroscopic constructor exists” to “the constructor exists; exact numerical source evaluation must use whatever primitive weights/cancellation/invariant bindings are canonically available.”

---

## 7. Equivalence-principle admissibility refinement

A subsequent review examined the representative `Xi` expansion as a future source binding.

For a neutral atom,

\[
\frac{n-p}{n+p}=1-\frac{2Z}{A},
\]

so the first two terms are algebraically redundant:

\[
a_1\frac{Z}{A}
+a_2\frac{N-Z}{A}
=
a_2+(a_1-2a_2)\frac{Z}{A}.
\]

Therefore the representative expansion contains one fewer independent composition direction than its raw six-term appearance suggests.

The EP discussion then established the correct constraint form. A single material-pair experiment constrains one linear combination of the independent composition coefficients, not each coefficient separately. For several independent composition pairs, define rows `d_k` and stack them into

\[
D=
\begin{bmatrix}
\mathbf d_1\\
\mathbf d_2\\
\vdots\\
\mathbf d_m
\end{bmatrix}.
\]

The admissibility condition is

\[
|\mathbf d_k\cdot\mathbf a|\le\epsilon_k
\]

for all tested pairs, or collectively

\[
D\mathbf a\approx0.
\]

If `D` has full rank over the independent composition coordinates, the allowed non-universal coefficient subspace is driven toward zero within experimental tolerance. If it is rank-deficient, its null space identifies the composition direction not constrained by the included tests.

The archive directionality rule then fixes the admissible use of such evidence:

> External equivalence-principle comparators may test a SEAM-derived `Xi`; they may not be used to fit or define the native `Xi` coefficients.

This EP branch is a constraint/validation branch. It does not replace the 10 kg Fe target execution.

---

## 8. Final target clarification

The target was then fixed explicitly:

> The goal is to get the executor to produce a mass/weight calculation for a 10 kg iron sphere.

The task is not:

- a general equivalence-principle study;
- a coefficient-space fit;
- a molecular Fe–Fe binding calculation;
- or another inventory of missing framework components.

The measured 10 kg is the specified body input. The requested calculation is the complete retained body state and the field/force/weight that follows from the native macroscopic source chain.

The final execution contract is therefore:

```text
1. Resolve complete 10 kg Fe constituent state.
2. Construct native macro source A(B), S_M, and sigma(x) as required.
3. Determine whether any unresolved Xi coordinate is actually needed for this same-material calculation.
4. Execute the native macro field/attraction law.
5. For Cavendish, apply the specified second body and geometry and calculate force/torque.
6. For weight, identify the external source/field, derive acceleration natively, then calculate W = M a.
7. Freeze the native result before revealing a conventional/experimental comparator.
8. If execution terminates, report the first exact unresolved scalar/operator inside this chain and the fully evaluated expression immediately before it.
```

The executor is specifically prohibited from replacing step 8 with a broad statement that gravity is unresolved or from redirecting the calculation into `E_H`, molecular `tau_SEAM`, `TAU_PAIR_MAPPING_UNBOUND`, or EP coefficient fitting unless an explicit canonical equation requires that quantity in the body-source chain.

---

## 9. Current canonical deliverable

The required report from a 10 kg Fe execution is:

```text
A. Retained body state
   material / isotope populations / nuclide masses / constituent counts / density / geometry

B. Native macroscopic source state
   A(B), S_M, sigma(x), and every actually used source coordinate

C. Native field result
   exterior field / acceleration in the specified geometry

D. Physical projection
   force, torque, or weight as requested

E. Exact terminal if incomplete
   first unresolved native scalar/operator only
```

The calculation is successful if it produces a native numerical quantity before comparator reveal. A symbolic terminal is acceptable only when it identifies the first exact unresolved item in the correct macroscopic chain.

---

## 10. Standing produced by this derivation process

The retained conclusions are:

1. The 10 kg Fe isotope/mass state is resolvable without reducing it to a single average atomic identity.
2. A macroscopic body interaction does not require brute-force enumeration of all atom pairs.
3. The macroscopic attraction/source branch is distinct from the v18.6 molecular Hamiltonian branch unless explicitly bound.
4. The Fe–Fe molecular result remains valid but does not determine Fe macroscopic attraction.
5. The macroscopic source constructor exists in the shared SEAM project record and is restored in the active archive.
6. The representative `Xi` expansion is structurally constrained by algebraic redundancy and equivalence-principle admissibility, but those comparators cannot define its native coefficients.
7. The immediate execution goal is the 10 kg Fe mass/source/field/weight calculation itself.
8. Future executors must run that chain directly and stop only at its first exact native boundary.
