# SEAM Deterministic Variational Evaluator Binding — R4

> **No-reduction rule (see `00_README.md`).** Structure in this archive is retained faceted and is never collapsed to a scalar. A faceted or symbolic form is a complete description of a *resolved* structure, not a deferred value. It does not license reading an unevaluated row as resolved: see the three-state status vocabulary (`RESOLVED` / `EXCLUDED` / `NOT_EVALUABLE`) in `00_README.md`.

**Runtime identity:** `VF-REGION-LBFGSB-R4`  
**Canonical implementation:** `runtime/variational_field_evaluator.py`  
**Purpose:** eliminate solver interpretation from the v18.6 `argmax` stage.

## Fixed execution contract

- exact support-region partition; no sampled spatial grid;
- exact spherical-lens shell-intersection geometry;
- Python 3.13.5 / NumPy 2.3.5 / SciPy 1.17.0;
- float64;
- five deterministic starts with scales `0, .35, .70, 1.05, 1.40`;
- L-BFGS-B;
- `ftol=1e-15`, `gtol=1e-9`, `maxiter=10000`, `maxls=100`;
- accept selected gradient norm `<=2e-5`;
- accept top-two objective difference `<=2e-6`;
- select highest complete entropy; exact ties go to lower start index.

A failure of either acceptance gate is not repaired. It terminates `INDETERMINATE_OPTIMIZER_NOT_CONVERGED`.

## Cu2 reference point

Contract inputs:

```text
N=[2,8,18,1]
c=[2,8,18,32]
N_r=6.20
lambda_field=1.0
lambda_coupling=0.1
```

Executed result:

\[
\boxed{S^*/k_B=12.502276251235417}
\]

```text
status = RESOLVED
selected gradient norm = 5.024295863460037e-7
top-two objective delta = 2.048518332742333e-8
```

Machine-readable transcript: `../provenance/CU2_VF_R4_NR_6_2.json`.

## Hamiltonian boundary

The v18.6 entropy contribution is executable from the selected state. The historical v6 `tau_SEAM` accumulator is not treated as a molecular pair-state mapping. If total pair energy requires `Delta tau_SEAM` and the active contract does not supply a current selected-state evaluator, the exact terminal state is:

```text
SYMBOLIC_ONLY: TAU_PAIR_MAPPING_UNBOUND
```

The runtime therefore never guesses zero, infers a value from `S*=S_inf`, or imports a historical time operator by name similarity.
