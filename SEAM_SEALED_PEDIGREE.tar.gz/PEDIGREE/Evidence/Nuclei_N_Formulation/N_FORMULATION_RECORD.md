# R173 — Neutron Count (N) Formulation Disclosure

**Standing:** `DISCLOSURE_ONLY_NOT_A_CLOSURE`
**Generator:** `Evidence/Runtime/n_formulation_disclosure.py` (`N-FORMULATION-DISCLOSURE-R173-1`)
**Comparator source:** `Evidence/Locked_Runs/R142_NUCLEAR_TRANSITION_PROJECTION_BATCH/O048_MASS_DEFECT_DOWNSTREAM_COMPARATOR_LOCK/FROZEN_NUBASE2020_GROUND_STATE_MASS_REFERENCE.csv`
**Table:** `Evidence/Nuclei_N_Formulation/Z001_Z128_NEUTRON_DISCLOSURE_TABLE.csv`

This record is **not** a closure and promotes no claim. It documents how a neutron
count may be specified against the bundled comparator, and what each way of
specifying it actually yields. No existing sealed artifact was modified, and the
R6 band runtime was neither changed nor re-derived.

## 1. Why a formulation is required

NUBASE2020 does not define a neutron count per element. `N` is a per-nuclide
identifier (`N = A - Z`), one row per measured ground state — 3,557 rows across
118 elements, of which 2,549 are `EVALUATED_EXPERIMENTAL`. IUPAC likewise
publishes an abundance-weighted mean atomic mass, which implies no integer `N`.

Neither source is withholding a number the other has. **Neither source contains a
per-element neutron count at all.** The quantity is absent, not disputed, so any
single integer `N` per element is a declared convention rather than a citation.

## 2. Disclosed selectors

Rather than adopt one convention, this record reports every selector the frozen
comparator can support, each with its own status.

| Selector | Definition | Unique | Degenerate | Undefined |
|---|---|---:|---:|---:|
| `N_longest_lived` | argmax half-life; `stbl` = infinite | 57 | 53 | 0 |
| `N_most_bound_per_nucleon` | argmax `(Z·Δ_H + N·Δ_n − Δ)/A` | 110 | 0 | 0 |
| `N_most_abundant` | argmax `Natural_Abundance_pct` | 84 | 0 | 26 |
| `N_observed_min` / `N_observed_max` | min/max `N` over experimental rows | 110 | — | — |

Constants used: Δ_H = 7288.971064 keV, Δ_n = 8071.31806 keV, both from the frozen
table itself.

## 3. The selectors disagree, and the disagreement is not small

- `N_longest_lived` vs `N_most_bound_per_nucleon`: **44** elements disagree.
- `N_most_abundant` vs `N_most_bound_per_nucleon`: **65** elements disagree.

Worked cases:

| Element | longest-lived | most bound | most abundant |
|---|---:|---:|---:|
| H (Z=1) | 0 | 2 | 0 |
| Fe (Z=26) | tie set {28;30;31;32} | 32 | 30 |
| U (Z=92) | 146 | 126 | 146 |

Two consequences follow. First, **"most stable" is ambiguous** and must be bound
explicitly to either half-life or binding energy per nucleon; the two are
different physical quantities and disagree for 44 elements. Second,
**`N_longest_lived` is degenerate for 53 of 110 elements**, because an element
with more than one stable isotope has no half-life maximum to take — tin has ten.
This generator reports the tie set rather than resolving it by an arbitrary pick.

## 4. Measured range versus admissibility envelope

The table carries both, as separate and differently-sourced columns:

- `N_observed_min` / `N_observed_max` — **measured.** The extremes of the
  experimentally evaluated nuclide rows for that element.
- `SEAM_N_low` / `SEAM_N_high` — **the R6 native band.** An admissibility
  envelope, not a measurement.

These must not be conflated in citation. The `SEAM_N_high_origin` column records
which condition set the upper edge in each row.

## 5. Standing finding on the band's upper edge

Across all 128 rows, `SEAM_N_high_origin` reports
`SCAN_CEILING_int(1.65P+10)` — **128 of 128**. The admissibility criterion
`W ≥ 0.55P` never becomes the binding condition at the upper edge inside the scan
window; unbounded, it does not fail until roughly 17–19× further out (N = 1010 at
Z = 26; N = 2898 at Z = 92).

The lower edge is different: `SEAM_N_low` is a genuine criterion crossing, where
`W` rises through `0.55P`.

The band is therefore **one-sided**: lower edge derived, upper edge imposed. The
containment result of 2,549/2,549 stands as recorded, and is a joint property of
the criterion and the scan ceiling rather than of the criterion alone.

`19_SEAM_EPN_BAND_EXTENSION_EVIDENCE.md` §5.1 already qualifies the band as
"an admissibility/scope envelope, not a precision isotope-location prediction,"
with an aggregate admitted-span/observed-span ratio of 3.77. That qualification
is the correct one to cite alongside the containment count.

## 6. What this record does not do

It does not derive the upper edge, does not justify the constant `1.65`, does not
select a canonical `N`, and does not close any registered claim. Deriving the
upper band edge from native structure remains open work and is the outstanding
item for `S-015`.
