# R49 OEC External Scientific Evidence Binding

**Role:** downstream empirical evidence for the bounded B01 OEC closed block.  
**Rule:** these sources constrain and test the SEAM state ledger; they do not define the upstream SEAM mathematics or substitute conventional energetic currencies.

## Bound observations

1. **Retained S-state cycle and room-temperature structures**  
   Kern et al., *Structures of the intermediates of Kok's photosynthetic water oxidation clock*, Nature 2018. PMCID: `PMC6485242`.  
   Bound observation: room-temperature 0F/1F/2F/3F structures populate S1/S2/S3/S0-rich states; transient 150 us and 400 us structures occur during S2->S3; an additional oxygen/water position appears during S2->S3.

2. **Four-electron/four-proton/one-O2 event count and water delivery**  
   *Photosystem II: commonality and diversity with emphasis on the extrinsic subunits*, PMCID: `PMC12661325`.  
   Bound observation: one completed Mn4CaO5 catalytic cycle couples four one-electron steps to oxidation of two water molecules, producing one molecular oxygen, four protons, and four electrons; one substrate water is delivered during S2->S3 and another during S3->[S4]->S0.

3. **Proton-release ordering and water/proton channels**  
   Ibrahim et al., *Structural dynamics in the water and proton channels of photosystem II during the S2 to S3 transition*, PMCID: `PMC8585918`.  
   Bound observation: the proton-release pattern is 1:0:1:2 for S0->S1, S1->S2, S2->S3, S3->S0; two substrate-water deliveries occur in distinct steps.

4. **Final O2-forming transition**  
   *Structural evidence for intermediates during O2 formation in photosystem II*, PMCID: `PMC10191843`.  
   Bound observation: S3->[S4]->S0 contains the O2-forming/reset sequence and resolves multiple structural intermediates over micro- to millisecond timescales.

5. **O2 membrane transport**  
   *Oxygen Concentration Inside a Functioning Photosynthetic Cell*, PMCID: `PMC4017319`.  
   Bound observation: small-molecule membrane flux follows `J=-P DeltaC`; measured O2 permeability of thylakoid lipid is 39.5 cm/s and an effective protein-rich thylakoid value of 8 cm/s is used in the cited model.

6. **O2 release pathway standing**  
   *Evolutionary diversity of proton and water channels on the oxidizing side of photosystem II and their relevance to function*, PMCID: `PMC10684718`.  
   Bound observation: specific O2 release pathways are not firmly established experimentally; nonspecific diffusion through the hydrophobic peptide/lipid matrix is considered likely.

## Evidence boundary

The external sources establish observed structures, event counts, timing/order, and transport constraints. They do **not** establish a SEAM scalar energy magnitude, the exact atom identities of both oxygens in released O2, or the downstream atom-resolved carbon successor. Those remain outside the closed block.
