# R49 OEC Technical Assertions Binding

This record binds the R49 evidence block to the canonical mathematics added to `02_CONTINUUM_TECHNICAL_FOUNDATIONS.md`.

## A. Unreduced identity ledger

Every atom and retained entity is carried as a persistent identity. Equal composition does not authorize algebraic cancellation.

\[
A_j^{(0)}\rightarrow A_j^{(1)}\rightarrow\cdots
\]

and a complete state is represented as

\[
Y_i=(\{A_j\},\{E_k\},\mathcal R_i,F_i,\Xi_i,\mathcal B_i).
\]

## B. Physical transition

\[
Y_i+\Delta Y_i\rightarrow Y_{i+1}+R_i
\]

where `R_i` is an explicit set/vector of exported or newly separated entities/state transfers. `R_i` is not collapsed to a scalar unless a native common projection has actually been derived.

## C. Closed retained-state cycle

For

\[
Y_n=Y_0,
\]

the retained-state differential closes,

\[
\Delta_{\mathcal C}^{\rm retained}=0,
\]

but exported event channels need not vanish. The OEC block therefore closes with

\[
R_{\rm cycle}=(N_e=4,N_H=4,N_{O_2}=1,\Delta S_{\rm OEC}=0).
\]

This is an event-level closure vector, not a scalar energy statement.

## D. Structural path length is not energy

\[
L_S=\sum_i|\Delta s_i|
\]

is permitted as a diagnostic of state traversal only. It cannot be relabeled as exported energy or entropy without a common native receiver metric. The earlier `0.05811475288` export interpretation is excluded by this rule.

## E. Boundary diffusion

A measured membrane permeability may be used only as an empirical boundary parameter:

\[
J_X=-P_X\Delta C_X.
\]

The molecule retains identity during transport. Boundary movement is therefore a location/state transition, not chemical consumption:

\[
X^{(m)}_{\rm local}\rightarrow X^{(m)}_{\rm external}.
\]

## F. Source/sink continuity

For a permeant species, sustained inward flux requires the receiving side not to saturate. A downstream retained successor can maintain the concentration differential without being named in advance:

\[
X_{\rm external}\rightarrow X_{\rm local}\rightarrow E_{\rm retained}.
\]

For B01 carbon, this is a boundary condition only. The atom-resolved carbon successor remains open.

## G. Open-system matter support

Water or other environmental matter entering the local apparatus is recorded as a new identified ingress event from `\mathcal B_i`; no equal molecule elsewhere may be cancelled against it.

## H. Scope of closure

R49 closes the OEC retained-state cycle and its immediate event/transport interfaces only. It does not close the full carbon branch, scalar transfer magnitude, exact released-O2 ancestry, or whole photosynthesis.
